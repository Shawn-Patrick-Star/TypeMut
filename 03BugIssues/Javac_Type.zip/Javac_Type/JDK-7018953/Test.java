package sandbox.test11;
public class Test {
    static class Node<E> {
        class Details {
            E e;
            Details(final E e) {
                this.e = e;
            }
        }
        Details details;
        Details getDetails() {
            return details;
        }
        Details createDetails(E e){
            details = new Details(e);
            return details;
        }
    }
    public Test(Node<? extends CharSequence> node) {
        Node<? extends CharSequence>.Details details = node.getDetails();
//        String str = ((CharSequence) details.e).toString();
        String str = details.e.toString(); // Bang!
        System.out.println(str);
    }
    public static void main(String[] args) {
        Node<String> node = new Node<String>();
        node.createDetails("test");
        new Test(node);
    }
}