     4  class T
     5  {
     6   public static void main(String[] ps)
     7   {
     8    List<String> list = getList();
     9   }
    10
    11   public static List<String> getList()
    12   {
    13    return new ArrayList();
    14   }
    15  }