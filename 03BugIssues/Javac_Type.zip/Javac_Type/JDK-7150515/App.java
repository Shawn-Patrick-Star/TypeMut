public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        App x = new App();
        B b = x.new B();
        D d = x.new D();
        E e = x.new E();
        F f = x.new F();
        String s = "Hallo";
        b.convertValue(d, e, -1, s);
    }
    abstract class A {
        abstract void convertValue(D d, E e, int i, Object... os);
        abstract void convertValue(D d, F f, E e, int i, Object... os);
        abstract void convertValue(D d, E e, Object... os);
    }
    class B extends A {
        void convertValue(D d, E e, int i, Object... os) {
        }
        void convertValue(D d, E e, Object... os) {
        }
        void convertValue(D d, F f, E e, int i, Object... os) {
        }
    }

    class C extends A {
        void convertValue(D d, E e, int i, Object... os) {
        }
        void convertValue(D d, E e, Object... os) {
        }
        void convertValue(D d, F f, E e, int i, Object... os) {
        }
    }
    class D {
        public D() {
            System.out.println("D - Constructor");
        }
    }
    class E {
        public E() {
            System.out.println("E - Constructor");
        }
    }
    class F {
        public F() {
            System.out.println("F - Constructor");
        }
    }
}