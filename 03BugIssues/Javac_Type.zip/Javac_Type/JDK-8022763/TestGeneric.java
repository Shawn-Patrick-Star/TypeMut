public class TestGeneric {
    
    public static void main(String[] args) {
        TestGeneric test = new TestGeneric();
        String result = test.<String>test( " test " );
    }
    
    public <T> T test(T t){
        try{
            T test = (T) new Integer(42);
            return test;
        } catch (ClassCastException ex){
            System.err.println( " Exception " );
        }
        
        return (T)  " pass " ;
    }
}