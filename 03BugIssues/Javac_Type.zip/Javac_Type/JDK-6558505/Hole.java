
class Hole<T> {
    class X extends RuntimeException {
        T t;
        X(T t) { this.t = t; }
    }
    T foo() {
        try {
            bar();
            return null;
        } catch (X x) {
            return x.t;
        }
    }
    void bar() {
        throw new Hole<Integer>().new X(3);
    }
    public static void main(String[] args) {
        System.out.println (new Hole<String>().foo());
    }
}