
package one;

public abstract class Abs {
  abstract void method();

  public void test() {
    method();
  }
}