package two;

class Conc extends Abs {
  Conc() {
    test();
  }

  public static void main(String[] args) {
    new Conc();
  }
}