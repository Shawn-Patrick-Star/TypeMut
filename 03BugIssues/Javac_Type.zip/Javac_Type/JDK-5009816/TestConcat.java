public class TestConcat {
    /* Note that if this class doesn't extend TestConcat everything
     * goes just fine */
    public static class TestConcatInner extends TestConcat {
        private double[] numbers;
        private String[] symbols;

        public TestConcatInner(double[] numbers, String[] symbols) {
            this.numbers = numbers;
            this.symbols = symbols;
        }

        public String toString() {
            // note also that prefixing concat with 'TestConcat.' also works
            return concat(numbers) + ' ' + concat(symbols);
        }
    }

    private static String concat(double[] list) {
        StringBuffer retval = new StringBuffer();
        for (int i = 0; i < list.length; i++) {
            if (i != 0) retval.append(", ");
            retval.append(list[i]);
        }
        return retval.toString();
    }

    private static String concat(String[] list) {
        StringBuffer retval = new StringBuffer();
        for (int i = 0; i < list.length; i++) {
            if (i != 0) retval.append(", ");
            retval.append(list[i]);
        }
        return retval.toString();
    }

    public static void main(String[] args) {
        double[] numbers = {1.0, 2.0, 3.0};
        String[] symbols = {"a", "b", "c"};
        TestConcatInner test = new TestConcatInner(numbers, symbols);
        System.out.println(test);
    }
}