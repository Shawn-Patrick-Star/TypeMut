class Outer<T> {

	class Cell {
		final T value;
		Cell(T value) {
			this.value = value;
		}
	}
	
	Outer<T>.Cell cast(Outer<?>.Cell o) {
		return (Cell) o; // expected: unchecked warning
	}
	
	public static void main(String[] args) {
		Outer<Integer>.Cell intCell = new Outer<Integer>().new Cell(314);
		Outer<String>.Cell strCell = new Outer<String>().cast(intCell);
		String val = strCell.value; // ClassCastException
		System.out.println(val);
	}
}