class method definitions is to prompt the compiler that this
method can indeed be called with a base class reference, but I
believe this is where the compiler fails to do proper dynamic
binding.

The design issue is not really polymorphic calls, but overloading
methods with different parameters that are all classes in the
same hierarchy.  I wish I had more time to explore the compilers
design, but I still almost NEVER want a base method called if there
is a more specific method implemented in the subclass.

Jason
(Review ID: 57686) 
======================================================================

BT2:EVALUATION

Overload resolution is based on the compile-time *type* of the arguments
to the overloaded method, not their actual class at runtime.  To get the
behavior you want, you need:

public static void main( String[] args ) {
   MyString s1 = new MyString();
   MyString s2 = new MyString();
   MyInteger i1 = new MyInteger();
   MyInteger i2 = new MyInteger();
   Datum res;

   res = s1.operOne(s2);
   res = s1.operTwo(i2);
   res = i1.operOne(s1);
}