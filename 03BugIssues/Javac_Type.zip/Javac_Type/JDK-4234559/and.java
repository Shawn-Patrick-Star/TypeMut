I am providing the base class and two subclasses.  I am demonstrating
two operations between Datum.  If the operation between two Datum
is defined, then I want the method in the Subclass to be called.  If
it is not defined, it drops to the Superclass method and throws a
exception that my evaluator catches. (basically, an operation not 
defined for data type exception).

This should work, but doesn't, due to some strange design of 
polymorphic calls to Overloaded AND Overridden superclass methods.
But, the design below is most elegant, short, and easy to debug
and maintain.  Other options require tons of instanceof checking,
or constant maintenance of the Datum class, by adding EVERY possible
combination of subclasses and operations, which for example, if you
have 8 datum and 8 operations, then the Datum class needs 64 exception
throwing methods...

How else can one do this behaviour, which in design, is very object
oriented, and exploits the benefits of polymorphic calls.  But it
doesn't work, and any attempt to make it work kills all goals of
OO polymorphic design.

public class Datum {
   public Datum operOne( Datum d ) { throw new MyException(); }
   public Datum operTwo( Datum d ) { throw new MyException(); }
}