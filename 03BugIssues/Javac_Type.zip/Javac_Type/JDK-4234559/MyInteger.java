
public class MyInteger extends Datum {
   public Datum operOne( MyInteger d  ) { ... }
   public Datum operTwo( MyInteger d  ) { ... }
}