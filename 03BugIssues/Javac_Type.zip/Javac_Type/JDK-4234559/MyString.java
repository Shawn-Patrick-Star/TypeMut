
public class MyString extends Datum {
   public Datum operOne( MyString d  ) { ... }
   public Datum operOne( MyInteger d ) { ... }
   public Datum operTwo( MyString d  ) { ... }
   public Datum operTwo( MyInteger d  ) { ... }
}