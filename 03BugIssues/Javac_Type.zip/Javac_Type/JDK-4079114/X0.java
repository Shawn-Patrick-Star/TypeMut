class X0
{
  void  test()
  {
    class Z extends A
    {
      class Y
      {
        int m=200;
        void test()
        {
          System.out.println(m);
          System.out.println(Z.this.m);
        }
      }
      Y y = new Y();
      int m=100;

      void test()
      {
        y.test();
      }
    }  //end of class Z
    Z z = new Z();
    z.test();
  }
  public  static  void  main(String[]  s)
  {
    X0  x  =  new  X0();
    x.test();
  }
}