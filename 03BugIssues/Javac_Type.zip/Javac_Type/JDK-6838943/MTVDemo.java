
public class MTVDemo {
    public static void main( String[] args ) {
	C< D<F> > cdf = new C< D<F> >();

	D<F> df;
	df = cdf.m( new D<F>(), new F(), true );

	// Exception in thread "main" java.lang.ClassCastException:
	// E cannot be cast to F
	F x = df.f;

	System.out.println("x: " + x);
    }
}