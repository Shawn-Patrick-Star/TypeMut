
public class C<T> extends A<Class<T>, Set<T>> {
    public void m(Class<?> c, Set<?> z) {
        System.out.println("C.m() invoked");
    }

    public static void main(String[] args) {
        new C<Integer>().m(null, null);
        new C<Integer>().m((Class<?>)null, (Set<?>)null);
    }
}