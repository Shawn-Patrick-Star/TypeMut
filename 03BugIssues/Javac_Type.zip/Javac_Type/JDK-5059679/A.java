import java.util.Set;

class A<U, V> {
    void m(U u, V v) {
        System.out.println("A.m() invoked");
    }
}