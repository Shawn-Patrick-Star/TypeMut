=========bug/Animal.java=======================

    package bug;

    public enum Animal {
      FROG;

      public interface FROG {}
    }

=========p/Imports.java==========================
   package p;

    import bug.Animal;
    import bug.Animal.FROG; //(1)
    import static bug.Animal.FROG;  //(2)

    public class Imports {
      public static void main(String[] args) {
        print(FROG);
      }

      static FROG print(Animal animal) {
        System.out.println(animal.name());
        return null;
      }
    }