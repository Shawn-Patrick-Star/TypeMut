import java.util.Collection;
import java.util.List;
import java.util.ArrayList;

public class Test
{
    public static <T> List<T> createEmptyL() {
        return new ArrayList<T>();
    }
    public static <T> Collection<T> createEmptyC() {
        return new ArrayList<T>();
    }
    public static <T> Iterable<T> createEmptyI() {
        return new ArrayList<T>();
    }
    public static void main(String[] args) {
        final List<String> lL = createEmptyL();
        final Collection<String> cL = (Collection<String>)createEmptyL();
        final Iterable<String> iL = (Iterable<String>)createEmptyL();
        final Collection<String> cC = createEmptyC();
        final Iterable<String> iC = (Iterable<String>)createEmptyC();
        final Iterable<String> iI = createEmptyI();

        final Collection<String> cL2 = createEmptyL();
        final Iterable<String> iC2 = createEmptyC();
    }
}