public class TestMain {

    public static interface A<T> {
        public void method(T param);
    }

    public static void main(String[] args) {
        final A<TestMain> anonClass = new A<TestMain>() {
            @Override
            public void method(TestMain param) {
            }
        };

        final A<TestMain> lambda = param -> {};

        // parameterized type from annon class
        final Type t = ((ParameterizedType)anonClass.getClass().
                getGenericInterfaces()[0]).getActualTypeArguments()[0];
        System.out.println("$  anon class generic type: " + t);

        System.out.println("$ anon clas   genericIface: " + anonClass.getClass().getGenericInterfaces()[0]);

        // parameterized type from lambda
        System.out.println("$ lambda expr generic type: " + "???");

        // -- lambda.getClass().getGenericInterfaces()[0]
        // does not contains type arguments any more
        System.out.println("$ lambda      genericIface: " + lambda.getClass().getGenericInterfaces()[0]);
    }
}