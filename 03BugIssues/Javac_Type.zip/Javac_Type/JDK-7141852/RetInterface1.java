I have source, but it is several interfaces.  Not sure how to attach it:

public interface RetInterface1{}
public interface RetInterface2 extends RetInterface1 {}
public interface TestInterface extends TestInterface1a, TestInterface2a, TestInterface3a{}
public interface TestInterface1a extends TestInterface1b{}
public interface TestInterface1b extends TestInterface1c
{
    RetInterface2 getObject();
}
public interface TestInterface1c
{
    RetInterface1 getObject();
}
public interface TestInterface2a extends TestInterface1b, TestInterface2b, TestInterface3b{}
public interface TestInterface2b extends TestInterface3c   // if you comment out this extends, it compiles fine
{
}
public interface TestInterface3a extends TestInterface3b{}
public interface TestInterface3b extends TestInterface3c
{
    RetInterface2 getObject();
}
public interface TestInterface3c
{
    RetInterface1 getObject();
}
public class TestClass
{
    public static void main(String[] args)
    {
        TestInterface testIntf = new TestInterface()
        {
            public RetInterface2 getObject()
            {
                return null;
            }
        };

        testIntf.getObject();
    }
}