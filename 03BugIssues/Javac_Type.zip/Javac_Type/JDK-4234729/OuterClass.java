> public class OuterClass {
>
>     class Parent2 extends Parent1 {
>
>         public void callFooBar(){
>             System.out.println(" Parent2 Foobar " +OuterClass.this);
>         }
>
>     }
>
>     public OuterClass() {
>
>         Parent2 p2 = new Parent2();
>     }
>
>     public static void main( String[] args ) {
>             OuterClass test1 = new OuterClass();
>
>     }
>
> }