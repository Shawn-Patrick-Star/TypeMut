

class Parent2 extends Parent1 {
            Parent2( OuterClass outer ) {
                outer.super();
            }
           public void callFooBar(){
               System.out.println(" Parent2 Foobar " +OuterClass.this);
           }

       }