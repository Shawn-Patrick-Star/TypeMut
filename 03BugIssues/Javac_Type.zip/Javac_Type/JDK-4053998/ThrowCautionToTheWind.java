
public class ThrowCautionToTheWind {
    public static void main (String[] args) {
    	Belch b = new BreakWind();
        b.throwCheckedException(); // pardon me
    }
}