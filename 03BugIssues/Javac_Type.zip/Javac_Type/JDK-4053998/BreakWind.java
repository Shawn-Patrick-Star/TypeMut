
class BreakWind extends Burp implements Belch {
}