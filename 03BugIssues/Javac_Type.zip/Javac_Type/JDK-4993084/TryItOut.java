public class TryItOut {
  public static void main(String[] args) {
    double ave = average(2,3, 4.5, 6, 7.8, 99, 56.3);
    System.out.println("Average is "+ave);
  }

  static double average(Object ... args) {
    double sum = 0.0;
    for(int i = 0 ; i<args.length ; i++) {
      if(args[i] instanceof Double) {
        sum += (Double)args[i];
      }
      if(args[i] instanceof Integer) {
        sum += (Integer)args[i];
      }
      if(args[i] instanceof Float) {
        sum += (Float)args[i];
      }
    }
    return sum/args.length;
  }
}