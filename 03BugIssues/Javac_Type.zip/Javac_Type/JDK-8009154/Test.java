
class Test {
    interface SAM<X> {
        void m(X ss, String s);
    }

    void m(String... s) { }

    public static void main(String[] args) {
        SAM<Test> st = Test::m;
        st.m(new Test(), "");
    }
}