package a;

public class CastTest {
	public interface BaseInterface<T> {

	} 
	
	public interface SubInterfaceA<T> extends BaseInterface<T> {

	}
	
	public interface SubInterfaceB<T> extends BaseInterface<T> {

	}
	
	public static void main(String[] args) {
		SubInterfaceA<String> a = null;
		SubInterfaceB<String> b = (SubInterfaceB<String>) a; // javac does not warn
		b = (SubInterfaceB<String>)(BaseInterface<String>)a;

	}
}