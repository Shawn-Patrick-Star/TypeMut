public class Increment
{
    public static void main(String[] args)
    {
        Integer vA = 0;
        Integer vB = vA++;
        Integer vC = ++vA;
        
        System.out.println("vA = " + vA);
        System.out.println("vB = " + vB);
        System.out.println("vC = " + vC);
    }
}