// Define the generic handler
public abstract class AbstractClass <H extends Handler >{

	private H parentHandler;
	
	public AbstractClass(H parentHandler) {
		super();
		this.parentHandler = parentHandler;
	}

	public H getHandler() {
		return parentHandler;
	}
}

//Call the generic handler
public class ConcreteClass extends AbstractClass<CustomHandler> {

	private Handler localHandler;
	
	public ConcreteClass() {
		//Define parentHandler
		super(new CustomHandler());
	}

	public void setLocalHandler(Handler handler){
		this.localHandler = handler;
	}
	
	public CustomHandler getForcedHandler() {
		//return the parent handler
		return getHandler();
	}
		
	public void check() {
		localHandler.handle(new Object());
	}	
}

@FunctionalInterface
public interface Handler {
	void handle(Object o);
}

public class CustomHandler implements Handler {
	@Override
	public void handle(Object o) {
		System.out.println("It works !");
	}
}

public class TestFailure {

	public static void main (String... arg){
		
		ConcreteClass cc  = new ConcreteClass();
		
		//Grab the parent handler  
                //                                        ^^^^^^^^^^^^^^
		cc.setLocalHandler(cc.getHandler()::handle);
		
		//Try to handle ==> fails
		cc.check();
		
	}
}

public class TestWorkaround {

	
	public static void main (String... arg){
			
		ConcreteClass cc  = new ConcreteClass();
		
		//Grab the parent handler
                //                                        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   
		cc.setLocalHandler(cc.getForcedHandler()::handle);
		
		//Try to handle ==> Success due to getForcedHandler() method with static type
		cc.check();
		
	}
}