public class main {
    public static Object test(Object x) {
        return x;
    }

    public static void main(String [] args) {
        System.out.println("result: " + (false == test(new Integer(1))));
    }
}