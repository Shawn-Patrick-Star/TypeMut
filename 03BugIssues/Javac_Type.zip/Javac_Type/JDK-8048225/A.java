    public static class A<V> {
        public List<String> getStrings() {
            return Arrays.asList("a", "b");
        }
    }