
public class Test {
    public static class A<V> {
        public List<String> getStrings() {
            return Arrays.asList("a", "b");
        }
    }

    public static void main(String[] args) {
        A a = new A();
        String s = a.getStrings().get(0);
    }
}