/**
 * VarArgTest.java
 *
 *
 * Created: Wed Nov 19 14:35:14 2003
 *
 * @author <a href="mailto: "</a>
 * @version
 */

public class VarArgTest{
  public VarArgTest (){
    
  }
  
  public static void varArg1(Object... args) {
    System.out.println("varArg1 called with " + args.length + " parameters.");
  }

  public static <ArgType> void varArg2(ArgType... args) {
    System.out.println("varArg2 called with " + args.length + " parameters.");
  }

  public static void main(String[] args){
    varArg1();
    varArg1("Foo");
    varArg1("Foo", 3);

    varArg2();
    varArg2("Foo");
    varArg2("Foo", 3);
  }


} // VarArgTest