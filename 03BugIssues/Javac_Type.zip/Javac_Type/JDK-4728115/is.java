 
//the following class is in the default package
 
public class Test {
    public static void main(String[] args) {
        new lib.C().show();
        new lib.C().test();
    }
}