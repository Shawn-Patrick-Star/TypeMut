 
package lib;
 
public class C extends pkg.B {
    void m1() { System.out.println("C1"); }
    int m2() { System.out.println("C2"); return 0; }
    private void m3() { System.out.println("C3"); }
 
    public void test() {
        ((A)this).m1();
        ((A)this).m2();
        ((A)this).m3();
    }
}