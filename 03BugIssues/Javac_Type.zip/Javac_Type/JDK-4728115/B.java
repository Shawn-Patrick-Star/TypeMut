 
package pkg;
 
public class B extends lib.A {
    void m1() { System.out.println("B1"); }
    void m2() { System.out.println("B2"); }
    void m3() { System.out.println("B3"); }
}