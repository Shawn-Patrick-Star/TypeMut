 
 
package lib;
 
public class A {
    public void show() { m1(); m2(); m3(); }
    void m1() { System.out.println("A1"); }
    void m2() { System.out.println("A2"); }
    void m3() { System.out.println("A3"); }
}