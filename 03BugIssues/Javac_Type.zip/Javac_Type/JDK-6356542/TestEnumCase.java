public class TestEnumCase
{
	enum Type { ONE, TWO, THREE };

	public static void main( String [] whatever )
	{
		 Type type = Type.TWO;
		
		switch( type )
		{
		case ( ONE ):
			System.out.println( "One" );
			break;
		case ( TWO ):
			System.out.println( "Two" );
			break;
		case ( THREE ):
			System.out.println( "Three" );
			break;
		}
	}
}