package test;
 
public class Test {
 
	public static void main(String[] args) {
		Byte B;
		final int fi = 0;
		B = fi; // narrowing pri. (int -> byte) + boxing (byte -> Byte)
	}
}