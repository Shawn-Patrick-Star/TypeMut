import java.lang.annotation.*;
import static java.lang.annotation.RetentionPolicy.*; 
import static java.lang.annotation.ElementType.*; 
import java.util.List; 
import java.util.ArrayList;

//case6:(repeating) type annotations on type parm in method reference.
class Test6{
    interface PrintString   { void    print(String s); }
    public void printArray(Object[] oa, PrintString ps) {
        for(Object o : oa ) ps.print(o.toString());
    }

    public void test() {
        Integer[] intarray = {1,2,3,4,5};
        printArray(intarray, TPrint::<@A String>print);               //okay
        printArray(intarray, TPrint::<@A @A String>print);        //no annotations in class file
        printArray(intarray, TPrint::<@A @A @B String>print); //okay
        printArray(intarray, TPrint::<@A @A @B @B String>print);        //no annotations in class file

    }

    public static void main(String... args) {new Test6().test(); }
}