public class Example {
	public static void main(String[] args) throws Exception {
		Supplier<Integer> s1 = new Supplier<Integer>() {
			@Override
			public Integer get(Integer t) {
				return t++;
			}
		};
		System.out.println("anonymous class returns: " + s1.get(0));

		Supplier<Integer> s2 = t -> t++;
		System.out.println("lambda returns: " + s2.get(0));
	}	
}

interface Supplier<T> {
	T get(T t);
}