package any;

import java.util.Optional;


/**
 *
 * @author Gerd Otto
 */
public class StrangeOptional 
{
	///////////////////////////////////////////////////////////////////////////
	// class hierarchy simplified to two classes with generic parameter
	// to illustrate the problem
	///////////////////////////////////////////////////////////////////////////
	static class ParentGen<T extends ParentGen<T>> {
		public Optional<Double> getValue() {
			return Optional.<Double>of(42.0);
		}
	}
	
	static class ChildGen extends ParentGen<ChildGen> {}
	
	///////////////////////////////////////////////////////////////////////////
	// class hierarchy without generic parameters .
	// the problem doesn't occur.
	///////////////////////////////////////////////////////////////////////////
	
	static class Parent {
		public Optional<Double> getValue() {
			return Optional.of(42.0);
		}
	}
	
	static class Child extends Parent {}
	

	public static void main(String[] args) {
		final Object og = new ParentGen().getValue().get();
		assert(og.getClass().equals(Double.class)) 
				: "assertion was java.lang.Double: "+og.getClass();
	//	final Double pg = new ParentGen().getValue().get(); // !!! DOES NOT COMPILE
		final Double cg = new ChildGen().getValue().get();

		final Object or = new Parent().getValue().get();
		assert(or.getClass().equals(Double.class)) 
				: "assertion was java.lang.Double: "+or.getClass();
		final Double pr = new Parent().getValue().get(); // !!! DOES COMPILE
		final Double cr = new ChildGen().getValue().get();
	}
}