    
    private class Test implements Cloneable, Interface2
    {
        private int m_junk = 0;
        
        public Object clone()
        {
            try
            {
                Test clone = ( Test )super.clone();
                clone.m_junk = m_junk;
                return( clone );
            }
            catch( CloneNotSupportedException xx )
            {
                throw new InternalError();
            }
        }
    }