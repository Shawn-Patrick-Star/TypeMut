//--------Program follows-----------------
public class BugTest
{
    public static void main( String[] args )
    {
        new BugTest().runTest();
    }
    
    public void runTest()
    {
        try
        {
            Interface2 a = new Test();
            Interface2 b = ( Interface2 )a.clone();
            System.out.println( "Success" );
        }
        catch( Throwable xx )
        {
            xx.printStackTrace();
        }
    }
    
    private interface Interface1
    {
        public Object clone();
    }
    
    private interface Interface2 extends Interface1
    {
    }
    
    private class Test implements Cloneable, Interface2
    {
        private int m_junk = 0;
        
        public Object clone()
        {
            try
            {
                Test clone = ( Test )super.clone();
                clone.m_junk = m_junk;
                return( clone );
            }
            catch( CloneNotSupportedException xx )
            {
                throw new InternalError();
            }
        }
    }
}