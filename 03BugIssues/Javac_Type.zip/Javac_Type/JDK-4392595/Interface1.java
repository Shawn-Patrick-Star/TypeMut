    
    private interface Interface1
    {
        public Object clone();
    }