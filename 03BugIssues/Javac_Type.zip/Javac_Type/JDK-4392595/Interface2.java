    
    private interface Interface2 extends Interface1
    {
    }