public class BridgeMyWorld {
    public final int compareTo(Object o) {
      return 0;
    }
    
    static class Oups extends BridgeMyWorld implements Comparable<Oups> {
        public int compareTo(Oups o) {
          return 0;
        }
    }
    
    
    public static void main(String[] args) {
        Oups oups=new Oups();
        
    }
}