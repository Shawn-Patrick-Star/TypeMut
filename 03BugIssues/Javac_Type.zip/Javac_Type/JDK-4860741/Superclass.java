Run OuterClass.main in the following two files:

Superclass.java:
================
package mypackage;

public class Superclass {
	protected void doStuff() {
		System.out.println("doing stuff");
	}
}

Outerclass.java
===============
package anotherpackage;

import mypackage.Superclass;

public class Outerclass extends Superclass {
	Innerclass innerclass = new Innerclass();

	private class Innerclass extends Superclass {
		InnermostClass innermostClass = new InnermostClass();

		private class InnermostClass {
			public void doAnything() {
				Outerclass.this.doStuff();
			}
		}
	}

	public static void main(String[] args) {
		new Outerclass();
	}
}