
import java.util.stream.IntStream;

public class Test {
    public static void main(String[] args) {
        IntStream.of(1, 2, 3, 4).sum();
    }
}