public class Hello {
    static class Foo<X> {}

    <X extends Throwable> Hello(Foo<X> foo) throws X {}

    public static void main(String[] args) throws Exception {
	new Hello(new Foo<Exception>());
    }
}