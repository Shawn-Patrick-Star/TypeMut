import java.util.List;
import java.util.Arrays;
import java.util.Comparator;

public class BugTest {
	public static void main(String[] args) {
		List<User> userList = Arrays.asList(new User("ZZZ"), 
		                                    new User("AAA"), 
											new User("BBB"));						
		userList.sort(Comparator.comparing(u -> u.getName()).reversed());
	}
}

class User { 
	private String name;	
	
	public User(String name) {
		this.name = name;		
	}
	
	public String getName() {
		return name;
	}
}