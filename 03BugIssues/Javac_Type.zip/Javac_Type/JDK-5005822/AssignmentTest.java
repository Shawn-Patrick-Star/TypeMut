import java.util.List;
import java.util.LinkedList;

/**
 * @author Patrick Jordan
 */
public class AssignmentTest {
	public static void main(String[] args) {
		List list = new LinkedList<Integer>();
		list.add("hi");
		list.add(1);

		for(int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
	}
}