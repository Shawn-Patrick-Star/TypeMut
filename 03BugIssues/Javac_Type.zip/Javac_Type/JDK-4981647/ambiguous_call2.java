public class ambiguous_call2
{
    public ambiguous_call2()    {    }

     public Integer add(Integer ... ints)    {
      System.out.println("Integers");
      return new Integer(0);
    }

    public Double add(Double ... dbls)    {
      System.out.println("Doubles");
      return new Double(0);
    }

   int test()
    {
      System.out.println("Call add with ints");
        Integer Isum = add(1,2,3,4,5,6,7,8,9,10);
        return 0;
    }

    public static void main(String[] args)
    {
        new ambiguous_call2().test();
    }
}