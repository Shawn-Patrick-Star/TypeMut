*/

public class CharArrayBug
{
        public static void
        main(String[] args)
        {
                // Initialization
                String s = "polymorph";
                char[] ca = {'i', 's', 'm'};

                // This concatenation goes wrong
                String concat  = s + ca;

                // Show it
                String concatA = s + ca.toString();
                String concatB = s + new String(ca);
                if (concat.equals(concatA))
                        System.out.println("Correct!");
                else if (concat.equals(concatB))
                        System.out.println("Bug!  (Expected in JDK 1.1.3.)");
                else
                        System.out.println("Unexpected bug!!");
        }
}