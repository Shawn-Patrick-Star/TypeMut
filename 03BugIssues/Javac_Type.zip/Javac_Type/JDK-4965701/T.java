
class T {
    public static void main(String[] args) {
        Integer i = 0;
        System.out.println(args[i]);
    }
}