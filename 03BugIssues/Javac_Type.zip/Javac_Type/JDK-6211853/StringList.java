--------Test.java--------
class StringList extends java.util.LinkedList<String> {
}

public class Test {
    public static void main(String[] args) {
        java.util.List<? extends String> a = new StringList();
        java.util.List<String> b = (StringList) a;      // warned but safe.
    }
}