import java.util.*;

public class Main {
  public static void main(String[] args) throws Exception {

    Object hashInputRule = new Object();
    Byte l = null;
    Byte rule = ((hashInputRule == null) ? ((byte) 0) : l);
  }
}