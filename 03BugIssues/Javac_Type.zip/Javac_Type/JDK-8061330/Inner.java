
    public class Inner {
        public Inner(List<String> s) {}
        public Inner(int i, List<String> s) {}
        public Inner(List<String> s, int i) {}
        public Inner(Set s) {}
        public Inner(int i) {}
    }