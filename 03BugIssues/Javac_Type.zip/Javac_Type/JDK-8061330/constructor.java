If inner class constructor has generics javac omits the first argument (ref to outer) in the signature attribute.


Consider the class:
==============
public class Outer {

    public class Inner {
        public Inner(List<String> s) {}
        public Inner(int i, List<String> s) {}
        public Inner(List<String> s, int i) {}
        public Inner(Set s) {}
        public Inner(int i) {}
    }

    public static void main(String[] args) {
        Class c = Inner.class;
        for (Constructor ctor : c.getDeclaredConstructors()) {
            Class[] tps = ctor.getParameterTypes();
            System.out.println("Parameter types: " + Arrays.toString(tps));
        }
    }
}