
public abstract class B implements A {

   public static void main(String[] args) {
      B b = new C();
      b.foo();
   }
}