the method "main" in class B is compiled such that the invokevirtual of method
foo() has a CONSTANT_Methodref with a class_index indicating class B.  Unlike
the JDK 1.3.1, the JDK 1.4.0_b65 doesn't place an abstract foo() method within
class B.  From class B's perspective, the method foo() exists only in the
Interface A that it implements.

Therfore, either class B should be given an abstract method foo() as is done in
the JDK 1.3.1 or the invokevirtual should be given a
CONSTANT_InterfaceMethodRef rather than a Constant_MethodRef. Otherwise, tools
that analyze classes statically will have a difficult time making sense of
class B when looking at just it, its superclasses and implemented interfaces.


=======================================================================
public interface A {
   void foo();
}