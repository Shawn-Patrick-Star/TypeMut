
public class C extends B {
   int a;

   public void foo() {
      a = 5;
   }
}