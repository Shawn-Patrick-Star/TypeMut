class O {
	public static void main(String[]args) {
		new O();
	}
	O() {
		f1().super(); // even if the value of f() would be trashed
			     // f() itself should be evaluated.(BUG)

		f2().staticField = 0; // f() evaluated correctly!!(OK)
	}

	static int staticField;
	static O f1() {
		System.out.println("f1() called!!");
		return null;
	}
	static O f2() {
		System.out.println("f2() called!!");
		return null;
	}
	static class Nested {}
}