import java.lang.invoke.*;

public class MHInvoke {

  interface TriFunction {
      Object apply(String a, char b, char c) throws Throwable;
  }

  public static void main(String... args) throws Throwable {
      MethodHandles.Lookup lookup = MethodHandles.lookup();
      MethodType mt = MethodType.methodType(String.class, char.class, char.class);
      MethodHandle ms = lookup.findVirtual(String.class, "replace", mt);

      System.out.println("result 1: " + ms.invoke("some string to search", 's', 'o'));
      
      TriFunction f1 = (a, b, c) -> ms.invoke(a,b,c);
      System.out.println("result 2: " + f1.apply("some string to search", 's', 'o'));
      
      TriFunction f2 = ms::invoke;
      System.out.println("result 3: " + f2.apply("some string to search", 's', 'o'));
  }
}