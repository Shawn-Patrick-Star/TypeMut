
class A {
    public static void main(String[] args) {
        System.out.println("test:"+(true&&true));
        boolean first = true;
        boolean second = true;
        System.out.println("test2:"+(first&&second));
        System.out.println("test3:"+first);
        System.out.println("test4:"+true);
    }
}