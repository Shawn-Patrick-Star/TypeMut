import java.util.Iterator;

public class Test {

	public void run() {
		MyClass myClass = new MyClass();
		for (OtherClass otherClass : myClass) {}
	}

	public static void main(String[] args) {
		Test t = new Test();
		t.run();
	}

}

class MyClass<O extends OtherClass> implements Iterable<O> {
	public Iterator<O> iterator() {
		return new Iterator<O>() {
			public boolean hasNext() {return false;}
			public O next() {return null;}
			public void remove() {}

		};
	}
}

class OtherClass {}