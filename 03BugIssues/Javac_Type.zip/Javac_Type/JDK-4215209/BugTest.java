
public class BugTest {

   public static void main(String[] args) {
      try {
         { // bad case
            One o = (One) Class.forName("Two").newInstance();

            System.out.println("value = " + o.value);           // prints 1
            System.out.println("getValue() = " + o.getValue()); // prints 2
         }
         { // good case
            Two x = new Two();
            One o = (One) x;
            System.out.println("value = " + o.value);           // prints 2
            System.out.println("getValue() = " + o.getValue()); // prints 2
         }
         }
      catch (Exception e) {
         System.out.println("exception: " + e);
      } // try
   } // main
}