
public class Foo
{
        public static void main(String [] parms)
        {
                Foo Bar = new Foo();
                String s = "";
                s += Bar.foobar();
        }

        public void foobar(){}
}