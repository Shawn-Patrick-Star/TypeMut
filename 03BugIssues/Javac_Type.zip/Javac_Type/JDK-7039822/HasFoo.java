+    private static interface HasFoo {
+        void foo();
+    }