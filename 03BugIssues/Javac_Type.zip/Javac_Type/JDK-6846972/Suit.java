import java.util.EnumMap;

enum Suit {
    CLUBS, DIAMONDS;
}