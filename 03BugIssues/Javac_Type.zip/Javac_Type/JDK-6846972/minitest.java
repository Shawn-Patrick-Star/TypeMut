
public class minitest {
    static Object [] array = {
        Suit.CLUBS, "value1",
        Suit.DIAMONDS, "value2"
    };

    public static void main(String[] args) {
        EnumMap map = new EnumMap(Suit.class);
        map.put(array[0], array[1]);
    }
}