----------------AccessBug.java-----------------
public class AccessBug {
   public static void main(String[] args) {
      new A3().test();
   }
}

class A1 {
   private int getI() {
      return 1;
   }
}

interface I1 {
   int getI();
}

abstract class A2 extends A1 implements I1 {
   public void test() {
      // I expect this should print "2". According to the
   	// JLS A1.getI() is "not inherited" by A2, so I guess
   	// it should not affect method resolution. Instead,
   	// an IllegalAccessError is thrown at runtime.
      System.out.println(getI());
   }
}

class A3 extends A2 {
   public int getI() {
      return 2;
   }
}
------------------------------------------