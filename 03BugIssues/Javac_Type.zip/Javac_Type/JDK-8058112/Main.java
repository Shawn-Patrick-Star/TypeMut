import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import static java.util.stream.Collectors.toList;

public class Main {


    public static void main(String[] args) {
        Main main = new Main();
        main.toInfoListError(Arrays.asList(new Base()));
    }

    public <H extends B & A> List<Info> toInfoListError(List<H> list) {
        Comparator<B> byNameComparator = (B b1, B b2) -> b1.getB().compareToIgnoreCase(b2.getB());
        return list.stream().sorted(byNameComparator).map(Info::new).collect(toList());
    }

    public <H extends B & A> List<Info> toInfoListWorks(List<H> list) {
        Comparator<B> byNameComparator = (B b1, B b2) -> b1.getB().compareToIgnoreCase(b2.getB());
        return list.stream().sorted(byNameComparator).map(s -> new Info(s)).collect(toList());
    }
}

interface B {
    public String getB();
}

interface A {
    public long getA();
}

class Info {

    private final long a;
    private final String b;

    <H extends A & B> Info(H h) {
        a = h.getA();
        b = h.getB();
    }
}

class Base implements A, B {

    @Override
    public long getA() {
        return 7L;
    }

    @Override
    public String getB() {
        return "hello";
    }
}