resulting .class file from either compiler causes the VM to throw a
VerifyError.  But if the two compilers were to take JLS 9.2 at face
value, rather than implementing the suggestions of the spec report, this
would be a compile-time error.

$ cat Blah.java
class Blah {
  public static void main(String[] args) {
    I.Inner.bar(new I(){});
  }
}