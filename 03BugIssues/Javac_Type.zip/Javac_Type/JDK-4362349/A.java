package secure;

public abstract class A {
  public static void main(String[] args) {
    A a = new C();
    System.out.println(a.message());
  }

  abstract String message();
}