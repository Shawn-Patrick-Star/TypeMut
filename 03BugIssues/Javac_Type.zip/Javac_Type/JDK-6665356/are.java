Compiler throws error for what seems to be a valid cast to a type in which both the qualifying type and inner class are parameterized. 

<code>
bash-3.00$ 
<code>
bash-3.00$ cat GenericOuter.java 
public class GenericOuter<S> {

    class GenericInner<T> extends LinkedList<T>{

    }
    public static void main(String...args){
       GenericOuter.GenericInner g1 = ( GenericOuter.GenericInner)new LinkedList<String>();
       GenericOuter<String>.GenericInner<String> g2 = ( GenericOuter<String>.GenericInner<String>)new LinkedList<String>(); //Compilation Error
    }

}