
    class foo
    {
      public static void main(String[] args)
      {
        String line = "abcd";
        StringBuffer sb = new StringBuffer();
        sb.append(line.subSequence(0, 2));
        System.out.println(sb.toString());
      }
    }