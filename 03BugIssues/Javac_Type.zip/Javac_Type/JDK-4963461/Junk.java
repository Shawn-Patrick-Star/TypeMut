
import static java.lang.annotation.VisibilityLevel.RUNTIME;
import java.lang.annotation.*;

@Foo(17) public class Junk {
    public static void main(String[] args) {
        System.out.println(Junk.class.getAnnotation(Foo.class).value());
    }
}