package test;

import java.util.*;

public class Test {
    public static void main(String[] args) {
        Map<String, Integer> m1 = new HashMap<String, Integer>();
        m1.put("foo", new Integer(1));
        m1.put("bar", 1);

        println("foo=", m1.get("foo"), " bar=", m1.get("bar"));
        println("primitives in varargs: int=", 42, " boolean=", true);

        // following line will not compile
        //int i = m1.get("nak");
//Boxing and unboxing conversions are currently only implemented as
//argument conversions.  It is almost certain that this is not what the
//JSR 201 expert group will specify.  When we have more guidance from
//JSR 201, we will update the prototype.

        wildcards();
        
    }

    public static void wildcards()
    {
        List<Number> src = new ArrayList<Number>();
        src.add(new Integer(1));
        src.add(new Double(2.0));

        List<Number> dest = new ArrayList<Number>();
        
        addAll_1(src, dest);
    }

    public static <E> void addAll_1(List<E> src, List<E> dest) {
        for(E o : src) {
            dest.add(o);
        }
    }
    
        
    

    public static void println(Object... objs) {
        for (int i = 0; i < objs.length; i++) {
            System.out.print(objs[i]);
        }
        System.out.println();
    }
}