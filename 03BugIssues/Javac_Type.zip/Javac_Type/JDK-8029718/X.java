
 public class X { 
     static void goo(J j) { 
         System.out.println("goo(J)"); 
     } 
     static void goo(I i) { 
         System.out.println("goo(I)"); 
     } 
     public static void main(String[] args) throws InterruptedException { 
        goo((x, y) -> { return x[0] += 1; }); // expected: print goo(I); actual: ambiguity error
     } 
 }