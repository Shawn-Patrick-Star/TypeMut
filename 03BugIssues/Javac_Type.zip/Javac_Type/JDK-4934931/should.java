/**
 *
 * This class  should not compile
 * <pre>
 * Reason :- This class will fail to compile  beacuse, this will tries
 * to convert  <b>null</b> value to primitive object wrapper.
 *  </pre>
 * 
 */
public class ErrorCondition1 {

        public static void main(String[] args) {
                Integer inte= null;
                int no =90;
                no = inte;
        }
}