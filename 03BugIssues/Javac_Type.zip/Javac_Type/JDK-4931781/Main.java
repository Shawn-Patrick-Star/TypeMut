     4  class Main {
     5      public static void main(String[] args) {
     6          Box<? extends Integer> bi = null;
     7          int i = bi.get();
     8      }
     9  }