import java.util.*;

public class Test{
    public static void main(String[] test){
        boolean flag = test.length % 2 == 0;
        Set<String> other = Collections.singleton("Test");

        //This compiles fine:
        print(flag ? other : Test.<String> genericMethod());

        //This failes to compile:
        print((flag ? null : Test.<String> genericMethod()));
        
        //This failes to compile:
        Set<String> res = (flag ? Test.<String> genericMethod() : other);
    }

    @SuppressWarnings({"unchecked"})
    public static <T> Set<T> genericMethod(){
        return (Set) new HashSet();
    }
    
    public static void print(Set<String> arg){
        System.out.println(arg);
    }
}