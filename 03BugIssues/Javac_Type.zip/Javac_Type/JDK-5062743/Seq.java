/**
 */
public class Seq<T>
{
    T _head;
    Seq<T> _tail;

    Seq() {}
    Seq(T head, Seq<T> tail) {
        _head = head;
        _tail = tail;
    }

    static <T> Seq<T> nil() {
        return new Seq<T>();
    }
    static <T> Seq<T> cons(T x, Seq<T> xs) {
        return new Seq<T>(x, xs);
    }

    public static void main(String[] args) {
        Seq<String> ss = nil();
        boolean b = false;
        foo(b ? ss : nil());
    }

    public static void foo(Seq<String> ss) {}

}