
class bottom extends tmp.pack1.temp
  {
    void myMethod ()
    	{
    	anotherMethod ();
    	}

    public static void main (String [] argv) {
        bottom    o_temp = new bottom ();
        o_temp.myMethod ();
    }
  }