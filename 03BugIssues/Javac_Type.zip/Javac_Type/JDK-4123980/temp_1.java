

//file: tmp/pack1/temp.java
package tmp.pack1;

public class temp extends tmp.temp  {
 }