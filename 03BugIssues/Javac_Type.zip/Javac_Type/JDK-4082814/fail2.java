public class fail2 {
    public static void main(String[] args) {
	if ((1L << 2) != 4) {
	    System.out.println("hello");
	}
    }
}