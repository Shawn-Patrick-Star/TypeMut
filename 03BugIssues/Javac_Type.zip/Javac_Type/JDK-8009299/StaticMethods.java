
public class StaticMethods {
    private interface SuperInterface {
        public static Object f(Object arg) { return null; }
    }
    public static void main(String... args) {
        Function<Object,Object> methodReference9
                  = SuperInterface::f;   // compiler crash
    }
}