    private interface SuperInterface {
        public static Object f(Object arg) { return null; }
    }