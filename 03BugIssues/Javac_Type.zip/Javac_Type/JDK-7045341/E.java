
static class E implements C<String> {
 Box<String> b;
 public Box<String> get() { return b; }
 public void set(Box<String> arg) { b = arg; }
}