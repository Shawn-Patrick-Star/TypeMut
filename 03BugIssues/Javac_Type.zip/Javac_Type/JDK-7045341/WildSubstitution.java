
public class WildSubstitution {

static class Box<T> {
 private T val;
 public Box(T val) { this.val = val; }
 public T get() { return val; }
 public void set(T val) { this.val = val; }
}

interface A<T> { T get(); void set(T arg); }
interface B<T> extends A<T> {}
interface C<S> extends A<Box<S>> {}

static class D implements B<String> {
 String s;
 public String get() { return s; }
 public void set(String s) { this.s = s; }
}

static class E implements C<String> {
 Box<String> b;
 public Box<String> get() { return b; }
 public void set(Box<String> arg) { b = arg; }
}

public static void main(String... args) {
 // B<?> <: A<?> is true
 Box<D> b1 = new Box<D>(new D());
 Box<? extends B<?>> b2 = b1;
 Box<? extends A<?>> b3 = b2;

 // C<?> <: A<Box<?>> is false
 Box<E> b4 = new Box<E>(new E());
 Box<? extends C<?>> b5 = b4;
 Box<? extends A<Box<?>>> b6 = b5;

 b6.get().set(new Box<Integer>(10));
 String s = b4.get().get().get();
}

}