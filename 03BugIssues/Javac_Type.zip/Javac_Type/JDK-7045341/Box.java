
static class Box<T> {
 private T val;
 public Box(T val) { this.val = val; }
 public T get() { return val; }
 public void set(T val) { this.val = val; }
}