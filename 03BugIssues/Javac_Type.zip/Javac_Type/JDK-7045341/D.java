
static class D implements B<String> {
 String s;
 public String get() { return s; }
 public void set(String s) { this.s = s; }
}