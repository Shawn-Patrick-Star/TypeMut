import java.util.Arrays;
import java.util.Comparator;

public class TestBug {

    public static void main(String[] args) {
        Integer[] ints = {1, 2, 3, 4};

        // Error occurs here
        Arrays.sort(ints, Comparator.comparing((Integer i) -> i).reversed());

        for(int i: ints) {
            System.out.println(i);
        }
    }

}