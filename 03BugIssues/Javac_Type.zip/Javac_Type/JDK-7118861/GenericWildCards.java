public class GenericWildCards
{
	public static void main(String[] args)
	{
		Number[] x = {10,20,30,40,50};
		Number[] y = {10.0,20.0,30.0,40.0,50.0};
		WildDemo<Number> wi = new WildDemo<Number>();
		WildDemo<Number> wi1= new WildDemo<Number>();
		wi.setWD(x);
		wi1.setWD(y);
		System.out.print("Equals: "+ wi.compareAvg(wi1));
	}
}