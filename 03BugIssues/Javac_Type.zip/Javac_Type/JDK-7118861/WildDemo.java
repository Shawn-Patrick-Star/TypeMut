
/////////////////      You can Find it in this Program    ////////////////
class WildDemo<T extends Number>
{	
	T[] a;
	void setWD(T[] a)  { this.a = a;  }
	
	double getAvg()
	{
		double tot=0.0;
		for(int i=0; i<a.length; i++)
		{
			tot+= a[i].doubleValue();
		}
		return tot/a.length;
	}
	
	boolean compareAvg(WildDemo<T> b)
	{
		return getAvg() == b.getAvg();
	}
}