public class test {
   public static void main( String[] argv ) {
      int i = byte[].length;
   } 
}