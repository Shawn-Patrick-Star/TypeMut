import java.util.Collection;

public class Main {
	@SuppressWarnings("unchecked")
	public static <U extends B>U get() {
		return (U)new B();
	}

	public static void main(String[] args) {
		A<B> a = new A<>(get());
	}

	static class A<T> {
		A(Collection<? extends T> lst) {
			System.out.println("Bad constructor");
		}
		A(T e) {
			System.out.println("ok");
		}
	}

	static class B {
	}
}