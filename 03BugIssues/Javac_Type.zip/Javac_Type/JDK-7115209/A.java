class A {
	void m1(boolean flag, Object...args) {
	  System.out.println("boolean wins!");
	}
	void m1(Object...args) {
	  System.out.println("DEFAULT");
	}
}

public class B {
	public static void main(String[] args) {
		A a = new A();
		a.m1(true, "A", new Integer(100), null);
	}
}