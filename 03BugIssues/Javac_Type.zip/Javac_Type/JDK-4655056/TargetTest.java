public class TargetTest {
    
  public static void main(String[] args) {
    StringBuffer test = new StringBuffer("aa");
    StringBuffer result = new StringBuffer("result");
    result.append(test);
    System.out.println(result.toString());
  }
}