public class Test {
	
	interface A {
		B m(int a, int b);
	}
	
	interface C {
		String m(int a, int b);
	}
	
	interface B {
		int m(int c);
	}
	
	public static void method(A a) {
		System.out.println("Method 1");
	}
	public static void method(C c) {
		System.out.println("Method 2");
	}
	
	public static void main(String[] args) {
		// This succeeds
		method((int a, int b) -> {
			if(a < b)
				return c -> a + b + c;
			else
				return c -> a + b + c;
		});
		
		/*But this fails (as expected)
		method((int a, int b) -> {
			return c -> a + b + c;	
		});*/		
    }
}