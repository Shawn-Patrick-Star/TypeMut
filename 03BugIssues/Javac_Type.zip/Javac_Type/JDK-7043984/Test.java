public class Test
{
    public static void main(String[] args)
    {
        new Test().error("", new Exception());
    }

    void error(Object message_, Throwable throwable_, Object... params_)
    {
    }

    void error(Object message_, Object... params_)
    {
    }
}