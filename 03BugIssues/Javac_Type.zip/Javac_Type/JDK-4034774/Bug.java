import A.B;

class Bug {
  public static void main(String[] args) {
    int c = B.aFinalVariable;

    B b1 = new B(0);

    B b2 = new B(B.aFinalVariable); 
  }
}