package A;

public class B {
  public final static int aFinalVariable = 0;

  public B(int a) {
    // if you comment away the next line there will be no errors!
    Object c = new Object() {};
  }
}