class Test {
   public static void main(String[] args) {
       new Subclass().test(0);
   }
 }
class Superclass {
   static void test(int i) {
      System.out.println("test(int i)");
   }
}
class Subclass extends Superclass {
   static void test(long l) {
      System.out.println("test(long l)");
   }
}
//This program compiles and when executed prints test(int i).