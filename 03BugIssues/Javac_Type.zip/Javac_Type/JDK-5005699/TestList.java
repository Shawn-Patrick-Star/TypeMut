public class TestList {
    class MyStringTokenizer extends StringTokenizer
        implements Iterable<String>
    {
        public MyStringTokenizer(String doc, String delim, boolean r) {
            super(doc, delim, r);
        }
		
        class MyStringIterator<String> implements Iterator<String> {
            public boolean hasNext() {
                return hasMoreTokens();
            }
			
           // GET THE COMPILER ERROR HERE !!!!
           public String next() {
                return nextToken();
            }
			
            public void remove() {
            }
			
        }
		
        public Iterator<String> iterator() {
            return new MyStringIterator<String>();
        }
    }

    public static void main(String[] args) {
        TestList list = new TestList();
        System.out.println(list.getFrequencyMap("test for a test"));
    }
	
    public Map<String, Integer> getFrequencyMap(String doc)  {
        Map<String,Integer> map = new TreeMap<String,Integer>();
        
        for (String word : new MyStringTokenizer(doc, " ,.", false))  {
            Integer freq = map.get( word );
            map.put( word, freq == null ? 1 : freq + 1 );
        }
		
        return map;
     }
}