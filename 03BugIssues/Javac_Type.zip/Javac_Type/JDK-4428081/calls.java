
When a sub class' inner class calls super, the virtual machine throws a
NoSuchMethodException. Here's the scenario.

=================== In file A.java =====================
public class A {
    pubilc void init() {
        System.out.println("I'm here");
    }
}