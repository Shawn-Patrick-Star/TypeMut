
    protected interface X {
        public void init();
    }