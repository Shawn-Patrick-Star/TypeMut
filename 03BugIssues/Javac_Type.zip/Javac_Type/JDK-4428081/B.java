public class B extends A {
    private Y y;

    public B() {
        y = new Y();
    }

    protected interface X {
        public void init();
    }

    protected class Y implements X {
        public void init() {
            B.super.init();
        }
    }

    public void init() {
        y.init();
    }

    public static void main(String[] args) {
        B me = new B();
        me.init();
    }
}