public class CompilerCrash {
    
    //dummy method1
    public static <T> T crash(T t1, T t2) {
        return t1;
    }
    
    //dummy method2
    public static <T> T noCrash(T t1) {
        return t1;
    }
    
    public static void main(String ...args) {
        Generic<?> g1 = new Generic<String>("crash");
        Generic<?> g2 = new Generic<String>("me");
        
        noCrash(g2);    // no crash
        crash(g1,g2);    // crash!!!
    }
}

//dummy interface
interface myInterface<T> {    }

// Note: crashes with "myInterface<Generic<? super T>>", as well.
class Generic<T> implements myInterface<Generic<? extends T>> {
    public Generic(T s) {   }
}