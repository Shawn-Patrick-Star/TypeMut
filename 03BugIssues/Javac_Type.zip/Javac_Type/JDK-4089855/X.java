
class X{
  public static void main( String[] argv ) {
    int i0 =   2147483647;
    int i1 =  -2147483648;
    int i2 =   2147483648;
    int i3 =  10000000000;
    int i4 = -10000000000;
    long l0 =   9223372036854775807L;
    long l1 =  -9223372036854775808L;
    long l2 =   9223372036854775808L;
    long l3 =  10000000000000000000L;
    long l4 = -10000000000000000000L;
  }
}