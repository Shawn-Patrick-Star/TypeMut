import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Foo {
    public static void main(String[] args) {
        boolean b = contains(
                buildList(new SomeComparator<String>("bar")),
                new SomeComparator<String>("x"));
        System.out.println(b);
    }

    public static <T> boolean contains(List<T> objects, T  customer ) {
        return objects.contains( customer );
    }

    public static <T> List<Comparator<? super T>> buildList(Comparator<? super T>... comparator) {
        return Arrays.asList(comparator);
    }

    private static class SomeComparator<T> implements Comparator<T> {
        public SomeComparator(T arg) {}
        public int compare(T o1, T o2) { return 0; }
    }
}