public class Test {
	public static void main(String[] args) {
		Object x = "A";
		String i = "B";
		x += i;
	}
}