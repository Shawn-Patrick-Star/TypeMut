     3  class Test3 {
     4   static class ListHolder<T> {
     5     final List<T> list = new ArrayList<T>();
     6
     7     class Inserter {
     8       Inserter(T itemToAdd) {
     9         list.add(itemToAdd);
    10       }
    11     }
    12   }
    13
    14   static class StringListHolder extends ListHolder<String> {
    15     class IntInserter extends ListHolder<Integer>.Inserter {
    16       IntInserter() {
    17         super(42);
    18       }
    19     }
    20   }
    21
    22   public void testInnerClassWithMismatchedOuterType() {
    23     StringListHolder list = new StringListHolder();
    24     list.new IntInserter();
    25
    26     System.out.println(list.list.get(0).length());
    27   }
    28
    29    public static void main(String... args) {
    30      new Test3().testInnerClassWithMismatchedOuterType();
    31    }
    32  }