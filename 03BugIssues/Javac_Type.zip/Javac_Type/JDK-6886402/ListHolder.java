     4   static class ListHolder<T> {
     5     final List<T> list = new ArrayList<T>();
     6
     7     class Inserter {
     8       Inserter(T itemToAdd) {
     9         list.add(itemToAdd);
    10       }
    11     }
    12   }