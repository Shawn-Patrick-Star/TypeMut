    14   static class StringListHolder extends ListHolder<String> {
    15     class IntInserter extends ListHolder<Integer>.Inserter {
    16       IntInserter() {
    17         super(42);
    18       }
    19     }
    20   }