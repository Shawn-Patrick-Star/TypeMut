
@Retention(RUNTIME) @Target({TYPE_USE,FIELD}) @interface A { } 

class Test7{
    interface MapFun<T, R> {  R m( T n); }
    MapFun<Class<?>,String> cs;
    void test() {
        cs = c -> {
                 class innerClass   {
                     @A Class<?> icc = null;
                     innerClass(Class<?> _c) { icc = _c; }
                     String getString() { return icc.toString(); }
                 }
                 return new innerClass(c).getString();
        };
        System.out.println("cs.m : " + cs.m(Integer.class));
    }

    public static void main(String... args) {new Test7().test(); }
}