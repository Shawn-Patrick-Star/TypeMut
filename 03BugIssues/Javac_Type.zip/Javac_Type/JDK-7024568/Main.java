

package pkg196134;

public class Main {

    public static void main(String[] args) {
        Obj o = null;
        o.test(0, 0, 0, 0, 0, 0, 0, 0, undefined);
    }
}