
public class MyClassC {

   public String toString() {
      return "MyClassC";
   }

}