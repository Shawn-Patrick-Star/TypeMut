
public class MyClassB {

   public void myMethod(String s) {
      System.out.println(s);
   }

   public void myMethod(char[] c) {
      System.out.println(c);
   }

   public void myMethod(MyClassC m) {
      System.out.println(m);
   }

}