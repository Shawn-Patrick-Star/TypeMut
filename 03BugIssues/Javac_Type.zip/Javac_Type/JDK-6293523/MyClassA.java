public class MyClassA {

   public static void main(String[] args) {
      MyClassB myObjectB = new MyClassB();
      myObjectB.myMethod(new char[] {'S', 't', 'r', 'i', 'n', 'g'});
   }

}