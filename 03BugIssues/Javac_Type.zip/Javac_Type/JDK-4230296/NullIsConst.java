// JLS vs Java2
// null is a Compile Time Constant
// added to 15.27.


class NullIsConst {
	public static void main(String[] args) {
		switch (args.length) {
		case null == "" ? 1 : 2:
			;
		}
	}
}