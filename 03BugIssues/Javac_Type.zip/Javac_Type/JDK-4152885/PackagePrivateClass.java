
//
// PackagePrivateClass.java
//
package pkg1;

/**
 * A package-private class
 */
class PackagePrivateClass
{
  private String str;

  public PackagePrivateClass(String str)
  {
    this.str = str;
  }

  public void printStr()
  {
    System.out.println(str);
  }
}