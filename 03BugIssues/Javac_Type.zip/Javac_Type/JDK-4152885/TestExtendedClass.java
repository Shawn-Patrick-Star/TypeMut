
//
//TestExtendedClass.java
//
package pkg2;

import pkg1.*;

public class TestExtendedClass
{
  private ExtendedClass ec;

  public TestExtendedClass(String str)
  {
   // Instantiate a new ExtendedClass object
   ec = new ExtendedClass(str);

   // Call the method printStr() that Extended Class
   // inherits from the PackagePrivateClass
   ec.printStr();
  }

  public static void main(String[] args)
  {
    TestExtendedClass test =
      new TestExtendedClass("Testing Extended Class");
  }
}