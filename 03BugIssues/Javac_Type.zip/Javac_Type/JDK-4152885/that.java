
//
//ExtendedClass.java
//
package pkg1;

/**
 * Public class that extends a package-private class
 */
public class ExtendedClass extends PackagePrivateClass
{
  public ExtendedClass(String str)
  {
    super(str);
  }
}