
import java.util.*;

public class rr {
    public static void main(String[] args) throws Throwable {
	List<?> x1 = new ArrayList<Integer>();
	List<?> x2 = new ArrayList<Integer>();
	x1.addAll(x2);
    }
}