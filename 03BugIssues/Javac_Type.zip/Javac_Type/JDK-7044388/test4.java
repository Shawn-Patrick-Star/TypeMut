
public class test4 {
    public int foo(int ... vai)   { return 1; }
    public int foo(Object ... vaO) { return 2; }

    //TEST: choose best of overloaded methods
    public int test()    {
        int i1 = 1;
        int i2 = 2;
        int ret = foo(i1,i2);  //should choose method 1
        return ret;
    }

    public static void main(String[] args)    {
      test4 tv = new test4();
      System.out.println( tv.test()==1?"PASS":"FAIL" );
    }
}