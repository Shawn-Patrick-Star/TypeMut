import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
public class TestAnnoDefault {
    public static void main(String[] args) {
        Holder h = C.class.getAnnotation(Holder.class);
        System.err.println("h=" + h);
        Child c = h.child();
        System.err.println("h.child=" + c);
        System.err.println("h.child.attr=" + c.attr());
    }
    @Retention(RetentionPolicy.RUNTIME)
    public @interface Holder {
        Child child() default @Child;
    }
    public @interface Child {
        String attr();
    }
    @Holder
    public class C {}
}