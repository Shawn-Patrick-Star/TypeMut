public class Test {
    public static void main(String... args) throws Exception {
        System.out.println(String.valueOf(getNum()));
    }
    
    private static <T> T getNum(){
        Integer i = 123;
        return (T)i;
    }
}