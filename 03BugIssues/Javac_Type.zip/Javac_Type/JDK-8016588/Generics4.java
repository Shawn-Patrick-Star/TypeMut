
public interface Generics4<D extends Generics4<D>> {

    static void foo1() {
        // Why does this compile? The left and right types are incompatible
        String x = now1();
    }

    static <D extends Generics4<D>> D now1() {
        return null;
    }

    public static void main(String[] args) {
        foo1();
    }

}
