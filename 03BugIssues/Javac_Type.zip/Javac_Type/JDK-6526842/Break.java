public class Break {
	public static void main(String[] args) {
		Ebbp<A,Box<Box<A>>> realFrom = new Ebbp<A,Box<Box<A>>>(new Box<Box<A>>(new Box<A>(new A())));
		caster(realFrom).q.p = new Box<B>(new B());
		A a = realFrom.q.p.p;
	}
	
	static Ebbp<?,? extends Box<Box<?>>> caster(Ebbp<?,?> from) {
		Box<Ebbp<?,?>> boxedFrom = new Box<Ebbp<?,?>>(from);
		Box<? extends Ebbp<?,? extends Box<Box<?>>>> boxedTo = boxedFrom;
		return boxedTo.p;
	}
}

class Box<P> {
	P p;
	Box(P p) {this.p = p;}
}

class Ebbp<P, Q extends Box<Box<P>>> {
	Q q;
	Ebbp(Q q) {this.q = q;}
}

class A {}
class B {}