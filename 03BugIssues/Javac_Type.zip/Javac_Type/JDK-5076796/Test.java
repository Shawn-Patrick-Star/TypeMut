public class Test {

        public Test() {
        }

        public void foo(String foo) {
                System.out.println("String");
        }

        public void foo(Object foo) {
                System.out.println("Object");
        }

        public static void main(String[] args) {
                Test t = new Test();
                t.foo(null);
        }

}