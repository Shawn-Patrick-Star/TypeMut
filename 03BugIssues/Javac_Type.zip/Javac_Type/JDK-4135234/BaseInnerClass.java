    protected class BaseInnerClass {
	public String getWorld() { return "World"; }
    }