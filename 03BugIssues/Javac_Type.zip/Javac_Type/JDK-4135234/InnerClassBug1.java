
// File InnerClassBug1.java

package p1;

public class InnerClassBug1 {
    protected class BaseInnerClass {
	public String getWorld() { return "World"; }
    }
}