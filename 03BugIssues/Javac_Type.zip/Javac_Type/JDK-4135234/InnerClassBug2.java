

// File InnerClassBug2.java

package p2;

public class InnerClassBug2 extends p1.InnerClassBug1
{  
    class ExtendedInnerClass extends BaseInnerClass {
	String getHelloWorld() { return "Hello " + getWorld(); }
    }

    ExtendedInnerClass eicObject = new ExtendedInnerClass();

    public static void main(String[] args) {
	System.out.println(new InnerClassBug2().eicObject.getHelloWorld());
    }
}