public class Bug
{
    public static void main(String[] args)
    {
        System.out.println(A.class);
    }
}
class A
{
    static final boolean FLAG = false;
    static final B obj = !FLAG ? null : new B() {};
}
class B
{
}