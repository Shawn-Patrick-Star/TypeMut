package com.foo;

public class PrimitiveTypeInferenceTest {
    public static void main(String[] args) {
        Integer i1 = getValue();
        int i2 = getValue();
        
        Float f1 = getValue();
        float f2 = getValue();
    }

    @SuppressWarnings("unchecked")
    public static <T> T getValue() {
        Object o = 0;
        return (T)o;
    }
}