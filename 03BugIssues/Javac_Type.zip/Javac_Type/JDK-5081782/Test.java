
class Test {
    static void m() {}
    public static void main(String... args) {
        Test.<Can,I,write,a,little,story,here>m();
    }
}