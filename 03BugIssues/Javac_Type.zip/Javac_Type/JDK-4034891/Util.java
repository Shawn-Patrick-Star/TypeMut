   package test;

   public class Util {
      interface Foo {
      }

      public static void message() {
         Foo pFoo = new Foo() {
            public void foo() {
            }
         };
      }
   }