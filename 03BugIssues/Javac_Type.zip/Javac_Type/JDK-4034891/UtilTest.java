   package test;

   public class UtilTest {
      public static void main(String[] asArg) {
		   Util.message();
         Util.message();
      }
   }