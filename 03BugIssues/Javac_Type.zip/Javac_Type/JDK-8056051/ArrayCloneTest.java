import java.util.Arrays;
import java.util.function.Function;
import java.util.function.Supplier;

public class ArrayCloneTest {
    public static void main(String[] args) {
        int[] intArgs = Arrays.stream(args).mapToInt(Integer::parseInt).toArray();
        printInt("int[]::clone", int[]::clone, intArgs);
        printInt("a -> a.clone()", a -> a.clone(), intArgs);
        printInt("intArgs::clone", intArgs::clone);

        printString("String[]::clone", String[]::clone, args);
        printString("a -> a.clone()", a -> a.clone(), args);
        printString("args::clone", args::clone);
    }

    private static void print(String label, Supplier<?> s) {
        try {
            System.out.printf("%s => %s%n", label, s.get());
        } catch (Throwable t) {
            System.err.printf("%s =!> %s%n", label, t);
            t.printStackTrace();
        }
    }

    private static void printInt(String label, Supplier<int[]> s) {
        print(label, () -> Arrays.toString(s.get()));
    }

    private static void printInt(String label, Function<int[], int[]> f, int[] a) {
        printInt(label, () -> f.apply(a));
    }

    private static void printString(String label, Supplier<String[]> s) {
        print(label, () -> Arrays.toString(s.get()));
    }

    private static void printString(String label, Function<String[], String[]> f, String[] a) {
        printString(label, () -> f.apply(a));
    }
}