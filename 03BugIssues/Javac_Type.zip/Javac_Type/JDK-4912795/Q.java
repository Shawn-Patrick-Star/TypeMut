
    import java.util.AbstractCollection;
    import java.util.Collection;
    import java.util.Iterator;

    interface Q<E> extends Collection<E> {}