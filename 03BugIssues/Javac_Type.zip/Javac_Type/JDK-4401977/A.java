     6	    public class A extends AS {
     7		class Inner {
     8		    void test() {
     9			A.super.o();
    10		    }
    11		}
    12		A() {
    13		    Inner i = new Inner();
    14		    i.test();
    15		}
    16	    }