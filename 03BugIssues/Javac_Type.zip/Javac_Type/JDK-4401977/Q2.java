     5	public class Q2 {
     6	    public class A extends AS {
     7		class Inner {
     8		    void test() {
     9			A.super.o();
    10		    }
    11		}
    12		A() {
    13		    Inner i = new Inner();
    14		    i.test();
    15		}
    16	    }
    17	    
    18	    public static void main(String[] args) {
    19		A a = new Q2().new A();
    20	    }
    21	}