import java.util.List;

public class Sample {
    static  Complicated complicated;
    public static void main(String[] args) throws Exception {
        complicated = new Complicated();
        complicated.list1.addAll(complicated.list2);
        complicated.list3.containsAll(complicated.list4);
        complicated.list5.retainAll(complicated.list6);
        complicated.list7.remove(complicated.publicStaticFinalIntConstant);
        complicated.packagePrivateConstant = complicated.packagePrivateFinalConstant;
        complicated.protectedMethod(complicated.list3);
        complicated.publicMethod(complicated.list1);
        complicated.packagePrivateMethod(complicated.map,complicated.list1);
    }
    static List<String> l1 =  complicated.list1;
    static List<String> l2 =  complicated.list2;
    static List<String> l3 =  complicated.list3;
    static List<String> l4 =  complicated.list4;
    static List<String> l5 =  complicated.list5;
    static List<String> l6 =  complicated.list6;
    static List<String> l7 =  complicated.list7;
    static int i = complicated.protectedMethod(complicated.list1);
}
