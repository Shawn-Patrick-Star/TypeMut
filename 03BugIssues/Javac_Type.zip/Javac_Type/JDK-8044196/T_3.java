
import java.lang.reflect.*;
import java.lang.annotation.*;

@Target({ElementType.TYPE_PARAMETER, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(TC.class)
@interface T { int value(); }

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@interface TC { T[] value(); }