
    public class C<@T(1) @T(2) N> {}