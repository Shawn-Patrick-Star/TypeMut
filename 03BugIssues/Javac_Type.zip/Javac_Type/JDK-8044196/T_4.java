
import java.lang.reflect.*;
import java.lang.annotation.*;

@Target({ElementType.TYPE_PARAMETER, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(TC.class)
@interface T { int value(); }

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@interface TC { T[] value(); }

public class RepAnno {

    public class C1<@T(1) N> {}
    public class C2<@T(1) @T(2) N> {}

    public static void main(String[] args) {

        Class<RepAnno> cl = RepAnno.class;
        Class<?>[] cs = cl.getDeclaredClasses();

        for (Class<?> c : cs) {
            System.out.println("Class: " + c);
            TypeVariable<?>[] tvs = c.getTypeParameters();
            for (TypeVariable<?> tv : tvs) {
                System.out.println("    T: " + tv.isAnnotationPresent(T.class));
                System.out.println("    TC: " + tv.isAnnotationPresent(TC.class));
            }
        }
    }
}