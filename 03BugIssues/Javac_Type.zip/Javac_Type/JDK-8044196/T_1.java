import java.lang.reflect.*;
import java.lang.annotation.*;

@Target({ElementType.TYPE_PARAMETER, ElementType.METHOD})
@Repeatable(TC.class)
@interface T { int value(); }

@Target(ElementType.METHOD)
@interface TC { T[] value(); }

public class RepAnno {

    public class C<@T(1) @T(2) N> {}

}