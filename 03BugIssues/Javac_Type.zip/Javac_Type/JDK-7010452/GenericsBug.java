import java.util.Comparator;

public class GenericsBug {
  
  public static void main(String[] args) {
    Comparator<String> s = new Comparator<String>() {
      public int compare(String a, String b) {
        return a.compareToIgnoreCase(b);
      }
    };
    Comparator<Object> o = new Comparator<Object>() {
      public int compare(Object a, Object b) {
        return a.hashCode() - b.hashCode();
      }
    };
    Comparator<Boolean> c = GenericsBug.compose(s, o);
    c.compare(Boolean.TRUE, Boolean.FALSE);
  }
  
  public static <T> Comparator<T> compose(final Comparator<? super T> c0,
                                          final Comparator<? super T> c1) {
    return new Comparator<T>() {
      public int compare(T a, T b) {
        int comparison = c0.compare(a, b);
        return (comparison != 0) ? comparison : c1.compare(a, b);
      }
    };
  }
  
}