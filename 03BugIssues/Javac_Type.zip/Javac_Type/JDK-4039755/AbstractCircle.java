
abstract class AbstractCircle {}