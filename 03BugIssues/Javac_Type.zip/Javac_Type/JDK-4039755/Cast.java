    
public class Cast {
    Cast(AbstractCircle x) {}

    public static void main(String[] args) {
	Circle circle = new Circle();
	Cast cast = new Cast((AbstractCircle)circle);
    }
}