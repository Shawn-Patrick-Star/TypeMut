public class CondTest {
   public static void main(String[] args) {
      Object o = ((3 > 2)? "x" : "x".wait());
   }
}