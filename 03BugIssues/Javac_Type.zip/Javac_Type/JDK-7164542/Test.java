
public class Test {

    public static <S extends AutoCloseable & Readable,
                       T extends AutoCloseable & Appendable>
                       void copy(S s, T t, int size) throws Exception {
        try (S src = s; T trg = t) {
            CharBuffer buf = CharBuffer.allocate(size);
            int i = src.read(buf);
            while (i >= 0) {
                buf.flip(); // prepare buffer for writing
                trg.append(buf);
                buf.clear(); // prepare buffer for reading
                i = src.read(buf);
            }
        }
    }

    public static void main(String[] args) throws Exception {
        int size = 32;
        FileReader r = new FileReader(args[0]);
        FileWriter w = new FileWriter(args[1]);
        copy(r, w, size);
        BufferedReader br = new BufferedReader(new FileReader(args[0]));
        BufferedWriter bw = new BufferedWriter(new FileWriter(args[1]));
        copy(br, bw, size);
    }

}