

public class ShowFlaw extends SuperOfShowFlaw {

    static Flaw<Number> fn =  new Flaw<Number>(new Integer(3));

    Flaw<?> m(){return fn;}


    public static void main(String[] args) {
	SuperOfShowFlaw sosf = new ShowFlaw();
	SuperOfFlaw<List<?>> sof = sosf.m();
	List<String> ls = new ArrayList<String>();
	ls.add("Smalltalk rules!");
	sof.put(ls);
	Number n = fn.get().get(0);
    }

}