import java.util.*;

public class Fallo {
        public static void main(String [] args) {
                List<String> lista = new ArrayList<String>();
                lista.add("hola");
                String s = (String)(lista.get(0));
                System.out.println (s);
        }
}