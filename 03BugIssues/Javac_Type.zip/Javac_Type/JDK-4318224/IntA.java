
public interface IntA {
  public static final int A = 0;
  public static final int B = 1;
}