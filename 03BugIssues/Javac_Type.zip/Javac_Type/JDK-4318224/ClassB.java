
public class ClassB implements IntA {

  /** Creates new ClassB */
  public ClassB() {
  }
  
  public static void testIt(ClassB test) {
    int a = 2;
    
    switch (a) {
      case test.A: System.out.println("a"); break;
// constant expression required for line above. The following line is compiled
correctly
// the line above should compile correcty because the object refers to an
constant
// implemented by the class itself.
      case IntA.B: System.out.println("b"); break;
    }
  }
  
  public static void main(String[] args) {
    testIt(new ClassB());
  }
}