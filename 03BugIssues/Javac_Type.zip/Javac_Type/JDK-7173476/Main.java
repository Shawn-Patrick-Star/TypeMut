public class Main {

  public static class Item {
    public Long getID() { return null; }
  }

  public static void main(String[] args) {
    Item i = new Item();
    Long ID = (i==null) ? 0L : i.getID();
    System.out.println(ID);
  }

}