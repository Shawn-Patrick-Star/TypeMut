> class Bug<T> {
>     T elem;
>     class Inner {
>         void put(T e) {
>             elem = e;
>         }
>     }
>     public static void main(String[] args) {
>         Bug<B> b = new Bug<B>();
>         Bug<? extends A> a = b;
>         a.new Inner().put(new A()); // this should not be possible
>         b.elem.b();            // this yields a ClassCastException
>     }
> }