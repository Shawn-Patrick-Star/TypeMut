

import java.util.*;
import java.lang.reflect.*;

public class TestEnum {

   public static void main(String[] args) {
        try {
             Colour02 test = Enum.valueOf(null, "BLUE");
             System.out.println("Test Fail");
        } catch(NullPointerException e) {
           System.out.println("Test Pass");
       }
   }

}