In this example, an anon local class is checking to see if the
enclosing class instance IS the current instance. I don't understand
how they can be the same. The bytecodes do not try and access the this$ field
for Anonsense.this, and in fact the inner class Anonsense$1 doesn't even have
one.

If there is something here that is violating the spec, please let me know.
[I know it violates clean coding rules. :^( ]

cruella<134> cat Anonsense.java
/* Isolated from Modena testcase ciner066. */
public class Anonsense {
  void test() { /* Needed to compile, never Called */ int i = 0; i = 1/i; }
  void checkIt() {
       Anonsense z = new Anonsense() {
            void test() {
              if ( this == Anonsense.this ) {
                  /* This should not be true, how can the enclosing instance
                   *   BE the current instance?
                   * Bytecodes look like:
                   *    aload_0
                   *    aload_0
                   *    if_acmpne
                   * which seems to imply that it thinks these are the same.
                   */
                  System.out.println("HOW CAN THIS BE?");
              }
            }
       };
       z.test();
  }
  public static void main(String[] s)  {
     Anonsense x = new Anonsense();
     x.checkIt();
  }
}