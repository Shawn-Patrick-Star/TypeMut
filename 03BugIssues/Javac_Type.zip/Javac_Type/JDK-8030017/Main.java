class Main {
    public static void main(String[] args) {
        Box<? extends Integer> bi = null;
        int i = bi.get();
    }
}