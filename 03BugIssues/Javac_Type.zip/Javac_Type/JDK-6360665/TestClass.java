public class TestClass implements DavInt, DavInt2
{
    public static void main(String [] args)
    {
        (true ? new TestClass() : new TestClass2()).davInt2Method();
        // THE ABOVE LINE THROWS A NoSuchMethodError EXCEPTION
    }

    public void davInt2Method()
    {
    }
    
    public void davIntMethod()
    {
    }
}
   
class TestClass2 implements DavInt, DavInt2
{
    public void davInt2Method()
    {
    }
    
    public void davIntMethod()
    {
    }
}

interface DavInt
{
	void davIntMethod();
}

interface DavInt2
{
	void davInt2Method();
}