public class TestOverload {
    interface Foo<T> {
        void m(T arg);
    }

    interface IntFoo {
        void m(int arg);
    }

    interface Bar<T> {
        void bar(Foo<T> arg);
    }

    interface IntBar extends Bar<Integer> {
        @SuppressWarnings("overloads")
        default void bar(IntFoo arg) {
            System.out.print("Primitive: ");
        }

        @SuppressWarnings("overloads")
        default void bar(Foo<Integer> arg) {
            System.out.print("Boxed: ");
            bar((IntFoo) arg::m);
        }
    }

    public static void main(String[] args) {
        class Impl implements IntBar {
            @Override
            public void bar(IntFoo foo) {
                IntBar.super.bar(foo);
                System.out.print("Overload: ");
                for (String arg: args) {
                    Integer n = Integer.valueOf(arg);
                    foo.m(n.intValue());
                }
            }
        }
        Impl impl = new Impl();
        impl.bar((int n) -> System.out.println(n + 100));
        impl.bar((Integer n) -> System.out.println(n));
    }
}
