     1  class T {
     2      static void f(String fmt, Object... args) {}
     3
     4      public static void main(String[] args) {
     5          f("foo", args);
     6          f("foo", null);
     7      }
     8  }