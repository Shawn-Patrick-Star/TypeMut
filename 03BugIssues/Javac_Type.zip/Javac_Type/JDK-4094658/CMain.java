import pack1.P1;

public class CMain {
	public static void main( String[] argv ) {
		P1 p1 = new P1();
		p1.p2.privatei = 3;
		System.out.println (p1.p2.privatei);
	}
}