
package pack1;

public class P1 {
        public P2 p2 = new P2();
}