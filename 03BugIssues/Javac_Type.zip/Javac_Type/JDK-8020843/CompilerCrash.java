import java.util.*;

class CompilerCrash {
    private static <T> T[] clone(T[] array) {
        return Arrays.stream(array)
                     .map(T::clone)
                     .collect(Collectors.toList())
                     .toArray(array);
    }
    public static void main(String... args) {
        clone(args);
    }
}