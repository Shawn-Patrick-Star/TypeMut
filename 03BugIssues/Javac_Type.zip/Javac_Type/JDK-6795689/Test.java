
class Test
{
    static abstract class Fn<A, B>
    {
        public abstract B applyTo(A value);

        public <X> Fn<X, B> after(final Fn<? super X, ? extends A> fn)
        {
            return new Fn<X, B>()
            {
                public B applyTo(X value)
                {
                    A intermediate = fn.applyTo(value);
                    return Fn.this.applyTo(intermediate);
                }
            };
        }
    }

    static final Fn<Object, String> TO_STRING = new Fn<Object, String>()
    {
        public String applyTo(Object obj) { return obj.toString(); }
    };

    static final Fn<Boolean, Boolean> COMPLEMENT = new Fn<Boolean, Boolean>()
    {
        public Boolean applyTo(Boolean b) { return !b; }
    };

    public static void main(String[] args)
    {
        // The following assignment shouldn't compile!
        Fn<Object, String> f = TO_STRING.after(COMPLEMENT);
        // Invocations of f.applyTo() then cause a ClassCastException:
        System.out.println(f.applyTo(new Object()));
    }
}