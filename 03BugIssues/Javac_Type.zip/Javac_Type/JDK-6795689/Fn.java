    static abstract class Fn<A, B>
    {
        public abstract B applyTo(A value);

        public <X> Fn<X, B> after(final Fn<? super X, ? extends A> fn)
        {
            return new Fn<X, B>()
            {
                public B applyTo(X value)
                {
                    A intermediate = fn.applyTo(value);
                    return Fn.this.applyTo(intermediate);
                }
            };
        }
    }