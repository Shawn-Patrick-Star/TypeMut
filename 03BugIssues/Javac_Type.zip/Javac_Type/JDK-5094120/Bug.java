public class Bug {

	public static void main(String[] args){
		DummyParameterTakerImpl dpti = new DummyParameterTakerImpl();
		
		defOk(dpti);
		defError(dpti);
	}

	/**
	 * A's decl occurs _before_ it is "used"
	 */
	static <A extends Parameter, B extends Dummy & ParameterTaker<A>> void defOk(B b){
	}
	
	/**
	 * A's decl occurs _after_ it is "used" - Results in a NPE
	 */
	static <B extends ParameterTaker<A> & Dummy, A extends Parameter> void defError(B b){
	}

	interface Dummy {} // Needed for multiple bounds

	interface ParameterTaker <P extends Parameter> {}
	
	interface Parameter {}

	static class DummyParameterTakerImpl implements ParameterTaker<Parameter>, Dummy {}
}