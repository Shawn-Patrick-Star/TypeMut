
// Sub.java
package b;
public class Sub extends a.Super {
    public static void main(String[] args) {
        Foo f = new Foo();
        f.x = 2;			// <== IllegalAccessError thrown here
    }
}