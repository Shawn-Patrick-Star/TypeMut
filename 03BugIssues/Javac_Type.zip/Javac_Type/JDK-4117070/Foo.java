    protected static class Foo {
        public Foo() {}			// required because of 4087421??
        public int x;
    }