
class t {
    public static void main(String[] args) {
        char[] def = { 'd', 'e', 'f' };
        System.out.println("\tabc" + def);
    }
}