// Cast.java
import java.util.zip.ZipEntry;

public class Cast {
        public static void main (String[] argv) {
                ZipEntry e = new ZipEntry("test.zip");
                byte[] b = new byte[e.getSize()];
//                byte[] b = new byte[ (int)e.getSize()]; //workaround
        }
}