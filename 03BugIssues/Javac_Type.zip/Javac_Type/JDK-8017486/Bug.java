import java.util.*;
import java.util.function.Function;

public class Bug {

    public static <P, Q> Iterator<Q> makeIterator(Iterator<P> iterator, Function<P, Q> extractor) {
        if (iterator == null) {
            return Collections.emptyIterator();
        }

        return new Iterator<Q>() {
            @Override
            public boolean hasNext() {
                return iterator.hasNext();
            }

            @Override
            public Q next() {
                P next = iterator.next();
                Q value = extractor.apply(next);
                return value;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public static <P, Q> Iterable<Q> makeIterable(Iterable<P> iterable, Function<P, Q> extractor) {
        if (iterable == null) return Collections.emptyList();

        return () -> makeIterator(iterable.iterator(), extractor);
    }

    public static Iterable<Boolean> makeIterable(final boolean[] a) {
        return () -> new Iterator<Boolean>(){
            private int index = 0;
            @Override
            public boolean hasNext() {
                return index < a.length;
            }

            @Override
            public Boolean next() {
                return a[index++];
            }
        };
    }

    public static void main(String ... args) {

        boolean[] a = new boolean[]{false, true};

        for (String s : makeIterable(makeIterable(a), (b) -> b ?  " T "  :  " F " )) {
            System.out.print(s);
            System.out.print(' ');
        }
        System.out.println( " : wrong outcome " );

        Function<Boolean, String> f = (b) -> b ?  " T "  :  " F " ;
        for (String s : makeIterable(makeIterable(a), f)) {
            System.out.print(s);
            System.out.print(' ');
        }
        System.out.println( " : right outcome " );

    }

}