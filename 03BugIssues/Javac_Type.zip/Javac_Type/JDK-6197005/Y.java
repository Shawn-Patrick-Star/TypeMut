     1  class Y {
     2      X x;
     3      void foo() {
     4          String s = x.y.returnU();
     5      }
     6      public static void main(String... args) {
     7      }
     8  }