class Bug6Base {
    protected void test() {;}
}

interface Bug6Int {
    public void test();
}

public class Bug6 extends Bug6Base implements Bug6Int {
    public static void main(String[] args) {
        System.err.println("test " + new Bug6());
    }
}

