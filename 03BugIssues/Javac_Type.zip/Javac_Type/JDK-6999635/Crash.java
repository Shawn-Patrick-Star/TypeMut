
class Crash {
	     
		interface Foo {}
		static class X1 extends Exception implements Foo {}
		static class X2 extends Exception implements Foo {}

		public static void main(String[] args) {
			try {
				if (args.length == 0)
					throw new X1();
				else
					throw new X2();
			}
			catch (X1|X2 ex) {
			}
		}
	}