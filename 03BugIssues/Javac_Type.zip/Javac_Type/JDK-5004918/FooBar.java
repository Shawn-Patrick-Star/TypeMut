public class FooBar {
  public static void main(String[] args) {

        List list = new LinkedList();
	String s = "this shouldn't work";
	list.add(s);
	List<Integer> listInt = list;
	int i = listInt.get(0);
	System.out.println(i);

  }
}