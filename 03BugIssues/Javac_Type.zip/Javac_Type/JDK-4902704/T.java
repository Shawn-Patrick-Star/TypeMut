
/*****************************************************/
import java.util.*;
class T extends Vector {
    public static void main(String[] args) {
        T t = new T();
        Iterator i = t.iterator();
    }
}