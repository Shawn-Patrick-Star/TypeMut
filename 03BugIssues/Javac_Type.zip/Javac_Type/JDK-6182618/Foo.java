public class Foo<T> {
        // These are all OK
        void bar1(Class<? extends T> x) {}
        <X extends T> void bar2(Class<X> x) {}
        void bar3(Class<? super T> x) {}

        // but this one causes javac to complain... why?
        <X super T> void bar4(Class<X> x) {}

        public static void main(String[] args) {
                Foo<Number> f = new Foo<Number>();
                f.bar1(Integer.class);
                f.bar2(Double.class);
                f.bar3(Object.class);
        }
}