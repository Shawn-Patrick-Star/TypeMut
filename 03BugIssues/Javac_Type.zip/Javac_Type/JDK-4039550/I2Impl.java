
// package bpkg, compilation unit I2Impl.java
package bpkg;
public class I2Impl implements apkg.I2 {
  public void g() { System.out.println("from bpkg: g()"); }
  public void f() { System.out.println("from bpkg: f()"); }
}