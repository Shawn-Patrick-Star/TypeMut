
// package apkg, compilation unit UseI1.java
package apkg;
public class UseI1 {
  public static void main(String[] args) {
    I1 x = new bpkg.I2Impl();  // (*)
    x.f();
  }
}