
public interface I2 extends I1 {
  void g();
}