import java.util.*;
import java.util.stream.Collectors;

interface SoftDelete {
	public boolean isDeletedFlag();
	public void setDeletedFlag(boolean deletedFlag);
}

class A implements SoftDelete {
	private boolean deleted;
	public boolean isDeletedFlag() {
		return deleted;
	}
	public void setDeletedFlag(boolean deletedFlag) {
		this.deleted = deletedFlag;
	}
}

class B extends A {
	public String toString() { return "B";}
}

class C extends A {
	public String toString() { return "C";}
}


public class Test {
	public static void main(String [] args) throws RuntimeException {

		Class<? extends A> genericFindClass = null;
		if( args.length == 1) {
			genericFindClass = A.class;
		} else {
			genericFindClass = B.class;
		}

		if( genericFindClass != null ) {
			List<?> dbList = findStuff(genericFindClass);
			// Filter deleted elements if applicable
			if( SoftDelete.class.isAssignableFrom(genericFindClass) ) {
				dbList = dbList.stream().filter( o-> !((SoftDelete)o).isDeletedFlag() ).collect( Collectors.toList());
			}
			for (Object o : dbList) {
				System.out.println(o);
			}
		}
	}

	static List<?> findStuff(Class someType) {
		List list = new ArrayList();
		if (someType == B.class)
			list.add(new B());
		else if (someType == C.class)
			list.add(new C());
		return list;
	}
}