import java.math.RoundingMode;

public enum MyEnum {

    FIRST(RoundingMode.CEILING),
    
    SECOND(RoundingMode.HALF_DOWN),
    
    THIRD(RoundingMode.UNNECESSARY),
    
    FOURTH(RoundingMode.HALF_EVEN),
    
    FIFTH(RoundingMode.HALF_DOWN),
    
    SIXTH(RoundingMode.CEILING),
    
    SEVENTH(RoundingMode.UNNECESSARY);
    
    private final RoundingMode mode;
    
    private MyEnum(RoundingMode mode) {
        switch ( mode ) {
        case CEILING:
        case HALF_DOWN:
        case UNNECESSARY:
        case HALF_EVEN:
            break;
        default:
            throw new IllegalArgumentException(mode + " is not a valid RoundingMode for MyEnum");
        }
        this.mode = mode;
    }
    
    /**
     * Dead code.
     */
    public boolean isOdd() {
        switch ( this ) {
        case FIRST:
        case THIRD:
        case FIFTH:
        case SEVENTH:
            return true;
        default:
            return false;
        }
    }
    
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
    
}