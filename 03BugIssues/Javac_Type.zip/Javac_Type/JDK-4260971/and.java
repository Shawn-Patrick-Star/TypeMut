
3) Create a 2nd class, that extends the previos class and implements the interface.

----------------------
For example:

class CC extends C implements I {
    
    public static void main(String[] args) {
        I me = new CC();       
        String[] res = me.getString(null,null,null);
        System.out.println("successful");               
    }        
}