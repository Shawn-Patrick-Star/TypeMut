import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;


public class MySecondLambda {
  final int CONSTANT_INSTANCE_INT_VALUE = 5678765;
  final String CONSTANT_INSTANCE_STRING_VALUE = "xyzyx";

  public static void main(String[] args) {
    List<String> names = Arrays.asList("1", "21", "376");
    Stream<Integer> lengths = names.stream().map(name -> name.length());
    System.out.println("This is the result of mapping names to lengths");
    lengths.forEach(a -> System.out.println(a));

    MySecondLambda mfl = new MySecondLambda();
    mfl.doInstanceMethod();
  }

  void doInstanceMethod() {
    final int CONSTANT_INT_VALUE = 232323;
    final String CONSTANT_STRING_VALUE = "mwmwm";

    /*
    Consumer<Integer> consumeInts = y -> {
      System.out.println("instance constant: " + CONSTANT_INSTANCE_INT_VALUE);
      System.out.println("   local constant: " + CONSTANT_INT_VALUE);
      System.out.println("          int arg: " + y);
      System.out.println("              sum: " +
                         (y +
                          CONSTANT_INSTANCE_INT_VALUE + CONSTANT_INT_VALUE));
    };

    consumeInts.accept(37);
    consumeInts.accept(54);
    consumeInts.accept(21);
    */

    Consumer<String> consumeStrings = s -> {
      System.out.println("instance constant: " +
                         CONSTANT_INSTANCE_STRING_VALUE);
      System.out.println("   local constant: " + CONSTANT_STRING_VALUE);
      System.out.println("       string arg: " + s);
      System.out.println("       catenation: " +
                         (s + ":" +
                          CONSTANT_INSTANCE_INT_VALUE + ":" +
                          CONSTANT_INT_VALUE));
    };

    consumeStrings.accept("bob");
    consumeStrings.accept("mary");
    consumeStrings.accept("harry");
  }
}