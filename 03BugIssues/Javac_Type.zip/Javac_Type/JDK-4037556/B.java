
public class B {
    public static void main (String[] args) {
        Y y = new Z();
        y.f(); // oops.
    }
}