
class Z extends X implements Y { // implement instance method with
static method
}