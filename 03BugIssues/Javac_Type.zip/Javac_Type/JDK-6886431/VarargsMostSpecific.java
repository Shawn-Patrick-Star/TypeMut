public class VarargsMostSpecific {

  static int f(Object... args) { return 1; }
  static int f(int... args) { return 2; }

  public static void main(String... args) {
    int result = f(1, 2, 3);
    System.out.println("result: " + result);
  }

}