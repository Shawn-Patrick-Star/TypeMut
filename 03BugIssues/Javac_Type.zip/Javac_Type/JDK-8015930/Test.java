/*
Tested with javac -version:
javac 1.6.0_18
javac 1.7.0_09

Test.java:19: incompatible types
found   : java.lang.Object
required: java.lang.String
        for(String element: raw.foo);
*/

import java.util.*;

public class Test<T> {
    Set<String> foo;
    
    public static void main(String[] arguments) {
        Test raw = new Test();
        for(String element: raw.foo);
    }
}