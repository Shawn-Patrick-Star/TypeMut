
import java.util.*;

class Test {
    public static void main(String[] args) {
        Collection<Integer> c = new Vector<Integer>();
        c = Collections.checkedCollection(c, int.class);
        c.add(0);
    }
}