/**Illustration of Java Enum-related compile bug.
*@author Garret Wilson
*/
public class BugEnum {

public interface Command {}

public interface CommandMessage<C extends Enum<C> & Command> {
public C getCommand();
}

public enum TestCommand implements Command {SUCCESS, FAILURE}

public static class TestCommandMessage implements CommandMessage<TestCommand> {
@Override public TestCommand getCommand() {return TestCommand.SUCCESS;}
}

public static <E extends Enum<E>> String getSerializationName(final E e) {
return e.name().toString().toLowerCase();
}

public static void main(String... args) {
CommandMessage<?> testMessage=new TestCommandMessage();
System.out.println(getSerializationName(testMessage.getCommand()));
}

}