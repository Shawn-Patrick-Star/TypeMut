
class Box<T> extends Base<Object> {
    T value;
    Box(T t) { value = t; }

    public static void main(String[] args) {
        Box<String>[] a = new Box<String>[1];
        Base<Object>[] o = a;
        o[0] = new Box<Integer>(new Integer(3));
        String s = a[0].value; // java.lang.ClassCastException
    }
}