
package x;

import a.*;

public class X extends A {
    void foo() {
	System.out.println("X's foo");
    }
}