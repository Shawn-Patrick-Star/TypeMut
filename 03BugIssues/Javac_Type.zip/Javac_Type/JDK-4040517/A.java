
package a;

import x.X;

public class A {
    void foo() { }
    public static void main(String[] args) {
	X xref = new X();
	xref.foo();
    }
}