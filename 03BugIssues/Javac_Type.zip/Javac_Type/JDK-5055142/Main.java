
    class Main {
        static int f(Color c) {
            switch(c) {
            case green:
                return 2;
            case red:
                return 1;
            default:
                return 0;
            }
        }

        public static void main(String[] args) {
            f(Color.red);
        }
    }