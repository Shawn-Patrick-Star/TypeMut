public class Bug  {
    public static void main(String[] args) {
        Integer i = 0;
        i++;
    }
}