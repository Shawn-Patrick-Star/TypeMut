public class Min {
    public static int min(int a, int ... ints){

  int minTmp=a;
  for(int num:ints){
      if(num < minTmp)
    minTmp = num;
  }
  return minTmp;
  }
    
    public static <T extends Comparable<T>> T min(T a, T ... ints){
  T minTmp=a;
  for(T num:ints){
      if(num.compareTo(minTmp) < 0)
    minTmp = num;
  }
  return minTmp;
    }
    
    public static void main(String[] args){
  System.out.println(min(Integer.valueOf(1), Integer.valueOf(2)));
    }
}