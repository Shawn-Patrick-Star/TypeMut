

Run the code below. The two lines printing the 'outer' class should show the same non null value. In fact with JDK1.2RC2 the second one gives null! This works fine with jdk1.1.7. It also works if TestInnerClasses.Inner does not extend Context.Job.

class TestInnerClasses
{
	Context ctx;

	public static void main(String[] args)
	{
		(new TestInnerClasses()).test();
	}

	TestInnerClasses()
	{
		ctx = new Context();
	}

	void test()
	{
		Inner t = new Inner();
		t.run();
	}

	class Inner extends Context.Job
	{
		Inner()
		{
			TestInnerClasses.this.ctx.super();
			System.out.println("Created inner class: "+this);
			System.out.println("Outer is "+TestInnerClasses.this);
		}

		void run()
		{
			System.out.println("Use inner class: "+this);
			System.out.println("Outer is "+TestInnerClasses.this);
		}
	}
}