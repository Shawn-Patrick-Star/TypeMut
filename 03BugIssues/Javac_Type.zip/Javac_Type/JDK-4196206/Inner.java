
	class Inner extends Context.Job
	{
		Inner()
		{
			TestInnerClasses.this.ctx.super();
			System.out.println("Created inner class: "+this);
			System.out.println("Outer is "+TestInnerClasses.this);
		}

		void run()
		{
			System.out.println("Use inner class: "+this);
			System.out.println("Outer is "+TestInnerClasses.this);
		}
	}