class tester{
    public static void main(String[] args) {
        System.out.println(true? new D1(): new D2());
    }
}