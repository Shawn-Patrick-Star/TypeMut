
and a class that use this constant:

public class bar {
 public static void main(String[]args) {
  System.out.println("v: "+foo.v);
 }
}