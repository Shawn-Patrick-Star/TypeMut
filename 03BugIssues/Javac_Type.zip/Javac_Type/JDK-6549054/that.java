
Suppose we have an interface that defines a constant:

public interface foo {
 int v=1;
}