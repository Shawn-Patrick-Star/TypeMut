package two;
 
public class UseFooBar extends one.GrantAccess {
    public void use() {
        System.out.println(foo + " " + bar);
    }
 
    public static void main(String[] args) {
        new UseFooBar().use();
    }
}