package one;
 
public class GrantAccess extends DefineFooBar {
}