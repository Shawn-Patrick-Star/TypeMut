   static class Inner {
      public static void foo() {
         System.out.println("foo yourself");
      }
   }