

public class Outer {
   static class Inner {
      public static void foo() {
         System.out.println("foo yourself");
      }
   }

   public static void main(String[] args) {
      Inner i = new Outer().new Inner();
      i.foo();

/* workaround...
      Outer o = new Outer();
      Outer.Inner i = o.new Inner();
      i.foo();
*/
   }
}