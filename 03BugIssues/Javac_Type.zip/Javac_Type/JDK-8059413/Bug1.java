
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Bug1 {
    public static void main(String[] args) {
        new Bug1().test();
    }

    public void test() {
        System.out.println(match( a -> true,
                (v) -> {
                    if ("one".equals(v)) return 1;
                    if (v instanceof Number) {
                        Number n = (Number) v;
                        if (n.longValue() == 3) return "three";
                        return n.longValue();
                    }
                    return "";
                }, 2, 3, "one", "two") );
    }

    public <T> T match(Predicate<T> p, Function<T, T> f, T... t) {
        return Stream.of(t).parallel().filter(p).map(f).findAny().get();
    }
}