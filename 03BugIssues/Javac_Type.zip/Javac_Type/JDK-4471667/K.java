     9  class K extends J implements I {
    10    public short m() { return 1; }
    11
    12    public static void main(String[] args) {
    13      K k = new K();
    14      J j = k;
    15      I i = k;
    16      System.out.println(i.m() + " " + j.m() + " " + k.m());
    17    }
    18  }