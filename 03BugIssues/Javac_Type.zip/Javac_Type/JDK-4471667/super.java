frog$ jdis K.class 
super class K
        extends J
        implements I
{


Method "<init>":"()V"
        stack 1 locals 1
{
                aload_0;
                invokespecial   Method J."<init>":"()V";
                return;
}

public Method m:"()S"
        stack 1 locals 1
{
                iconst_1;
                ireturn;
}

public static Method main:"([Ljava/lang/String;)V"
        stack 4 locals 4
{
                new     class K;
                dup;
                invokespecial   Method "<init>":"()V";
                astore_1;
                aload_1;
                astore_2;
                aload_1;
                astore_3;
                getstatic       Field java/lang/System.out:"Ljava/io/PrintStream;";
                new     class java/lang/StringBuffer;
                dup;
                invokespecial   Method java/lang/StringBuffer."<init>":"()V";
                aload_3;
                invokeinterface InterfaceMethod I.m:"()D",  1;
                invokevirtual   Method java/lang/StringBuffer.append:"(D)Ljava/lang/StringBuffer;";
                ldc     String " ";
                invokevirtual   Method java/lang/StringBuffer.append:"(Ljava/lang/String;)Ljava/lang/StringBuffer;";
                aload_2;
                invokevirtual   Method J.m:"()I";
                invokevirtual   Method java/lang/StringBuffer.append:"(I)Ljava/lang/StringBuffer;";
                ldc     String " ";
                invokevirtual   Method java/lang/StringBuffer.append:"(Ljava/lang/String;)Ljava/lang/StringBuffer;";
                aload_1;
                invokevirtual   Method m:"()S";
                invokevirtual   Method java/lang/StringBuffer.append:"(I)Ljava/lang/StringBuffer;";
                invokevirtual   Method java/lang/StringBuffer.toString:"()Ljava/lang/String;";
                invokevirtual   Method java/io/PrintStream.println:"(Ljava/lang/String;)V";
                return;
}

public Method m:"()I"
        stack 1 locals 1
{
                aload_0;
                invokevirtual   Method m:"()S";
                ireturn;
}

public Method m:"()D"
        stack 2 locals 1
{
                aload_0;
                invokevirtual   Method m:"()S";
                i2d;
                dreturn;
}

}