     5  abstract class J {
     6    int m() { return 2; }
     7  }