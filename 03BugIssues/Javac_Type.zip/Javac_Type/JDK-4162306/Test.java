import java.lang.reflect.Method;

public class Test {
  public static void main (String[] argv) {
    Method[] m = SomeClass.class.getDeclaredMethods();
    for (int i=0; i< m.length; i++) {
      System.out.println(m[i]);
    }
  }
}