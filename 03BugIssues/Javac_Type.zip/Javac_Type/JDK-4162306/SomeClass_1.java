abstract class SomeClass extends java.lang.Object implements SomeInterface {
    SomeClass();
    public int method1();
    public abstract int method2();
}