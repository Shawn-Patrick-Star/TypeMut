
public class C {
    interface I<T> {}
    static void m(I<?> o) {
        System.out.println("checking " + o);
        System.out.println("[#1] instance of Exception? " + (o instanceof Exception));
        System.out.println("[#2] instance of Exception? " + Exception.class.isInstance(o));
        System.out.println("[#3] instance of Exception? " + ((I) o instanceof Exception));
    }
    public static void main(String[] x) {
        class I1 implements I<String> {}
        m(new I1());
        class I2 extends Exception implements I<String> {}
        m(new I2());
    }
}