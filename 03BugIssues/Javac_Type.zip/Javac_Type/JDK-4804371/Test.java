public class Test {

Test() {
    new Object() {
        public void finalize() throws Throwable {
            Test.this.finalize();
        }
    };
}

public static void main(String[] argv) {
    new Test();
}

}