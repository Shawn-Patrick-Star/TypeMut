package test.problem;

class A<D> {

	D d;
	
	D getD() {
		return null;
	}
}

class B extends A<Integer> {

	Integer y;
	
	B() {
		y = d = getD(); // Verify Error here
	}
	
	public static void main(String[] args) {
		new B();
	}
}