// credits for this test go to Timo Kinnunen
class MissingTypeCheck {

	public static void main(String[] args) {

		// -- does not throw compiled with javac (correct)
		MissingTypeCheck.<String> newArray();

		// -- does not throw compiled with javac (NOT CORRECT)
		// -- JAVAC SHOULD PERFORM A TYPE CHECK HERE
		assertNothing(MissingTypeCheck.<String> newArray());

		// -- throws compiled with javac (correct)
		// String[] hopeless = newArray();
	}

	static <T> void assertNothing(T actual) {
		/* nada */
	}

	static <T> T[] newArray() {
		@SuppressWarnings("unchecked")
		T[] array = (T[]) new Object[0];
		return array;
	}
}