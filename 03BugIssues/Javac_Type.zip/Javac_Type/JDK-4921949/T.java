
class T {
    public static void main(String[] args) {
        Character c = 'a';
        String s1 = ("_" + c + "_").intern();
        if (s1 != "_a_") throw new Error(s1);
    }
}