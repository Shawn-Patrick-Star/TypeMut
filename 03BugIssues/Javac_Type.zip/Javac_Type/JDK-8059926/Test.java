
public class Test {
    public static void main(String[] args) {
        Iface<? super Integer> i = (Integer...a) -> "";
        String result = i.m(1);
    }
}