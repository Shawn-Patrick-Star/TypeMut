

public class X  { 
    public static void main(String[] args) { 
            I i = Y::zoo; 
            i.zoo(null,  null); 
        } 
}