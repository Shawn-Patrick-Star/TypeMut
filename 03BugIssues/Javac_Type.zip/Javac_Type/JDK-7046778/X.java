

class X<T> {
    class Y<Z> {
         Y(T a, Z b) { }
    }

    public static void main(String[] args) {
        X<String>.Y<String> x1 = new X<String>().new Y<String>("",""); //ok
        X<String>.Y<String> x2 = new X<String>().new Y<>("",""); //fails
    }
}