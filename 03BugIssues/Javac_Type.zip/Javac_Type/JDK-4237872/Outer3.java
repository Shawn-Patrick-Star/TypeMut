class Outer3 {
	class Nested3 {
		Nested3() {
			super();
		}
		Nested3(String o) {
			o.super();	// should be error
		}

		void g() {
			System.out.println("Outer3.this = " + Outer3.this);
		}
	}

	void f() {
		System.out.println(this);
		new Nested3("hello").g();
		new Nested3().g();
	}

	public static void main(String[] args) {
		new Outer3().f();
	}
}