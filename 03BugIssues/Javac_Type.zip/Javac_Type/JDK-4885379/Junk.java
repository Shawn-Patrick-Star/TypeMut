
import java.util.*;

public class Junk {
    public static void main(String[] args) {
        Collection<?> c = new HashSet<String>();
        Set<?> s = (Set<?>)c;
    }
}