
class X {
   String s=null;
  
   X() {
      s="CLASS_X";
   }

   String test() {
      class Y { 
         Y() {
            s="CLASS_Y";
         }
     
         String test() {
            class Z extends X {
               Z() {
                  X.new Y().super(); //Y's constructor is expected to be called.
               }
               String test() {
                  return s;
               }
            }
            return new Z().test();
         }
      }
      return new Y().test();
   }
   
   public static void main(String[] s) {
      X x=new X();
      System.out.println(x.s); // String "CLASS_X" should appear.
   }
}