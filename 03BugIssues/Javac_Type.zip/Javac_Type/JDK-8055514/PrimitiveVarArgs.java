public class PrimitiveVarArgs
{
    public static void main(String[] args)
    {
        int[] ints = new int[]{1, 2, 3, 4, 5};
        prints(ints);
    }

    void prints(int... ints)
    {
        for(int i : ints)
            System.out.println(i);
    }
}