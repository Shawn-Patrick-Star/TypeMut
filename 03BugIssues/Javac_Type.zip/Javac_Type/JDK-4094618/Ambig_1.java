public class Ambig extends S implements I {
        public static void main( String[] argv ) {
		Ambig a = new Ambig();
                System.out.println(a.i);
        }
}