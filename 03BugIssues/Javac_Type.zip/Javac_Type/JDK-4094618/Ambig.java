
The class Ambig extends S and implements I.  Both S and I define a field i, but
this field is private in S.  Therefore, Ambig inherits i from I only.  There
should not be any ambiguity.  Problem discovered using Modena test c0814702.

algol% cat Ambig.java
interface I {
        int i=1;
}