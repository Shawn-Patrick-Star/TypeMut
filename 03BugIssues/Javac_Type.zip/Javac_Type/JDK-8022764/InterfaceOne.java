//InterfaceOne.java
public interface InterfaceOne {
    Integer one = 1;
}

//InterfaceTwo.java
public interface InterfaceTwo {
    Integer one = 1;
}

//InterfaceThree.java
public interface InterfaceThree extends InterfaceOne, InterfaceTwo {
}

//TestMultipleInheritance.java
public class TestMultipleInheritance {
    public static void main(String[] args) {
System.out.println(InterfaceThree.one);//Error The field InterfaceThree.one is ambiguous
    }
}