
class CastCrash {

  public static void main(String[] args) {
    List<Integer> l = new ArrayList<Integer>();

    SN sn = (SN)(LI) l;

  }

}