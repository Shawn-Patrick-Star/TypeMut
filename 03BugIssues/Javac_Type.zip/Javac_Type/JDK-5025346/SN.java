

import java.util.*;

interface SN extends Set<Number>{}