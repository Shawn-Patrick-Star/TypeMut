package pkg.subpkg;

public interface ID { }

--------------------------------------------------------

package pkg;

import static pkg.Demo.DemoID.*;
import pkg.subpkg.ID;

public class Demo {

	public static enum DemoID implements ID { A, B, C }
	
	public static void main( String[] args ) {
		System.out.println( A );
	}
}