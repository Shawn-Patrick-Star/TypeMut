import java.util.ArrayList;
import java.util.List;

public class Bug {
    public static void main(String[] args) {
        List<List<Double>> mainList = new ArrayList<List<Double>>();
        List subList = new ArrayList();
        mainList.add(subList);
        subList.add("Bad apple.");

        for (List<Double> currentList : mainList) {
            for (Double d : currentList)
                System.out.println("Unreachable, as it should be.");
        }
    }
}