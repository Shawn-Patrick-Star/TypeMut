import java.util.Collection;
import java.util.List;

public class ReflectionBugDemo {
  public static void main(String[] args) throws SecurityException, NoSuchMethodException {
    Class<?> returnType1 = Example1.class.getMethod("process").getReturnType();
    Class<?> returnType2 = Example2.class.getMethod("process").getReturnType();
    
    System.out.println("Return type of Example1.process(): " +returnType1);
    System.out.println("Return type of Example2.process(): " +returnType2);
  }
  
}

class Example1<E extends Collection> {
  public E process() {
    return null;
  }
}

class Example2 extends Example1<List> {}