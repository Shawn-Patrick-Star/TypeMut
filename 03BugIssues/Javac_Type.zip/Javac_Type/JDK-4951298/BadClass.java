
class BadClass implements TestM3 {

    public String message() {
        return "Hello World";
    }

    public Class myClass() {
        return Float.TYPE;
    }

    public static void main(String[] arg) {
        System.out.println(" Done...");
        BadClass bc = new BadClass();
        TestM2 tm2 = (TestM2) bc;
        System.out.println("   "+tm2.message());
        System.out.println("   "+tm2.myClass());
    }

}