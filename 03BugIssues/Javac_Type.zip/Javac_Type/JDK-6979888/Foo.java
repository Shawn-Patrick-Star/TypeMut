public class Foo
{
    public static <T> T[] foo(T... o)
    {
        return o;
    }

    public static void main(String[] args)
    {
        String[] s = foo();
        System.out.println(s);
    }
}