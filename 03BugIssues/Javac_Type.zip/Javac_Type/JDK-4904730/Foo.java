
class Foo implements Comparable {
    int val;
    Foo(int i) { val = i; }

    public int compareTo(Object o) {
        Foo f = (Foo)o;
        return (val < f.val ? Integer.MIN_VALUE : (val == f.val ? 0 : 1));
    }

    public boolean equals(Object o) {
        return o instanceof Foo && ((Foo)o).val == val;
    }

    public int hashCode()    { return val; }

    public String toString() { return Integer.toString(val); }
}