/**
 * File : ReverseOrder.java
 * Date :  22/04/2002
 * Pertaining to BugId:4593209
 */

import java.util.*;

public class ReverseOrder {
private static String testname = "" ; 
 public static void main(String[] args) throws Exception {
    ReverseOrder test = new ReverseOrder();
    test.go();
  }

  public void go() throws Exception {
    boolean status[];
    int passcount = 0, failcount = 0;
    int numTests = 1;
    int i, j = 0;
    status = new boolean[numTests];
    System.out.println("Total Number of Tests for Exec : "+numTests);
    for(i = 0; i < numTests; ++i) {
        try {
            ++j;
            switch (j) {
            case 1:
            testname="ReverseOrder";
	    status[i] =ReverseOrderTest();
            break;
      		}
         } catch (Exception e) {
            status[i] = false;
            System.out.println ("Exception in test "+j+": "+e.getMessage());
            e.printStackTrace();
        }
    }
    // Get pass and fail totals
    for(i = 0; i < numTests; ++i) {
            if (status[i] == true)
               passcount++;
            else
               failcount++;
    }
    System.out.println("Pass count: " + passcount);
    System.out.println("Fail count: " + failcount);
    // check if tests passed
    if ( failcount < 1 ) {
    System.out.println("Test for ReverseOrder Passed");
       TestHelper.exit(0);
    } else {
       System.out.println("Test for ReverseOrder failed");
       TestHelper.exit(1);
    }
 }
    public boolean ReverseOrderTest() throws Exception
{
 
    
    	Foo[] a = { new Foo(2), new Foo(3), new Foo(1) };
        List list = Arrays.asList(a);
        Collections.sort(list, Collections.reverseOrder());

        Foo[] golden = { new Foo(3), new Foo(2), new Foo(1) };
        List goldenList = Arrays.asList(golden);

        if (!list.equals(goldenList))
            	return TestHelper.testFail(testname +"   : FAIL ");
        else 
        	return TestHelper.testPass(testname +"   : PASS");	
            		
   	}

class Foo implements Comparable {
    int val;
    Foo(int i) { val = i; }

    public int compareTo(Object o) {
        Foo f = (Foo)o;
        return (val < f.val ? Integer.MIN_VALUE : (val == f.val ? 0 : 1));
    }

    public boolean equals(Object o) {
        return o instanceof Foo && ((Foo)o).val == val;
    }

    public int hashCode()    { return val; }

    public String toString() { return Integer.toString(val); }
}

}