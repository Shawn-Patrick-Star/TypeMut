
class T {
    static public <T> T ident(T t) { return t; }
    public static void main(String[] args) {
        Box<Integer>[=] bi = new Box<Integer>[3];
        Object[] o = null;
        o = ident(true ? bi : o);
        o[0] = new Box<String>("hello");
        Integer i = bi[0].value;
    }
}