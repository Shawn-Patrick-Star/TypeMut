public class CceOnAssign {
    
    public static void main(String[] args) {
        Integer a = 1;
        Long b = 2L;
        Comparable<?>[] result = error(a, b);
    }
    
    static <T> T[] error(T...a) {
        return a;
    }
}