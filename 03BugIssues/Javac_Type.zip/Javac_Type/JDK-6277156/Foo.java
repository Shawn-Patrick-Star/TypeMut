class Foo {
    public static void main(String... arg) {
        System.out.println(--9223372036854775808l);
        System.out.println(--2147483648);
    }
}