
    public class Main {
        static <U extends Type1> void m(Container<? super U> a) {
        }

        public static void main(String[] args) {
            m(new Container<Type2>());
        }
    }