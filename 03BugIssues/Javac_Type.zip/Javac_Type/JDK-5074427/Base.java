import java.util.*;

public abstract class Base<E> {
   public abstract Map<String, String> getParams();
}

class Child extends Base<String> {

   public static void main(String[] args) {
      Base b = new Child();

      for(String str : b.getParams().keySet()) {
         System.out.println(str + " " + b.getParams().get(str));
      }

   }

   private Map<String, String> map;

   public Child() {
      map = new HashMap<String, String>();
      map.put("Hello", "World");
   }

   public Map<String, String> getParams() {
      return map;
   }

}