
public class UnexpectedKind {
    public static void main(String [] args) {
        OtherClass c = new OtherClass();
        int ci = c.i;
    }
}