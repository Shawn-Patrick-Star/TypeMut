public class GenericVarArgsTest {
    public static void main( String[] args ) {
        Controller<SessionImpl> controller = new ControllerImpl<SessionImpl>( new QueueImpl(), new QueueImpl() );
    }
}

interface Session {
}

class SessionImpl implements Session {
}

interface Queue <S extends Session> {
}

class QueueImpl implements Queue<SessionImpl> {
}

interface Controller <S extends Session> {
}

class ControllerImpl <S extends Session> implements Controller<S> {
    private Queue<S>[] queues;

    public ControllerImpl( Queue<S>... queues ) {
        this.queues = queues;
    }
}