package testPackage;

import static testPackage.p.Helper.field;
import static testPackage.p.Helper.Type;
//import static testPackage.p.Helper.Type.method;   // LINE1

public class Test {
    public static void main(String[] args) {
        System.out.println(field);
        System.out.println(Type.v);
//        System.out.println(testPackage.p.Helper.field);  //LINE2
    }
}