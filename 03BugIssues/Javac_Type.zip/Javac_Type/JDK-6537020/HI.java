package testPackage.p;

interface HI {
    public static int field = 1;
    public static class Type {
        public static int v = 1;
        public static int method(){return 1;}
    }
}