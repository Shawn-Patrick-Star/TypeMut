class HC {
    public static int field = 3;
    public static class Type {
        public static int v = 3;
        public static int method(){return 3;}
    }
}