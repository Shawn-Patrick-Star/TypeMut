import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@ds({@d})
//@d

public class AnnotationTest {
    public static void main(String[] args) {
        System.out.println(AnnotationTest.class.getAnnotation(ds.class).value()[0].name());
    }
}