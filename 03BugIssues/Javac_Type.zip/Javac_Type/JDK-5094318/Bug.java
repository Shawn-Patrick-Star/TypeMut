public class Bug {

	public static void main(String[] args){
		method(new int[0].clone());
	}
	
	// Java 1.5.0+
	public static void method(int[] array){
		System.out.println("You gave me an array of ints");
	}
	
	// Java 1.4.2 and before
	public static void method(Object obj){
		System.out.println("You gave me an object");
	}
}