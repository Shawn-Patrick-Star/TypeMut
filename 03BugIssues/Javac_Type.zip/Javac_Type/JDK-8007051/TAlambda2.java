
import java.lang.annotation.*;
import static java.lang.annotation.RetentionPolicy.*;
import static java.lang.annotation.ElementType.*;

public class TAlambda2 {

    public void test() {
        Integer[] intarray = { new Integer(1), new Integer(2), new Integer(3) };
        printArray(intarray, TPrint::<@A String>print);
    }

    public void printArray(Object[] oa, PrintString ps) {
      for(Object o : oa ) ps.print(o.toString());
    }

    public static void main(String... args) {
        new TAlambda2().test();
    }
}