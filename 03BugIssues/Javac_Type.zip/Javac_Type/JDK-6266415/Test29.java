import static java.lang.System.out;
  public class Test29 {
     public static void main(String[] args) { 
         testMethod(null); //Error Message is coming
         testMethod(null,null);//No Error or Warning Message is coming 
     }
     public static void testMethod(Integer ...ts) {
         out.println("Integer Test method ");
     }
     public static void testMethod(int... ts) {
         out.println("int Test Method");
     }
  }