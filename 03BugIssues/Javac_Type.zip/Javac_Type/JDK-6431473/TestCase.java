
public class TestCase<B>
{
    interface Base
    {
    }

    interface Interface extends Base
    {
    }

    static class Implementation implements Interface
    {
    }

    <T extends B, E extends T> E returnArg(Class<T> c, E e)
    {
        // do something with c
        return e;
    }

    public static void main(String[] args)
    {
        TestCase<Base> tc = new TestCase<Base>();
        tc.returnArg(Interface.class, new Implementation());
    }
}