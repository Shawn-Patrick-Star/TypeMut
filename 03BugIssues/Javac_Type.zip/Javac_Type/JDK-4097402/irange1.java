public class irange1 {
public static void main(String[] argv) {
    int i1 = -2147483649;  // error: -2147483549 out-of-range
    System.out.println(i1);
}
}