import java.util.*;

public class Test<V> extends HashMap<String, V> {
    public V get(String key) {
        System.out.println("Subclass method called!");
        return super.get(key);
    }
    
    public static void main(String[] arg) {
        Test<Object> test = new Test<Object>();

        System.out.println("Test 1:");
        test.get("test"); // works, prints "Subclass method called!"

        System.out.println("Test 2:");
        Map<String, Object> sameObject = test;
        sameObject.get("test");  // same object, same signature, but no output!  HashMap.get gets called instead
    }
}