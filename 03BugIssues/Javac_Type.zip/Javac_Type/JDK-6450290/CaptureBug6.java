// this code compiles without warnings, has no casts,
// but throws a ClassCastException
public class CaptureBug6 {
	public static void main(String[] args) {
		Box<Box<A,A	>,Box<A,A>> a = new Box<Box<A,A>,Box<A,A>>(new Box<A,A>(new 
A()));
		Box<?, ?> b = a;		
		b.value.same = new Box<B,B>(new B());
		A c = a.value.same.value;
	}
}

class Box<X extends Box<?,?>, T extends X> {
	Box (T v) {
		value = v;
	}

	Box () {}
		
	T value;
	Box<X, T> same;

}

class A extends Box<A,A> {}
class B extends Box<B,B> {}