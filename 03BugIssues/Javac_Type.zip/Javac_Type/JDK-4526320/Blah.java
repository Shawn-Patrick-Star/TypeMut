class Blah {
  public static void main(String[] args) {
    I.Inner.bar(new I(){});
  }
}