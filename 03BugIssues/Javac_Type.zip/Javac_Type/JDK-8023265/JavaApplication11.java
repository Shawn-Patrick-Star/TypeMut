package javaapplication11;

/**
 *
 * @author dainius
 */
public class JavaApplication11 {
    public static interface Some<T extends Some<T>> {
        void someTask();
        T clone();
    }
    
    public static class SomeImpl implements Some<SomeImpl> {

        @Override
        public void someTask() {
            System.out.println( " Job done " );
        }

        @Override
        public SomeImpl clone() {
            return new SomeImpl();
        }
    
        
    }
    
    public static class SomeContainer<T extends Some<T>> {
        private final T container;

        public SomeContainer(T container) {
            this.container = container;
        }

        public T getContainer() {
            return container;
        }
        
    }
    
    
    
    public static class TestClass {
        public <T extends Some<T>> SomeContainer<T> doWork(T t) {
            //There next line crashes compiler
            SomeContainer<T> ret = new SomeContainer<>(t.clone());
            
            ret.getContainer().someTask();
            return ret;
        }
        
        public <T extends Some<T>> SomeContainer<T> doWork2(T t) {
            //In this case everything compiles
            T newT=t.clone();
            SomeContainer<T> ret = new SomeContainer<>(newT);
            
            ret.getContainer().someTask();
            return ret;
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new TestClass().doWork(new SomeImpl());
    }
}