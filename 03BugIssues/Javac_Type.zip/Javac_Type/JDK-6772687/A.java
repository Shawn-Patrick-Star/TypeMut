public class A<N extends A> {
    public N x() {
        return null;
    }
}

public class B<M extends B> extends A<M> {
    public M y() {
        return null;
    }
    public static void main(String[] args) {
        new B().x().y();
    }
}