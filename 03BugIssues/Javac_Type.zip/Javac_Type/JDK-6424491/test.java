public class test {
    
    public FaultyEnum f1,f2,f3;

    public enum FaultyEnum {
	AAA(0, FaultyEnum.BBB, "text1"),
	BBB(1, FaultyEnum.CCC, "text2"),
	CCC(2, FaultyEnum.AAA, "text3"),
	DDD(3, FaultyEnum.EEE, "text4"),
	EEE(4, FaultyEnum.BBB, "text5");
	
	private final int index;
	
	private final FaultyEnum nested;
	
	private final String text;
	
	FaultyEnum(int i, FaultyEnum f, String s) {
	    index= i;
	    nested= f;
	    text= s;
	}
	
	public int index() {
	    return index;
	}
	
	public FaultyEnum nest() {
	    return nested;
	}
	
	public String text() {
	    return text;
	}
    }
    
    public static void main(String[] args) {
	test t = new test();
	t.f1= FaultyEnum.AAA;
	t.f2= FaultyEnum.BBB;
	t.f3= FaultyEnum.CCC;

	System.out.println("enum1:" + t.f1);
	System.out.println("index:" + t.f1.index());
	System.out.println("text:" + t.f1.text());
	System.out.println("nested:" + t.f1.nest()+"\n");

	System.out.println("enum2:" + t.f2);
	System.out.println("index:" + t.f2.index());
	System.out.println("text:" + t.f2.text());
	System.out.println("nested:" + t.f2.nest()+"\n");

	System.out.println("enum3:" + t.f3);
	System.out.println("index:" + t.f3.index());
	System.out.println("text:" + t.f3.text());
	System.out.println("nested:" + t.f3.nest()+"\n");
    }
    
}