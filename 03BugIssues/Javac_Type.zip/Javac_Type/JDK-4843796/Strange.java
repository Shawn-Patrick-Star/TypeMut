abstract class Strange {

   Strange() {
      init();
   }

   abstract void init();

   public static void main(String[] args) {

      boolean a = true;
      final boolean b1 = a;

	new Strange() {
	   void init() {
	      System.out.println("b1: " +  b1);
	   }
      };

      final boolean b2 = true;

	new Strange() {
	   void init() {
	      System.out.println("b2: " +  b2);
	   }
      };
   }
}