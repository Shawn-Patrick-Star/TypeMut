class FinalBug {

final int finalbug;

    FinalBug() {
        this(0);
        finalbug = 111; // if this lacks the compiler  complains
        System.out.println("In FinalBug() this.finalbug = " + this.finalbug);
    }

    FinalBug(int i) {
        finalbug = i;
        System.out.println("In FinalBug(int) this.finalbug = " + this.finalbug);
    }

  public static void main(String[] args) {
      FinalBug f = new FinalBug();
      System.out.println("f.finalbug = " + f.finalbug);
  }
}