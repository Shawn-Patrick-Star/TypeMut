
    private static interface IntA<T> {

        public T test();
    }