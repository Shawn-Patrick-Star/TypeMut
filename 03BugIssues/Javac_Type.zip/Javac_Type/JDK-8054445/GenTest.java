
/**
 *
 * @author Jeric Bryle Sy Dy <jeric@jericbryledy.com>
 */
public class GenTest {

    private static class ClaA {

        public void myMethod() {
            System.out.println("my method");
        }

    }

    private static interface IntA<T> {

        public T test();
    }

    private static interface IntB<T extends ClaA> extends IntA<T> {

    }

    private static class Trash implements IntB {

        @Override
        public Object test() {
            return null;
        }

        // will not work
//        @Override
//        public ClaA test() {
//            return null;
//        }

    }

    public static void main(String[] args) {
        // will work
        //IntA<ClaA> testType = new Trash();

        // will work
        //IntB<ClaA> testType = new Trash();

        // will not work
        IntB testType = new Trash();

        testType.test().myMethod();
    }
}