
    private static class Trash implements IntB {

        @Override
        public Object test() {
            return null;
        }

        // will not work
//        @Override
//        public ClaA test() {
//            return null;
//        }

    }