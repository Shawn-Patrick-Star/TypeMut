
    private static interface IntB<T extends ClaA> extends IntA<T> {

    }