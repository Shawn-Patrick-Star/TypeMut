 
	/**Subclasses are parameterized by their own type*/
	private static abstract class SelfType<T extends SelfType<T>>{
		public abstract T getThis();
	}