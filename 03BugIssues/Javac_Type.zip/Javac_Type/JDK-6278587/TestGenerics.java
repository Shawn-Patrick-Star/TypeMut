
import java.util.*;

public class TestGenerics {
 
	/**Subclasses are parameterized by their own type*/
	private static abstract class SelfType<T extends SelfType<T>>{
		public abstract T getThis();
	}
 
	/**Supertype inherits directly from the parameterized SelfType*/
	private static class SuperType extends SelfType<SuperType>{
		@Override
		public SuperType getThis(){
			return this;
		}
	}
 
	/**Subtype inherits indirectly from the parameterized SelfType*/
	private static class SubType extends SuperType{}
 
	/**Creates a list containing a single SelfType*/
	public static <T extends SelfType<T>> List<T> makeSingletonList(T t){
		return Collections.singletonList(t);
	}
 
	/**
	 * Creates a list containing a single SelfType, allowing the list's
	 * element-type to be a supertype of the type of its single element
	 */
	public static <T extends SelfType<T>,S extends T> List<T> makeSingletonList2(S s){
		return Collections.singletonList((T)s);
	}
 
	public static void main(String[] args){
		/*making lists of super types works fine ...*/
		makeSingletonList(new SuperType());
		List<SuperType> lsup = makeSingletonList(new SuperType());
 
		/*but we can't make a list of sub types; seems weird ...*/
		List<SubType> lsub = makeSingletonList(new SubType()); //ERROR
		/*can't even call it w/o assigning the return value:*/
		makeSingletonList(new SubType()); //ERROR
 
 
		/*so instead, we should be able to make lists of super type containing sub type elements*/
		makeSingletonList2(new SubType()); //ERROR
		/*even if we assign the return value:*/
		lsup = makeSingletonList2(new SubType()); // ERROR (eclipse is okay with this though)
		/*this still doesn't work either:*/
		lsub = makeSingletonList2(new SubType()); // ERROR
 
		/*we can make lists of super type this way though*/
		makeSingletonList2(new SuperType()); // (eclipse doesn't like this though)
		/*also ok if we assign the return value*/
		lsup = makeSingletonList2(new SuperType());
	}
}