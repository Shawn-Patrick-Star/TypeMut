import java.util.ArrayList;

public class ForLoop4Java5 {
  public ForLoop4Java5() {
  }

  public ArrayList  makeList(){
    ArrayList<String> al = new ArrayList<String>(10);
    String currentvalue = "";
    for(int i=0; i<10; i++){
		al.add(i +":: String");
	}
	//al.add(new Double(12.233));
    return al;
  }
  public static void main(String[] args) {
    ForLoop4Java5 forLoop4Java51 = new ForLoop4Java5();
    ArrayList a = forLoop4Java51.makeList();
	    for(int i = 0; i<a.size();i++){
	      System.out.println((Number)a.get(i));
    }
  }

}