import java.util.Comparator;
public class Foo {
    public Foo (Comparator<Object> list, boolean ret) {
    }
}