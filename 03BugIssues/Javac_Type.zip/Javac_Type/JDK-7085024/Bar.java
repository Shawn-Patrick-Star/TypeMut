public class Bar {
    public static void main(String[] args) {
        final Foo f = new Foo(null, (BitSet) null );
    }
}