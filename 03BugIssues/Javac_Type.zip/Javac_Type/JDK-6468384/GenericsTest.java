
import java.util.LinkedHashSet;
import java.util.Set;

public class GenericsTest {

    public class A {};

    public class B extends A {};

    public static void main(String[] args) {
        GenericsTest g = new GenericsTest();
        Set<A> set = g.newSet(g.new B());
    }

    public <T, V extends T> Set<T> newSet(V... objects) {
        Set<T> set = new LinkedHashSet<T>();
        for (T t : objects) {
            set.add(t);
        }
        return set;
    }

}