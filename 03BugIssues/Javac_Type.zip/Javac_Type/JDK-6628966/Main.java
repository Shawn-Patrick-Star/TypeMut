public class Main {

    public static void main(String[] args) {
        E.A.test();
    }

}