public class Config {
	public static Ref<Config> s = new Ref<Config>(new Config());
	public int INTERVAL = 4000;
	
	public Config()
	{
	}
	
	public static void main(String[] args) {
		System.err.println(Config.s.r.INTERVAL); // - > will thrown VerifyError
		//Like this its work
//		Config c = Config.s.r;
//		System.err.println(c.INTERVAL);
	}
}