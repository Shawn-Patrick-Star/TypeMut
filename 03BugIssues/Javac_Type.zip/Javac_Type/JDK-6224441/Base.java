
import java.lang.reflect.*;

class Base {
    public static int X = readDerivedNReflectively();
    static int readDerivedNReflectively() {
        try {
            return Derived.class.getField("N").getInt(null);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }
}