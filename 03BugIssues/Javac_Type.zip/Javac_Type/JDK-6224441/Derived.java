
class Derived extends Base {
    public static final int N = 12;
    public static void main(String[] args) {
        System.out.println(Base.X);
    }
}