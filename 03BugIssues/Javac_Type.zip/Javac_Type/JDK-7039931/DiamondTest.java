
public class DiamondTest {
   static class Foo<T extends Number> {
       <S extends T> Foo(S s) { }
   }


   public static void main(String... args) {
       Object o0 = new <Integer> Foo<>(null); // javac unhappy!
   }
}