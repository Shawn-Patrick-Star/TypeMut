   static class Foo<T extends Number> {
       <S extends T> Foo(S s) { }
   }