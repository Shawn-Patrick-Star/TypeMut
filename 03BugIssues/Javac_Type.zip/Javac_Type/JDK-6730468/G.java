import java.util.*;

public class G {
  public static <U> U fill(U u, List<List<U>> list) {
    list.get(0).set(0, u);
    return u;
  }

  public static void main(String[] args) {
    List<String> l1 =  new ArrayList<String>();
    l1.add("foo");
    List<List<String>> strs = Collections.singletonList(l1);
    fill(1, strs);
    String s = l1.get(0);
  }
}
// thanks to Michael Nascimento for this example