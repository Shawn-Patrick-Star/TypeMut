public class autoboxing {
 static int f (Object o) { return 0; }
 public static void main (String[] args) {
  int i = f(1);
 }
}