
import java.util.*;

import static java.lang.System.out;

public class T2 {

    public static void main(String[] args) {
        Collection c = T2a.m(new ArrayList<String>());  // => "T2a.m"
    }

    static Collection m(List<String> p) {
        out.println("T2.m");
        return null;
    }
}