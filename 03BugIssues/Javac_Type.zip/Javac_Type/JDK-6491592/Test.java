class Test {
    public static void main(String... args) {
        Object o = null;  // o can be any reference type except String
        o += null;
    }
}