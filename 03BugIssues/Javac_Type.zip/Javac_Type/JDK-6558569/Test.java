
class Test<X,Y>{
    public Pair<X,Y> m() {
        return (Pair<X,Y>)new ObjectPair(); // warning missing here
    }

    public static void main(String[] args) {
        Test<String,String> t = new Test<String,String>();
        Pair<String,String> pss = t.m();
    }
}