

// file: Foo.java
public class Foo {
  public static final Bar bar = new Bar();
  public static class Bar {
    private Bar() {}
  }
  public static void main(String[] args) {}
}