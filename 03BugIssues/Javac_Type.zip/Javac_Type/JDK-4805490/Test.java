
class Test {
    public static final String s1 = "abcde";
    public static final String s2 = s1 + s1;
    public static void main(String[] args) {
        if (s2.intern() != s2)
            throw new Error();
    }
}