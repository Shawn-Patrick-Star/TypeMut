

// 1. Save as Bug.java, then:
// javac Bug.java
// java Bug
// 2. SOURCE (follows
// 3. Output:
// mgm@marvin$ java Bug
// bmeth, A.this=A@1dce0622
// Bug.this=null
// java.lang.NullPointerException
//        at Bug$1.bmeth(Bug.java:14)
//        at Bug.test(Bug.java:17)
//        at Bug.main(Bug.java:3)
// mgm@marvin$ 
public class Bug  {
    public static void main(String[] args)  {
	new Bug().test();
    }
    void test()  {
	A anA = new A();

	// b does not get a valid pointer to its enclosing Bug instance!
	// It should have a Bug.this & an A.this
	A.B b = anA.new B() {
	            void bmeth() {
			super.bmeth();
			System.out.println("Bug.this="+Bug.this);
			bugmeth();
		    }
	    };
	b.bmeth();
    }
    void bugmeth() {
	System.out.println("bmeth");
    }
}