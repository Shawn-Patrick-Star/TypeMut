import java.util.*;

public class Test {

  public static <A> Set<A> method(List<? super A> list) {
    return new HashSet<A>();
  }

  public static void main(String[] args) {
    ArrayList<Number> l = new ArrayList<Number>();
    Set<Integer> s1 = method(l);
    Set<Integer> s2 = (Set<Integer>)method(l);
  }
}