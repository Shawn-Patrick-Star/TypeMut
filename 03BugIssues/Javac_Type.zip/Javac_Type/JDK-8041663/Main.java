package scratch;

public class Main {
  public interface SinkStrategy { }

  public interface AccessStrategy extends SinkStrategy { }

  public interface Strategy extends AccessStrategy { }

  public interface Source extends SourceWrapper { }

  public interface SourceWrapper {
    Source with(AccessStrategy strategy);
  }

  public interface SinkWrapper {
    Sink with(SinkStrategy strategy);
    Sink with(AccessStrategy strategy);
  }

  // --> moving SourceWrapper to here causes compilation to succeed

  public interface Sink extends Source, SinkWrapper { }

  public static class Channel implements Sink {
    @Override
    public Sink with(AccessStrategy strategy) {
      System.out.println("access  " + strategy);
      return null;
    }
    @Override
    public Sink with(SinkStrategy strategy) {
      System.out.println("sink " + strategy);
      return null;
    }
  }

  public static void main(String[] args) {
    final Sink channel = new Channel();
    final Strategy s = new Strategy() { };
    channel.with(s);
  }
}