Main.java:
public class Main {
	public static void main(String[] args) {
		a.A myA = new a.A();
		myA.p = myA.vec.get(0);
	}
}

a/A.java:
package a;
import java.util.Vector;
public class A {
	private class P {}
	public P p;
	public Vector<P> vec;
	public A() {
		vec = new Vector<P>();
		vec.add(new P());
	}
}