package test.bugs;

import java.util.Arrays;
import java.util.Collections;

public class ThrowableParameters {
    public static void main(String[] args) {
        Collections.singletonList(Arrays.asList("a", "b", "c").stream()
                .findAny()
                .orElseThrow(() -> new IllegalArgumentException("?")));
    }
}