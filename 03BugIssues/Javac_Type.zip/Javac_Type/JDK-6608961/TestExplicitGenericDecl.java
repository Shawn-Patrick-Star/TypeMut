import java.util.*;

public class TestExplicitGenericDecl {

    private <T> T id(T x) { return x; }

    public static void main(String[] args) {
        TestExplicitGenericDecl a = new TestExplicitGenericDecl();
        Object o = (a.<Object>id("foo")).toString();
        Object o2 = (Collections.<String>emptyList()).toString();
    }
}