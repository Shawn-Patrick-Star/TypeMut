public class Chooser<T> implements Iterable<T> {

  public Chooser(Collection<? extends T> c1,
                Collection<? extends T> c2) {
    this.c1=c1;
    this.c2=c2;
  }
  
  public Iterator<T> iterator() {
    if (c1.size()<c2.size())
      return c1.iterator();
    else
      return c2.iterator();
  }
  
  private final Collection<? extends T> c1;
  private final Collection<? extends T> c2;
  
  public static void main(String[] args) {
    ArrayList<String> l1=new ArrayList<String>();
    Collections.addAll(l1,args);
    
    ArrayList<Integer> l2=new ArrayList<Integer>();
    l2.add(3);
    
    for(Comparable<?> c:new Chooser<Comparable<?>>(l1,l2))
      System.out.println(c);
  }
}