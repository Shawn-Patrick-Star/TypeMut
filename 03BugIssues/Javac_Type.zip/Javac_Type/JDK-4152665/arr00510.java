public class arr00510 {

    public static void main(String[] args) {
        Object a =  new void[2][2];
    }
}