import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import static java.util.Arrays.asList;

public class TestCase {
    public static void main(String... args) {
        new Baz();
    }
}

class Foo<T> {
    public Foo(List<Function<T, Collection>> ts) {

    }
}

class Baz extends Foo<Bar> {
    public Baz() {
        super(asList(Bar::foos));
    }
}

class Bar {
    Optional<List<String>> foos() {
        return Optional.empty();
    }
}