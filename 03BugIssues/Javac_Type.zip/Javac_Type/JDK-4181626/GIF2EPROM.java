*/
public class GIF2EPROM
{
   private static final int FONT_WIDTH  = 16;
   private static final int FONT_HEIGHT = 16;
        private static final int CHARACTER_COUNT = 10 * 4;

        /**
        This function takes an RGB (direct color model) image and obtains
        its palette information and an array of bytes which are indexes
        into the palette. The implementation supports only 8-bit (256 color)
        images.
        */
   private static void getIndexColorData(Image img, byte[] pixels, byte[] byReds, byte[] byGreens, byte[] byBlues)
        {
                Panel dummy                     = new Panel();
           int width                    = img.getWidth(dummy);
                int height                      = img.getHeight(dummy);
                int nPaletteIndex = 0;
                int[] nPixels           = new int[width * height];
                int[] nPalette          = new int[256];
                PixelGrabber pg = new PixelGrabber(img, 0, 0, width, height, nPixels, 0, width);
                
                try
                {
                        pg.grabPixels();
                }
                catch (InterruptedException e) {}

                // Loop through each pixel in the image...
                for (int y = 0; y < height; y++)
                {
                        for (int x = 0; x < width; x++)
                        {
                                int nIndex = -1;

                                // Search for the palette index of the current pixel's color...
                                for (int i = 0; i <= nPaletteIndex; i++)
                                {
                                        if ( nPalette[i] == nPixels[y * width + x] )
                                        {
                                                nIndex = i;
                                                break;
                                        }                        
                                }

                                // If the current pixel's color is not in the palette, add it
                                // to the palette.
                                if ( nIndex == -1 )
                                {
                                        nPalette[nPaletteIndex] = nPixels[y * width + x];
                                        nIndex = nPaletteIndex;
                                        nPaletteIndex++;
                                }

                                // Change the pixel from a color value to an index value.
                                pixels[y * width + x] = (byte) nIndex;
                        }
                }

                for (int i = 0; i < 256; i++)
                {
                        int red   = (nPalette[i] >> 16) & 0xff;
                        int green = (nPalette[i] >> 8 ) & 0xff;
                        int blue  = (nPalette[i]      ) & 0xff;

                        byReds[i]       = (byte)red;
                        byGreens[i] = (byte)green;
                        byBlues[i]      = (byte)blue;
                }
        }

        private static String toHexString(int value)
        {
                String hex = Integer.toHexString(value);

                switch (hex.length())
                {
                        case 1:  hex = "000" + hex;  break;
                        case 2:  hex = "00"  + hex;  break;
                        case 3:  hex = "0"   + hex;  break;
                }

                return "$" + hex.substring(0, 2) + ",$" + hex.substring(2, 4);
        }

        public static void main(String[] args)
        {
      if (args.length != 1)
      {
         System.out.println("Error: Must specify a GIF filename.");
         return;
      }

                Image image = Toolkit.getDefaultToolkit().getImage(args[0]);

                if (image == null)
                {
                        System.out.println("Error: Could not read GIF image.");
                        return;
                }

                try
                {
                        MediaTracker tracker = new MediaTracker(new Panel());
                        tracker.addImage(image, 0);
                        tracker.waitForAll();
                }
                catch (InterruptedException e)
                {
                        System.out.println("Error: Could not read GIF image.");
                }
                
                byte[] pixels = new byte[CHARACTER_COUNT * FONT_WIDTH * FONT_HEIGHT];
                byte[] reds   = new byte[256];
                byte[] greens = new byte[256];
                byte[] blues  = new byte[256];
                BufferedWriter file = null;

                getIndexColorData(image, pixels, reds, greens, blues);

      try
      {
         file = new BufferedWriter(new FileWriter("font.x68"));
                        file.write("\tORG $0000\n\n");

                        for (int i = 0; i < CHARACTER_COUNT; i++)
                        {
                                for (int y = i * FONT_HEIGHT; y < i * FONT_HEIGHT + FONT_HEIGHT; y++)
                                {
                                        String binary = "";
                                        int hex = 0;

                                        for (int x = FONT_WIDTH - 1; x >= 0; x--)
                                        {
                                                try
                                                {
                                                        binary += pixels[y * FONT_HEIGHT + x] == 0 ? System.out.print("1") : System.out.print("0");
                                                        hex = Integer.parseInt(binary, 2);
                                                }
                                                catch (NumberFormatException e) {}
                                        }
System.out.println();
                                        file.write("\tDB " + toHexString(hex) + "\n");
                                }

                                // Create a pad of null bytes to fill in 6 characters of data.
                                // This simplifies the character layout so that each character
                                // set is in its own 512-byte block.
                                // (16*4 characters * 32 bytes per character == 2048 bytes)
                                if ((i + 1) % 10 == 0 && i > 0)
                                {
                                        for (int j = 0; j < 6 * 16; j++)
                                        {
                                                file.write("\tDB " + toHexString(0) + "\n");
                                        }
                                }
                        }

                   file.flush();
              file.close();
                }
           catch (IOException e)
      {
         System.out.println("Error: Could not write to file \"font.x68\"");
      }

                System.exit(0);
        }
}