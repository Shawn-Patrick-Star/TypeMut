
public class foo {
    public static void main(String[] args){
        final int a = 3;
        System.out.print("a = ");
        System.out.println(a);
        System.out.println("a = " + a);
    }
}