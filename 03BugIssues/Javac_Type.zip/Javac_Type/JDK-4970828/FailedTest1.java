//import static java.util.Collections.sort;
import static java.util.Collections.*;

public class FailedTest1 {
    public static void main(String [] args) {
        sort(new java.util.LinkedList<String>());
    }
}