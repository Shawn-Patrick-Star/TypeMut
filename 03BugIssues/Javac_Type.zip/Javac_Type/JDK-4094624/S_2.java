
package Spack;

public class S {
	int i=-1;
	int getI(){ return i; }
	void setI( int j ){ i=j; }
}