// public class S {
// 	int i=-1;
// 	int getI(){ return i; }
// 	void setI( int j ){ i=j; }
// }
public class Ambig2 extends S{
	public static void main( String[] argv ) {
		Ambig2 a = new Ambig2();
		System.out.println(a.i);
	}
}