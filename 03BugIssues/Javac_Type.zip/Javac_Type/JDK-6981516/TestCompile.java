package com.test;

public class TestCompile {

	public static void main(String[] args) {
		Class<?> clazz = (Class<? extends Generic<? super Object>>) Child.class;
	}
}

interface Generic<T>{
}

class Child implements Generic<Integer>{
}