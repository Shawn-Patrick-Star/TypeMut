class Spam {
        private void eggs() {
                System.out.println("Egg on face.");
        }

        public void spam() {
                SubSpam spam = new SubSpam();
                spam.eggs();
        }

        public static void main(String[] argv) {
                Spam spam = new Spam();
                spam.spam();
        }
}