class A<T> {
  static class X {
    static class Q {
      public static void main() {
        System.out.println("A<T>.X.Q");
      }
    }
  }
}

class B extends A<B.Y.Q> {
  static class Y extends X { } // X here is inherited from A
}

class X {
  static class Q {
    public static void main() {
      System.out.println("X.Q");
    }
  }
}

class Main {
  public static void main(String[] args) {
    B.Y.Q.main();
  }
}