package cond_ternary1;

public class Test2 {

  interface I1 {
    void f1();
  };
    
  interface I2 {
    void f2();
  };

  static class CI1 implements I1, I2 {
    public void f1() {
    };
    public void f2() {
    };
  }

  static class CI2 implements I1, I2 {
    public void f1() {
    };
    public void f2() {
    };
  }

  public static void main(String[] args) {
    CI1 ci1 = new CI1();
    CI2 ci2 = new CI2();
    new Test2().invoke_f1_f2_with_CI(true, ci1, ci2);
  }

  void invoke_f1_f2_with_CI(boolean z, CI1 x1, CI2 x2) {
    (z ? x1 : x2).f1();
    (z ? x1 : x2).f2();
  }
}