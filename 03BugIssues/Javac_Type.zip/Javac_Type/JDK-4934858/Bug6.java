import java.util.*;
public class Bug6 {
    static class Path extends LinkedHashSet<String> {}

    public static void main (String[] args) {
	Path path = new Path();
	path.add("foo");
	for (String s : (Iterable<String>) path) System.out.println(s);
	for (String s : path) System.out.println(s);
    }
}