import java.util.List;

public class Main {

    public static void main(String[] args) {
        try {
        } finally {
            List<List<?>> l = null;
            for (List<?> textRegion : l) {
            }
        }
    }

}