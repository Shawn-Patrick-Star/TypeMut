public class GenObject<T>
{
        public void foo(T obj)
        {
                System.out.println("obj = "+obj);
        }
}
public interface TestInterface
{
        void foo(String blah);
}
public class TestObject extends GenObject<String> implements TestInterface
{
        public static void main(String[] args)
        {
                TestObject test = new TestObject();
                TestInterface test2 = test;

                // works
                test.foo("blah");

                // fails with AbstractMethodError
                test2.foo("blah");
        }
}