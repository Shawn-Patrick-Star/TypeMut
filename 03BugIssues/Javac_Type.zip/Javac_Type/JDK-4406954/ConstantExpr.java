*/
 
public class ConstantExpr
{
 
static void println(int i)
    {
    System.out.println("int " + i);
    }
 
static void println(char c)
    {
    int i = c;
    c &= 0x7F;
    c = ((0x20 <= c) && (c <= 0x7E)) ? c : (char) (c ^ 0x40);
    System.out.println("char " + i + " " + c);
    }
 
public static void expectChar()
    {
    String s = null;
    System.out.println();
    System.out.println("Expect char ...");
 
    println(true ? 'a' : 80);
    println((0 == 0) ? 'a' : 80);
    println((null == null) ? 'a' : 80);
    println((s == s) ? 'a' : 80);
    println(true ? 'a' : ((null == null) ? 'P' : 80));
 
    println(true ? 80 : 'a');
    println((0 == 0) ? 80 : 'a');
    println((null == null) ? 80 : 'a');
    println((s == s) ? 80 : 'a');
    println(true ? 80 : ((null == null) ? 'P' : 'a'));
    }
 
public static void expectInt()
    {
    System.out.println();
    System.out.println("Expect int ...");
    println(true ? 'a' : (1 / 0));
    println(true ? 'a' : 123456);
    }
 
public static void main(String[] strings)
    {
    expectChar();
    expectInt();
//  System.out.println('P' == 80);
//  System.out.println('a' == 97);
    }
 
}