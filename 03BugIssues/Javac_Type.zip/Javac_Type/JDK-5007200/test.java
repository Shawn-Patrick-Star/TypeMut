package p;

public class test {
    public static void main(String[] argv) {
        cl_a x = new <String> cl_a(new String("Hello")) {
        };
    }
}