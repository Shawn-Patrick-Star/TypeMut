
abstract class C<T> extends B implements A<T> {
    public void g(T t) {
        f(t);
    }
}