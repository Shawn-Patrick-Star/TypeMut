
class D extends C<Integer> {
    public static void main(String[] args) {
        new D().g(new Integer(3));
    }
}