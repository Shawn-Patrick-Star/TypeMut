class A {
	public static Object create() {
		return null;
	}
}

class B extends A {
	public static<T>  Object create() {
		return null;
	}
	public static void main(String... args) {
		Object b=B.create();
	}
}