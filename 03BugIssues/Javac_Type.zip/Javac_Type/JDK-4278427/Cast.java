
class Cast implements JCast{

  public int foo(){return 23;}

  public static void main(String[] args) {

  JCast j = new Cast();
  KCast k = (KCast) j;
  }
}