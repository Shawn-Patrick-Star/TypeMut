public class Test {
    public static interface C<T> {
        T compute();
    }

    public static <T> T test(C<T> c) {
        return c.compute();
    }

    public static class Wrapper<T> {
        public T value;
    }

    public static <T> T of(T t) {
        return t;
    }
    public static void main(String... args) {
        final Wrapper<String> w = new Wrapper<String>();
        test(new C<String>() {
            public String compute() {
                return w.value = of("test");
            }
        });
    }
}