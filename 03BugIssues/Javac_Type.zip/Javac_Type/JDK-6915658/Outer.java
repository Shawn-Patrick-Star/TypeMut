public class Outer<T>
{    
    public class Inner<U extends T>
    {
        private U data;
        public Inner(U data) { this.data=data; }
        public U getData() { return data; }
    }
    
    public static void main(String[] args)
    {
        Outer<Number>.Inner<Integer> obj=new Outer<Number>().new Inner<Integer>(10);
        System.out.println(obj.getData());
    }
}