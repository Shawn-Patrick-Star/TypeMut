interface A<T>
{
    void foo(T x);
}

interface B<T> extends A<T[]> { }

class C  implements B<Integer>
{
    static <T extends B<?>> void bar(T x)
    {
        x.foo(new String[]{"A"});
    }

    public void foo(Integer[] x)
    {
        int y = x[0];
    }

    public static void main(String[] args)
    {
        bar(new C());
    }
}