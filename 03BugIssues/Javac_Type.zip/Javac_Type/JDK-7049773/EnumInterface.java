
public interface EnumInterface {

	public void doSomething();
}