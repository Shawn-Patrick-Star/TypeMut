public class Main {
	public static void main(String[] args) {
		EnumImplements ei = EnumImplements.A1;
		ei.doSomething();
	}
}