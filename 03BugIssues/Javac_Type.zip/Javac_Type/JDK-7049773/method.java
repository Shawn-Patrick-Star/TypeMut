
The workaround we found was to declare the interface method as abstract in EnumImplements.java:
public enum EnumImplements implements EnumInterface {
	A1 {
		@Override
		public void doSomething() {
		}
	};
        public abstract void doSomething();
}