import java.util.LinkedList;

public class Generic<T extends Object> {
    
    public LinkedList<String> getStrings() {
        return null;
    }

    public static void main(String[] args) {
        LinkedList<String> s = new Generic().getStrings();
        s.toString();
    }
}