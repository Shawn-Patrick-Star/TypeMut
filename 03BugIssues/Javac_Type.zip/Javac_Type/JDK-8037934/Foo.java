class Foo<Outer> {
    void m(){
        class Local1{}
        class Local2 extends Local1{}
        Local2.class.getTypeParameters();
    }
    public static void main(String[] args) {
        new Foo().m();
        System.err.println("Test passed");
    }
}