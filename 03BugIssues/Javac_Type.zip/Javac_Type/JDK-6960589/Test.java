import java.dyn.*;

public class Test {
    static class Greeter extends JavaMethodHandle {
        private final String greetee;
        public void run() { System.out.println("hello, " + greetee); }
        
        Greeter(String greetee) {
            super(RUN);
            this.greetee = greetee;
        }

        private static final MethodHandle RUN = MethodHandles.lookup().findVirtual(Greeter.class, "run", MethodType.make(void.class));
    }
    
    public static void main(String[] args) {
        Greeter greeter = new Greeter("world");
       
        try {
            greeter.<void>invoke();
        } catch(Throwable e) {
            System.out.println("Exception:" + e);
        }
    }
}