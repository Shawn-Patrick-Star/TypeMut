public class Test {
	public static void main(String[] args) {
		Integer i1 = Integer.valueOf((byte)3);  // works fine with all compilers
		Integer i2 = (byte)3;  // works fine with eclipse compiler, not javac
	}
}