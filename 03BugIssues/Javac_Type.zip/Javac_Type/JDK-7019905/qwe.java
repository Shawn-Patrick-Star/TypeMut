import java.util.*;

public class qwe {
    public static void main(String[] args) {
        Map<String, ? extends List<String>> m1 = new HashMap<String, LinkedList<String>>();
        Map<String, ? extends List<String>> m2 = new HashMap<String, LinkedList<String>>();
        // Uncomment next line to reproduce
        //m1.putAll(m2);

        // Workaround:
        Map m1RAW = m1;
        Map m2RAW = m2;
        m1RAW.putAll(m2RAW);
    }
}