import java.util.List;
import java.util.ArrayList;
class FooBase {
  class TestString {
    String str;
    TestString(String strin) {
      str = strin;
    }
  }
}
class Foo extends FooBase {
  public static void main(String[] args) {
    new Foo().run();
  }  
  Foo() {
    super();
  }
  void run() {
    List<String> list = new ArrayList<>();
    list.stream().forEach(TestString::new);
  }
}