
package sXpack;

public class sX {
        protected int sXf = 1;
}