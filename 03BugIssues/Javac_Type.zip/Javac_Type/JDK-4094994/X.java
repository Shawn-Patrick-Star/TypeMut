
import sXpack.sX;

class X extends sX {
  class Y {
    void test() { System.out.println( sXf ); }
  }
  Y oy = new Y();
  public static void main( String[] argv ) {
    X ox = new X();
    ox.oy.test();
  }
}