import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

public class TestFailure {

	@Target(ElementType.TYPE_USE)
	@Retention(RetentionPolicy.RUNTIME)
	public @interface MyAnnot {
	}

	public static abstract class MyCallable {
		protected abstract String getString(int number);
	}

	public static void main(String[] args) {
		System.out.println(new MyTester().createCallable().getString(5));
	}

	public static class MyTester {
		private String getA(){
			return "a";
		}
		
		private String a = "a";

		protected MyCallable createCallable() {
			return new MyCallable() {
				@Override
				protected String getString(int number) {
					return number + getA();
					// or: return number + a;
				}
			};
		}
	}

}