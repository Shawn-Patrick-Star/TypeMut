
public class Literals {
    long x = 0xffffffffffffffffffffffffffffffffffffffffffffffffffL;
    public static void main(String... args) {
	System.out.println(0xffffffffffffffffffffffffffffffffffffffffffffffffff);    
    }
}