// https://gist.github.com/marcomorain/865ce4040f5deaa31751/f8cec8eb082b4fa34fba0f66cf36cc13bb612b09

package com.swrve.test_case;

public class Walker<ResultType, ValueType> {

    public static void main(String[] args) {
    }

    public abstract class Builder<ResultType, ValueType> {
        public abstract class StringVal {
            public abstract String getString(ValueType theVal);
        }
        public abstract ResultType stringEquals(StringVal a, StringVal b);
    }

    private final Builder<ResultType, ValueType> builder;

    public Walker(Builder<ResultType, ValueType> theBuilder) {
        this.builder = theBuilder;
    }

    public ResultType handleBooleanValue() {
        Builder.StringVal a = null;
        Builder.StringVal b = null;
        return builder.stringEquals(a, b);
    }
}