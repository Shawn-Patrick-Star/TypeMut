// Note the order of implementation of I1 & I2

class X {
   public static void main(String[] arg)
    { 
      System.out.println("Done");
    } 
}