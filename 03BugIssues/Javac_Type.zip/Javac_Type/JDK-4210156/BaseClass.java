package package1;

public class BaseClass
{
	protected int pi;
}