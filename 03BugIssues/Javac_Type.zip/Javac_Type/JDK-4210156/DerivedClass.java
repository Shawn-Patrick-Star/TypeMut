package package2;

import package1.BaseClass;

public class DerivedClass extends BaseClass
{
	private class InnerClass extends BaseClass
	{
		public void buggyMethod()
		{
			DerivedClass.this.pi = 5;
		}
	}

	public DerivedClass()
	{
		InnerClass ic = new InnerClass();
		ic.buggyMethod();
	}

	public static void main(String[] s)
	{
		DerivedClass dc = new DerivedClass();
	}
}