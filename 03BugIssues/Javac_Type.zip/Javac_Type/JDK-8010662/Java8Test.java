import java.util.*;

public class Java8Test {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(1, 2, 3);
        List<Integer> transformedList = transformCollection(list, Java8Test::negate);
        System.out.println(transformedList);
    }

    private static int negate(int value) {
        return -value;
    }

    private static <T, C extends Collection<T>> C transformCollection(C collection, CollectionTransformer<T> transformer) {
        C transformedCollection;
        if (collection instanceof RandomAccess) {
            transformedCollection = (C) new ArrayList<T>(collection.size());
        } else if (collection instanceof List) {
            transformedCollection = (C) new LinkedList<T>();
        } else if (collection instanceof SortedSet) {
            transformedCollection = (C) new TreeSet<T>();
        } else if (collection instanceof Set) {
            transformedCollection = (C) new HashSet<T>(collection.size());
        } else {
            transformedCollection = (C) new ArrayList<T>(collection.size());
        }
        for (T object: collection) {
            transformedCollection.add(transformer.transform(object));
        }
        return transformedCollection;
    }

    public interface CollectionTransformer<T> {
        T transform(T object);
    }
}