
class MultipleInterface implements Test1, Test2 {
    public int test(int i) {
        return (i + 4);
    }

    public static void main(String[] args) {
        MultipleInterface my = new MultipleInterface ();
        int r = my.test(67);
        System.out.print("test() method returned: ");
        System.out.println(r);
    }
}