public class Testbed {
	public static void main(String[] args) {
		java.util.List<Dog> l = null;
		Dog d = l.get(0).copy(); // ok
		foo(l.get(0).copy()); // error
	}

	private static void foo(Dog d) { }
}

class Animal {
	public <T> T copy() {
		return null;
	}
}

class Dog extends Animal {
}