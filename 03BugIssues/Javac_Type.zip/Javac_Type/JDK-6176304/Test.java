import java.util.*;
class Test {
   public static void main(String[] args) {
      Set<? extends Integer> s=Collections.emptySet();
   }
}