class Main {
   public static <T> Iterable<T> identity(Iterable<T> iterable) {
        System.out.println("Iterable");
        return iterable;
   }

   public static Object identity(Object object) {
        System.out.println("Object");
        return object;
   }

   public static <E extends Exception> E caughtException() {
        return null;
   }

   public static void main(String... args) {
     identity(caughtException());
   }
}