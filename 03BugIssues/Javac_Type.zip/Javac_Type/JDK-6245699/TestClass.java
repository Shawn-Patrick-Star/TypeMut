public class TestClass {

  public static void main(String[] args) {
    Interface x = new Derived();
    x.method(); // throws AbstractMethodError
  }

  static interface Interface {
    public Base method();
  }
  
  static class Base {
    // Bug only occurs if method is declared final
    public final Derived method() { return null; }
  }
  
  static class Derived extends Base implements Interface {}
}