import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class EnumCase {

	public static void main(String[] args) {
		Builder<String> b = new Builder<String>()
			.addEnumElements(InterEnum.class) // EnumCase.java:[10,3] <E>addEnumElements(java.lang.Class<E>) in EnumCase.Builder<java.lang.String,java.lang.String> cannot be applied to (java.lang.Class<EnumCase.InterEnum>)
			;
		for (Object i : b.build()) {
			System.out.println(((Inter)i).getT());
		}
	}

	static interface Inter<T> {
		T getT();
	}

	static class Builder<T> {
		private final List<Inter<T>> inters = new ArrayList<Inter<T>>();
		<E extends Enum<E> & Inter<T>> Builder<T> addEnumElements(Class<E> interEnum) {
			inters.addAll(Arrays.asList(interEnum.getEnumConstants()));
			return this;
		}
		List<Inter<T>> build() {
			return Collections.unmodifiableList(inters);
		}
	}

	static enum InterEnum implements Inter<String> {
		A("a")
		;
		private final String t;
		private InterEnum(String t) {
			this.t = t;
		}
		public String getT() {
			return t;
		}
	}
}