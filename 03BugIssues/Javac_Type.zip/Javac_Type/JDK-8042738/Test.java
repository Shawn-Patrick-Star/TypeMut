import java.util.*;

public class Test {
	
	interface A {
		void m(int a, int b); 
	}
	interface B {
		int m(int a, int b);
	}
	
	public static void method(A a) { }
	
	public static void method(B b) { }
	
	public static void main(String[] args) {
		// Should only be potentially applicable with type B
		method((a, b) -> a + b);

		// Should only be potentially applicable with type A
		method((a, b) -> {System.out.println("String"); });

		
		// Should only be potentially applicable with type B
		method((a, b) -> {
			if(a < b) 
				return a + b;
			else 
				return a;
		});
    }
}