
abstract class Father<T extends Father>
{
        public void clear(){

        }
}