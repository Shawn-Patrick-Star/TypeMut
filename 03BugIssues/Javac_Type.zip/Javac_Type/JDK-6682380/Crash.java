public class Crash {

        public static void main(String[] argv){
                TreeSet<Father> sons = new TreeSet<Father>();

                try{
                }
                catch(Throwable t){
                }
                finally{
                        for(Father<?> son : sons)
                        {
                                son.clear();
                        }
                }
        }
}