
    // Start of ArrayCast.java

    public class ArrayCast {
        public static void main(String[] args) {
            Integer[] integers = { };
            int[] ints = (int[]) integers;
        }
    }