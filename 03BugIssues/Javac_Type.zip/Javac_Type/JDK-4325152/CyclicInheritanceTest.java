

public class CyclicInheritanceTest  implements
CyclicInheritanceTest.InnerInterface{

  public static void main(String[] args){
    System.out.println(ONE);
    System.out.println(TWO);
    System.out.println(THREE);
  }
  
  public interface InnerInterface{
    public final InnerInnerClass ONE=new InnerInnerClass("ONE");
    public final InnerInnerClass TWO=new InnerInnerClass("TWO");
    public final InnerInnerClass THREE=new InnerInnerClass("THREE");
    
    public class InnerInnerClass{
      public final String txt;
      
      public InnerInnerClass(String txt){
        this.txt=txt;
      }
      
      public String toString(){
        return txt;
      }
    }
  }
}