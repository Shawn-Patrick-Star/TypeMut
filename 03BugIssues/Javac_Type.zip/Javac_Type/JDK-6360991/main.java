import java.util.ArrayList;

public class main {

    public static void main (String [] args) {

        ArrayList<Integer> myArray = new ArrayList<Integer>();
        for (Integer elem : myArray) {
            elem.toString();
        }

    }

}