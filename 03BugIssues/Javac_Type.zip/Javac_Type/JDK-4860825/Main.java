
class Main {
    public static void main(String[] args) {
        Derived d = new Derived();
        Base b = d;
        b.f()[0] = new Box<String>("hello");
        Integer i = d.f()[0].value;
    }
}