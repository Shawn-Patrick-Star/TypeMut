public class GenericsJavacIssue {

	public static void main(String[] args) {
		final GenericsJavacIssue instance = new GenericsJavacIssue();
		instance.test1(instance.new Foo<FredI>());
	}

	@SuppressWarnings("unchecked")
	private <T extends FredI> void test1(FooI<T> foo) {
		test((FooI<GeorgeI>) foo);	//This line fails to compile
		//Replacing code with this nasty double cast does compile
		test((FooI<GeorgeI>) (FooI<? extends GeorgeI>) foo);
	}

	private void test(FooI<GeorgeI> foo) {
		System.out.println("OK");	//Running this code in eclipse works, OK is printed to the console.
	}

	private interface GeorgeI {
	}

	private interface FredI extends GeorgeI {
	}

	private interface FooI<T> {
	}

	private class Foo<T> implements FooI<T> {
	}
}