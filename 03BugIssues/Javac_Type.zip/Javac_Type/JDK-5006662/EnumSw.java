
enum EnumSw {
    foo, bar, baz;

    public static void main(String[] args) {
        EnumSw e = null;
        try {
            switch (e) {
            default: break;
            }
            throw new Error("failed to throw NullPointerException");
        } catch (NullPointerException ex) {
            System.out.println("passed");
        }
    }
}