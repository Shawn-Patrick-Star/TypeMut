*/

import java.lang.*;

class increment {

  public static final short maxShort = 0x7FFF;

  public static void main (String[] args) 
  {
    short x1 = maxShort, x2 = maxShort, x3 = maxShort;
    x1++;
    x2 += 1;          //    <---  this will be incorrect!
    x3 = (short)(x3+1);
    System.out.println ("x1 = " + x1 +   //  -32768 : ok
                      ", x2 = " + x2 +   //   32768 : ?!?!?
                      ", x3 = " + x3 );  //  -32768 : ok
  } // main

}