AutoCloseableBug.java:

public class AutoCloseableBug {
    public static void main(String[] args) {
        System.out.println( " hello " );
        try (TheBug<RuntimeException> bug = new TheBug<>()) {
            System.out.println( " [with bug] " );
        }
        System.out.println( " world " );
    }
    private static class TheBug<E extends Exception> implements AutoCloseable {
        @Override
        public void close() throws E {
            System.out.println( " [closing] " );
        }
    }
}

Compare to AutoCloseableNoBug.java, which compiles and runs as expected:

public class AutoCloseableNoBug {
    public static void main(String[] args) {
        System.out.println( " hello " );
        TheBug<RuntimeException> bug = new TheBug<>();
        try {
            System.out.println( " [with bug] " );
        } finally {
            bug.close();
        }
        System.out.println( " world " );
    }
    private static class TheBug<E extends Exception> implements AutoCloseable {
        @Override
        public void close() throws E {
            System.out.println( " [closing] " );
        }
    }
}