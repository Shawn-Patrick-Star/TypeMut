package a.b.c;

public class X {
   void hi() {System.out.println("hello");}
}