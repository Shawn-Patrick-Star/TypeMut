import a.b.c.*;

class Test {
   public static void main(String[] args) {
      new X().hi();
   }
}