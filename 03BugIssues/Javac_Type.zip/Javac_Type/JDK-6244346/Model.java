
import java.util.*;

class Model<T> {
    public List<String> getContent() { return null; }
    public static void main(String[] args) {
        Model m = null;
        List<String> l = m.getContent(); // <-- unchecked warning!
    }
}