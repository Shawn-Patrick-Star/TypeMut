class Main {
  public static void main(String[] args) {
    new TV().go();
  }
}

class TV {
  void go() {
    System.err.printf("Result: %s\n", foo("Frump").doit().it());
  }

  <R> I foo(R r) {
    return () -> new C() {
      R cr = r;
      @Override
      Object it() { return cr; };
    };
  }
}

interface I {
  C doit();
}

abstract class C {
  abstract Object it();
}
