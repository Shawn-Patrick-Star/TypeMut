interface FirstInterface <O,N> {
    public O find(N number);
}

interface SecondInterface <T extends CharSequence> extends FirstInterface<String, Integer> {
    public String convert(T charSequence);
}


class SecondClass implements SecondInterface<StringBuilder> {
    public String find(Integer i) { return null; }
    public String convert(StringBuilder stringBuilder) { return null; }
}

class X {
    public static void main(String[] args) {
        SecondInterface secondInterface = new SecondClass();
        secondInterface.find(new Integer(1));
        String s = secondInterface.find(new Integer(1));
    }
}