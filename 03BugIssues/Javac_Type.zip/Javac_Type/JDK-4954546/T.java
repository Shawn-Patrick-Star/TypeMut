     2  class T {
     3      interface I { void f(); }
     4      interface J { void g(); }
     5      static class A implements I, J { public void f(){} public void g(){} }
     6      static class B implements J, I { public void f(){} public void g(){} }
     7      public static void main(String[] args) {
     8          f(true, new A(), new B());
     9      }
    10      static void f(boolean cond, A a, B b) {
    11          (cond?a:b).f();;
    12          (cond?a:b).g();;
    13      }
    14  }