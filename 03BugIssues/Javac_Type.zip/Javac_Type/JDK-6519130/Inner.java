  private static class Inner extends Outer {
    void print() { System.out.println("Should be OK"); }
  }