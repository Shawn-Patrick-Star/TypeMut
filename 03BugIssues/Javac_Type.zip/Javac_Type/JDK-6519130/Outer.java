
package transaction;

abstract class Outer {
  static Inner factory() { return new Inner(); }
  abstract void print();
  private static class Inner extends Outer {
    void print() { System.out.println("Should be OK"); }
  }
}