
public class VisibilityTest {
  public static void main (String[] args) {
    final Outer o = Outer.factory ();
    o.print (); // OK - can also make Inner have package access or above
    Outer.factory().print(); // Kicks up
  }
}