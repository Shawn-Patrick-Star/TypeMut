
public class test {

void foo(){
  boolean b = false;
  Class a =  b ? A.class : B.class;
  System.out.println("a is " + a.getName());
}

public static void main(String[] args)
{
 new test().foo();
 }

}