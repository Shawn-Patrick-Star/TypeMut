

package testlab;

public class Test1 {

  public Test1() {
  }

  public int testMethod(Object obj) {
    return 0;
  }

  public int testMethod(String str) {
    return 1;
  }

/*  // Uncomment to get javac error, otherwise no error is thrown though
ambiguity exists
  public int testMethod(Test1 str) {
    return 2;
  }
*/
  public static void main(String[] s) throws Exception {
    Test1 test = new Test1();
    System.out.println(test.testMethod(null));

    Embed2 e2 = new Embed1();
    Embed3 e3 = new Embed1();
    System.out.println(e2.testT());
    System.out.println(e3.testT());
  }


  static class Embed1 implements Embed2, Embed3 {
    public int testT() {
      return 1;
    }
/*
    public int test2() {
      return 2;
    }
    public Object testlab.Embed2.test2() {  // ??????????? - how to resolve
ambiguity in implementation?
      return null;
    }
*/
  }

  interface Embed2 {
    public int testT();
//    public Object test2();
  }
  interface Embed3 {
    public int testT();
//    public int test2();
  }

}