public class TryCatchFinally {
    public void misBehave() {
	try {
	    throw new Exception("");
	} finally {
	    return;
	}
    }
    public static void main (String[] args) {
	new TryCatchFinally().misBehave();
    }
}