// Nesting a class within a method
interface Destination // package access
{
  Object readLabel(); // implicitly public
}
public class Parcel
{
  public Destination destination(String s)
  {
    class PDestination implements Destination
    {
      private Parcel p = new Parcel(); // outer class available here
      private String label;
      private PDestination(String whereTo) {label = whereTo;} // non-default and sole constructor
      public String readLabel() { return label; } // must be public, like in the implemented interface
      void f() throws ClassNotFoundException, InstantiationException, IllegalAccessException
      { // private will give a compile error
        System.out.println("PDestination f()");
        p.f();
      }
    }

    return new PDestination(s);
  }
  private void f() {System.out.println("Parcel f()");}

  public static void main(String[] args) throws
  ClassNotFoundException, InstantiationException, IllegalAccessException
  {
    Parcel p = new Parcel();
    Destination d = p.destination("Tasmania");
    System.out.println(d.readLabel());
//    PDestination pDest = new PDestination("Uganda"); // PDestination not available inside Parcel
    Class pDestClass = Class.forName("Parcel$1PDestination"); // see the name of the .class file
//    Object obj = pDestClass.newInstance(); // java.lang.InstantiationException (at run time, compile OK)
    ((Parcel$1PDestination)d).f(); // first comment this line, compile, uncomment it, then recompile
  }
}
/*
javac Parcel.java
java Parcel
Tasmania
PDestination f()
Parcel f()
*/