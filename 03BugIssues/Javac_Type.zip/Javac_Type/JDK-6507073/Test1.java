package test;

import java.util.Collection;
import java.util.HashSet;

public class Test1
{

	public static void main(String[] args)
	{
		new Test1(HashSet.class);
	}

	public Test1(Class<? extends Collection<?>> aClass)
	{
	}
}