    11  class Test {
    12      public static void main(String[] args) {
    13          Collection<Integer> c1 = null;
    14          Collection<Number> c2 = Collections2.umc(c1);
    15      }
    16  }