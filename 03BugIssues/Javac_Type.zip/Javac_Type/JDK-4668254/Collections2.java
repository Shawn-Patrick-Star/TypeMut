     3  class Collections2 {
     4      // proposed signature for Collections.unmodifiableCollection
     5      public static <T, S extends T> Collection<T>
     6                                  umc(Collection<S> c) {
     7          return null;
     8      }
     9  }