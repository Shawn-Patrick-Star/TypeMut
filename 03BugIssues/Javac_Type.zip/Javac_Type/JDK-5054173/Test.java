import java.util.Map;
public class Test {
   public static void main(String[] args) {
     Map m = null;
     Map m2 = m.getClass().newInstance();
   }
}