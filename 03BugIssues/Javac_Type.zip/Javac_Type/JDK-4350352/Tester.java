
*** SOURCE CODE ***
package cwhitmer.test;

public class Tester {
  public static void main( String[] args ) {
    Tester.class = null;
  }
}