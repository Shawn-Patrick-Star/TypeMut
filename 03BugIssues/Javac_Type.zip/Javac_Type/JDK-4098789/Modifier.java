public abstract class Modifier{

  public static void main(String [] args){

    System.out.println("This is the Main Method...");


  }


 private final abstract void doesItWork();
    //abstract method
  
}