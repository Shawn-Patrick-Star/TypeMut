     1  class Test {
     2      public static void foo(int ...i) {}
     3      public static void foo(double...d) {}
     4
     5      public static void main(String[] args) {
     6          foo(1, 2, 3);
     7      }
     8  }