
 
public class WildcardCallRestrictions2 
{
    public static void main(String[] args) 
	 {
		_Ref<? super String> con = null;
		String str = "Your hair is on fire!";
		str = con.deref();     // <<fail>> 
    }
}