
public class Test {
    
    private abstract interface X {
        static abstract class Y {
            private abstract class Z {}
        }
    }
    
    private static abstract class A {
        private static class B extends Test.X.Y {
            private class C extends Test.X.Y.Z {}
        }
    }
    
    /** Creates a new instance of Test */
    public Test() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}