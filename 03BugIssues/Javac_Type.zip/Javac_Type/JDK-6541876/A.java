    
    private static abstract class A {
        private static class B extends Test.X.Y {
            private class C extends Test.X.Y.Z {}
        }
    }