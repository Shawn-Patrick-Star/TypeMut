public class Test {
 public static void main(String[] args) {
   for (E e : E.values()) {
     e.m();
   }
 }
}