public class EmptyAsList {
  public static void main(String... args) {
    java.util.Arrays.asList();
  }
}