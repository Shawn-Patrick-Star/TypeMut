package name.slacroix;

import java.util.Arrays;
import java.util.Comparator;

public class C3 {
    static protected long[][] arrayMap = new long[100][2];

    public static void main(String[] args) {
            int indexFound = Arrays.binarySearch(arrayMap, 1, comparator);
    }
    static protected Comparator<long[]> comparator = new Comparator<long[]>(){
            public int compare(long[] a, long[] b) {
                return 1;
            }
        };
}