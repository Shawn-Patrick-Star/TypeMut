
public class JavacTest {
    public static void main(String[] args) {
        IBar b = new Bar();
        String x = b.doIt();
    }
}