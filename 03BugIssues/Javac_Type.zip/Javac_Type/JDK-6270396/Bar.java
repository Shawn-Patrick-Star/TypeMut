
class Bar extends Foo<String> implements IBar {
}