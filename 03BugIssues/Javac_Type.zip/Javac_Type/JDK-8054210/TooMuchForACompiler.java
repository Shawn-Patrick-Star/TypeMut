import java.util.function.Consumer;

public class TooMuchForACompiler {

    public interface Supplier<T, E extends Exception> {       
        T get() throws E;
    }

    public static <T, E extends Exception> T produceAndConsume(Supplier<T, E> supplier, Consumer<E> handler) {
        try {
            return supplier.get();
        } catch (Exception e) {
            handler.accept((E) e);

        }
        return null;
    }

    public static void main(String... args) {
        produceAndConsume(() -> -1, i -> System.out.println(i.getMessage()));
    }

}