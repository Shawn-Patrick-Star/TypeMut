/*
 * Compiling this program with the 1.7.0_05 Java compiler, at least on Linux
 *  x86_64, causes the compiler to abort due to a NullPointerException.
 *
 * To reproduce the NPE, compile with:
 *  javac SwitchString.java
 *
 * This test case was constructed to test the use of strings in switch
 *  statements as provided by Java 7 language enhancements.  It was drafted
 *  based on the following clauses from JLS 7 (JSR-000901):
 *
 * 14.11 The switch Statement
 * ...
 * These labels are said to be associated with the switch statement, as are
 * the values of the constant expressions (15.28) or enum constants (8.9.1)
 * in the case labels.
 *
 * 15.28 Constant Expressions
 * ...
 * A compile-time constant expression is an expression denoting a value of
 * primitive type or a String that does not complete abruptly and is composed
 * using only the following:
 * ...
 * - Casts to primitive types and casts to type String (15.16)
 *
 * The cast to String in the case label below has no semantic relevance, but
 *  is permitted according to JLS 7 (JSR-000901)
 */

public class SwitchString {
    public static void main(String [] args) {
        switch (args[0]) {
            case (String)"text":
                break;
        }
    }
}