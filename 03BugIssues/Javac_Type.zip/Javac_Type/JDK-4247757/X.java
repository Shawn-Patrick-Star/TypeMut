class X {
  int s=0;
  X() { s=0; }
  int test() {
    class Y { //enclosing class is X
     Y() { s=1; }
     int test() {
        class Z { // enclosing instance is Y
          Z() { new X().super(); }
          int test() { return s; }
        }
        // javac error message:
        // X.java:14: Class X. 1$Z not found in type declaration.
        return new Z().test();
      }
    }
    return new Y().test();
  }
  public static void main(String[] s) {
    X x=new X();
    System.out.println(x.test());
  }
}