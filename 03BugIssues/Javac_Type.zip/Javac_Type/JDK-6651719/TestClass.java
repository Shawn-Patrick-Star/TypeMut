class TestClass {

    public static void main(String... args) {
        MyClass<? extends MyClass<?, ?>, ? extends MyClass<?, ?>> gg = null;
    }
}