public class Foo {

  public static void main(String[] args) {
    Set<String> set1 = newSet1(); // fails
    Set<String> set2 = newSet2(); // succeeds

    Map<String, Integer> map1 = newMap1(); // fails
    Map<String, Integer> map2 = newMap2(); // fails
    Map<String, Integer> map3 = newMap3(); // succeeds
  }

  static <E extends Comparable<? super E>> Set<E> newSet1() {
    return new Set<E>();
  }

  static <E extends Comparable<E>> Set<E> newSet2() {
    return new Set<E>();
  }

  static <K extends Comparable<? super K>, V extends Comparable<? super V>>
      Map<K,V> newMap1() {
    return new Map<K,V>();
  }

  static <K extends Comparable<K>, V extends Comparable<V>> Map<K,V> newMap2() {
    return new Map<K,V>();
  }

  static <K extends Comparable<K>, V extends Comparable<?>> Map<K,V> newMap3() {
    return new Map<K,V>();
  }

}

class Set<E> {}

class Map<K,V> {}