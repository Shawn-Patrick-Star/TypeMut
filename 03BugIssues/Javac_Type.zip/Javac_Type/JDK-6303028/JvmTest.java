package test;

public class JvmTest {
    public static Long parseLong(String s) {
        return (s == null) ? (Long) null : Long.parseLong(s);
    }

    public static void main(String[] args) {
        System.out.println(parseLong(null));
    }
}