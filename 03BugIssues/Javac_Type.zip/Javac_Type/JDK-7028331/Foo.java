package com.foo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Foo {
    public static void main(String[] args) {
        List<Comparator<? super String>> list = buildList(new SomeComparator<String>("bar"));
        boolean b = contains(
                list,
                new SomeComparator<String>("x"));
        System.out.println(b);
    }

    public static <T> boolean contains(List<T> objects, T object) {
        return objects.contains(object);
    }

    public static <T> List<Comparator<? super T>> buildList(Comparator<? super T>... comparator) {
        return Arrays.asList(comparator);
    }

    private static class SomeComparator<T> implements Comparator<T> {
        public SomeComparator(T arg) {}
        public int compare(T o1, T o2) { return 0; }
    }
}