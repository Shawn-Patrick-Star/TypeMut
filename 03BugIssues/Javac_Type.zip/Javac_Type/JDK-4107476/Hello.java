
    public class Hello {
       public static void main (String[] args) {
          F3 f = new C();
          f.method(); 
       }
    }