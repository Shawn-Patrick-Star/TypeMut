
package desdemona;

public class Main {
    static protected int staticProtectedMainRoutine() {
       return 1;
    }
}