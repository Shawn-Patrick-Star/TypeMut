
package othello;

public class M2 extends desdemona.Main {
    public static void main (String[] args) {
        int x = desdemona.Main.staticProtectedMainRoutine();
    }
}