/*
 * Object.java
 *
 * Created on June 30, 2007, 7:21 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author Shree
 */
package java.lang;

 class Object {
    
    /** Creates a new instance of Object(?) */
    public Object() {
       // super(); // got compiler error for this line
        this("hello");
        System.out.print("here");
    }
    public Object (String s) {
        System.out.println("Object constructor overloaded successfully !!");
    }
     public static void main(String[] args){
         Object obj =new Object();
         
     }
}