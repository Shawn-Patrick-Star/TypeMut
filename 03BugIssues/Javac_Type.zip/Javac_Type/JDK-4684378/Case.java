     2  public class Case
     3  {
     4  public static void main(String[] argv)
     5  {
     6  Stack<String> bar = new Stack<String>();
     7  String foo;
     8
     9  // Compiles, but causes verify error
    10  foo=(bar.empty()?"":bar.peek()).intern();
    11
    12  // The following two work fine
    13  foo = (bar.empty()?"":bar.peek().intern());
    14  foo = (bar.empty()?"":(String)bar.peek()).intern();
    15  }
    16  }