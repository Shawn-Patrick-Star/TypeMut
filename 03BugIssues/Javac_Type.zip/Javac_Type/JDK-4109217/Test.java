
public class Test extends Object {
  public static void main(String[] args) {
    final String aa = "aa";
    System.out.println(aa + "bb");
  }
}