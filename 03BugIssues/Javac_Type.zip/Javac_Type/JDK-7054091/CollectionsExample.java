import java.util.*;

public class CollectionsExample {
    public static void main(String[] args) {
        int[] a = {1,2,3,4};
       
        // Fails
        Collection<? extends Class<?>> collection = (Collection<? extends Class<?>>) Arrays.asList(a);

        // Works
        //List list = Arrays.asList(a);
        //Collection<? extends Class<?>> collection = (Collection<? extends Class<?>>) list;
    }
}