
class NulltoString {

public String toString(){
  return null;
}

public static void main(String[] args){
  NulltoString m = new NulltoString();
  String s = ""+m;
  if(s==null){
	System.err.println("s is null");
  } else if(s.equals("null")){
	System.err.println("s is \"null\"");
  } else {
	System.err.println("s is "+s);
  }
}

}