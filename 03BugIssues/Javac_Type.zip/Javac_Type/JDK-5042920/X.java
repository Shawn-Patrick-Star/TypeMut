
/////////////////////////////////////////
public class X {
   public static void main(String[] args) {
       String s = new X().foo().bar();
   }
   <V extends X> V foo() {
       return null;
     }
   String bar() {
       return "";
   }
}