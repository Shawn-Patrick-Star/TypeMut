
import java.util.List;
import java.util.ArrayList;

class ListOfListTest {

   public static void main(String[] argv) {
      List<List<Integer>> ll = new ArrayList<List<Integer>>();
      List<Integer> il = new ArrayList<Integer>();
      ll.add(il);
      il.add(1);
      for (Integer i : ll.get(0)) {
         System.out.println(i);
      }
   }
}