
public class Pair<X,Y>{
    Pair(){}
    Pair<? extends X,? extends Pair<X,Y>> get(){ return null;}

    public static void main(String[] s){
        Pair<? extends Integer,? super String> p=new Pair<Integer,String>();
        Pair<? extends Integer,? super String> p2=p.get();
        // Should return a Pair<? extends Integer,? extends Pair<? extends Integer,? super Number>>
    }
}