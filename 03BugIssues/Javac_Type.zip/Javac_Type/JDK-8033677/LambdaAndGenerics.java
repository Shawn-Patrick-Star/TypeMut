public class LambdaAndGenerics {
    public static interface Predicate<T> {
        boolean test(T t);
    }
    public static <I, T extends I> I lambdaWrapper(final T lambda) {
        return lambda;
    }
    public static void main(String[] args) {
        new DoesNotFail<String, Integer>().start();
        new Fails().start();
    }

    /**
     * Works fine for N, M declared for a class
     */
    static class DoesNotFail<M, N> {
        void start() {
            System.out.println(one(lambdaWrapper(e -> false)));  // compiler works-out types correctly
        }
        String one(Class<N> arg) {
            return "DoesNotFail class: " + arg;
        }
        String one(Predicate<M> arg) {
            return "DoesNotFail predicate: " + arg.test(null);
        }
    }

    /**
     * Fails when N, M are declared for methods
     */
    static class Fails {
        void start() {
            System.out.println(one(lambdaWrapper(e -> false)));  // COMPILER ERRORS "reference to one is ambiguous" + "cannot infer type variables"
            // one(null);  // COMPILER ERROR "reference to one is ambiguous" which is correct
        }
        <N> String one(Class<N> arg) {
            return "Fails class: " + arg;
        }
        <M> String one(Predicate<M> arg) {
            return "Fails predicate: " + arg.test(null);
        }
    }
}