public class Wonk {
        public static void main(String[] args) {
                double prim = 1.1;
                Double boxed = 2.2;
                prim += boxed;
                                                                                
                System.out.printf("boxed=%4f prim=%4f\n", boxed, prim);
        }
}