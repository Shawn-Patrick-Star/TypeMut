
public abstract class B {
    private abstract void f (); // now OK?

    static class C extends B {
        void f () { // implements private abstract method
        }
    }

    public static void main (String[] args) {
        B b = new C();
        b.f();
    }
}