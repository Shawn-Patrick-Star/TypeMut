
    static class C extends B {
        void f () { // implements private abstract method
        }
    }