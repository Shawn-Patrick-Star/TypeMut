public class X extends A {
public static void main( String[] argv ) {
        X ob = new X();
        try { ob.s(0); }
        catch (Exception e) { System.out.println(e); }
        try { ob.s(1); }
        catch (Exception e) { System.out.println(e); }
} 
void s(int i) throws NullPointerException,IllegalArgumentException {
        if (i==0) throw new NullPointerException();
        else if (i==1) throw new IllegalArgumentException();
}
}