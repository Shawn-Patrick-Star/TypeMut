
class One {
    class Two extends One {
        { System.out.println(One.this); }
    }
    class Three extends Two {
        { new Two(); }
    }
    public static void main(String[] args) {
        One o = new One();
        System.out.println(o + " " + o.new Three());
    }
}