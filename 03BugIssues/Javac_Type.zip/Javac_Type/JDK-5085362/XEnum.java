XEnum.java
public enum XEnum {
    XA, XB
}

YEnum.java
public enum YEnum {
    YA, YB
}

Test.java:
import static XEnum.XA;
import static YEnum.YA;

public class Test {
    public static void main(String[] args) {
        method(XA);
        method(YA);
    }

    static void method(XEnum x){};
    static void method(YEnum y){};
}