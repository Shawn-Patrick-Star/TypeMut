
import java.lang.annotation.*;

@Target({ElementType.TYPE_USE, ElementType.TYPE_PARAMETER})
@interface Anno {}

class AnnoTest {
    public <T> AnnoTest() {}
    public static void main(String... args) {
        AnnoTest test = new <@Anno Integer> AnnoTest();
    }
}