
public class Tester {
   protected static final int foo[] = {1,2,3,4,5,6};
   
   public static void main(String[] args) {
      switch (args.length) {
         case foo[0]:
         case foo[1]:
         case foo[2]:
         case foo[3]:
         case foo[4]:
         case foo[5]:
         default:
            System.out.println("bar");
            break;
      }
   }
}