
// DIFFERENT SOURCE FILE
public interface TestInterface {

	static char myChar = 'A';
}