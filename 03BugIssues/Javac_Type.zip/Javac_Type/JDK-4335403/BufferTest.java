
public class BufferTest implements TestInterface{

	public static void main(String[] args){

		StringBuffer sb = new StringBuffer();
		sb.append(myChar);

		String var = "VAR";
		sb.append("\n" + var + " " + myChar);

		sb.append("\nHARD CODE: " + myChar);

		System.out.println("Result is: " + sb.toString());
	}
}