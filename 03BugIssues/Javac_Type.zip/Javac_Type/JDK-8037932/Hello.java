import java.util.ArrayList;
import java.util.List;

public class Hello {

    public static void main(String[] args) {
        foo((true ? new ArrayList<String>() : new ArrayList<CharSequence>()));
    }

    static <T> void foo(List<T> l) {
    }
}