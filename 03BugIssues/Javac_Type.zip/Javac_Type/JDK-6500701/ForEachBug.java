import java.util.ArrayList;
import java.util.List;

public class ForEachBug {
	public class A {}

	public class B {}

	public static void main(String[] args) {
		new ForEachBug().reproduceBug();

	}

	private void reproduceBug() {
		List list = new ArrayList();
		list.add(new B());
		List<A> aList = new ArrayList<A>();
		aList.addAll(list);
		for (Object a : aList) {
			System.out.println(a);
		}
	}

}