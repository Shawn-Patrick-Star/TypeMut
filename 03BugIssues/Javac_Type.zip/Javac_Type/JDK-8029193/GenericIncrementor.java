//Generic Class

import java.util.List;

public class GenericIncrementor<T extends Object> {

    public <T>  java.util.List<T> listIncrement(List<Long> param) {
        for (Long l : param){
            long incremented = l + 1L;
            System.err.println( "Incremented: " + incremented);
        }
        return null;
    }

}
//Test class

import java.util.LinkedList;

public class genericTest {



    public static void main(String ... args) {
        LinkedList<String> ids = new LinkedList<>();
        ids.add("1");
        ids.add("2");
        ids.add("3");
        ids.add("4");

        GenericIncrementor<Object> longTest = new GenericIncrementor();
        //This throws a compiler Bug
        ///longTest.listIncrement(ids);

        //This does not
        GenericIncrementor collTest = new GenericIncrementor();
        collTest.listIncrement(ids);


    }

}