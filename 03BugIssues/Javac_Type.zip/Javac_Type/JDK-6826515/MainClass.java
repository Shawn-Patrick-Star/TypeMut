package untitled1;

import java.util.*;

public class MainClass {
  private HashMap<Client,Captioner>	captioners = new HashMap<Client,Captioner>();
  private HashMap<Short,Client>	mrfClientByAddress = new HashMap<Short,Client> ();
  
  private void processText (Object packet) {
    Short author = new Short((short) 1);
    Client captionerClient = mrfClientByAddress.get(author);
    if (captionerClient != null) {
      String captionerName = captionerClient.getDisplayName();
      Captioner captioner = captioners.get(captionerName);
      if (captioner == null) {
        captioner = new Captioner(author);
        captioners.put(captionerClient, captioner);
      }
    }
    System.out.println("Executed");
  }
  
  public static void main (String [] args) {
    new MainClass().processText(new Object(){});
  }
}

package untitled1;

public class Client {
  public String getDisplayName() {
    return "String";
  }
}

package untitled1;

public class Captioner {
  public Captioner(short num) { }
}