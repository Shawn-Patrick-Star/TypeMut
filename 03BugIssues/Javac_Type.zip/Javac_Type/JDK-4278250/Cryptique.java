

public class Cryptique {

    // if you have a method such as:   
    
    public static void testFunction(Object[] thing, Object[] anotherThing) {
    
    }

    public static void main(String[] args) {
        
        // ...and in the calling code you have:

        String[] test = new String[] {"Hello", "there"} ;
        int[] numbers = new int[] {1,2,3} ;
        
        testFunction (test, numbers) ;
    }
}