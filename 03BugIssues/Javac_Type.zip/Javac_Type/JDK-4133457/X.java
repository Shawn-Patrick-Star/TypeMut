
//X.java:
class X
{
    int m=101;
	
  
   class Z
   {
    int m=100;

    void test()
    {
     new Z()
     {
      int m=200;
      void test()
      {
       Chk.chkIntVal("err1","m",m,200);
       super.m = 1;
       Chk.chkIntVal("err2","super.m",super.m,1);
       Chk.chkIntVal("err3","Z.this.m",Z.this.m,100);
       Chk.chkIntVal("err4","X.this.m",X.this.m,101);
      }
     }.test();
    }
 }
void xtest()
	{
		new Z().test() ;
	}
   
   public static void main(String[] s)
   {
     new X().xtest();
   }
 
 }