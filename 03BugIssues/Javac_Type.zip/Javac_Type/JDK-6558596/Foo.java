
public class Foo {
  public static void main(String[] args) {
    Bar bar = new Bar(); 
    bar.add("Hello");
    bar.add("Hello, world", "Buddy");
  }
}