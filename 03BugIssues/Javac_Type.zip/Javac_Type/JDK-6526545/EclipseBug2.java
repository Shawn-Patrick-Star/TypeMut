public class EclipseBug2 {
    enum MyEnum {
      value;
    }

    enum AnotherValue {
      value2;
    }

    static abstract class A<T> {
      abstract <U extends T> U empty();
    }

    static class B extends A<Enum<?>> {
      @Override
      Enum<?> empty() {
        return MyEnum.value;
      }
    }

    public static void main(String[] args) {
      A<Enum<?>> a=new B();
      AnotherValue value2 = a.empty();
    }
}