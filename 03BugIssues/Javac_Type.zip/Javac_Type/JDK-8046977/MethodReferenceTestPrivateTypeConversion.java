
public class MethodReferenceTestPrivateTypeConversion {

    interface ISi { int m(Short a); }
    
    public static void main(String[] args) {
      (new MethodReferenceTestPrivateTypeConversion()).testUnboxObjectToNumberWiden();
    }

    public void testUnboxObjectToNumberWiden() {
        ISi q = (new E<Short>())::xI;
        q.m((short)77);
    }
    
    class E<T> {
        private T xI(T t) { return t; }
    }
}