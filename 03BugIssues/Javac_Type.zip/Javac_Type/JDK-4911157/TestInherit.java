
public class TestInherit extends LinkedList<TestItem> {
    public static void main(String[] args) {
        TestInherit test = new TestInherit();
        
        test.add(new TestItem());

        // Works
        Iterator<TestItem> iter = test.iterator();
        while (iter.hasNext()) {
            TestItem item = iter.next();
            System.err.println(item);
        }

        // Doesn't work
        for (TestItem item : test) {
            System.err.println(item);
        }
    }
}