import java.util.*;

public class Thingy {

    public static void main(String[] args) {
        List<Integer> myIntegerList = Arrays.asList(1,2,3,4,5,6);

        int sum = myIntegerList.stream().reduce(0, (a, b) -> a + b, (c, d) -> c + d);

        System.out.println(sum);
    }
}