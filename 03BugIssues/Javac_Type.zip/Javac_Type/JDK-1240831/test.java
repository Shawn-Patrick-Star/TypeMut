package p1;
 
public class test {
    public static void main(String[] args) {
 
        Broken b = new p2.TimeBomb();
 
        b.f();
    }
}