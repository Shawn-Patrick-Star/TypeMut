
    package p2;

    class TimeBomb extends p1.Broken {
        void f () {
        }
    }