
    package p1;

    public abstract class Broken {
        abstract void f (); // default access
    }