(Compile this class with the "-Xlint" option and see that no warnings are raised.  Then run it and see a runtime exception due to an unchecked erroneous cast.  Uncomment the optional code to see another path to attempting the same cast which does raise a warning.)


// A generic class:
public class TypedCastBug<T> {
    
    // A parameterized subclass, typed with Object:
    static class Child extends TypedCastBug<Object> { }
    
    
    // ** This method performs an unchecked cast that javac
    //    erroneously does not issue a warning for:
    static <U> TypedCastBug<U> create() {
        Child child = new Child();
        child.set(new Object());
        return (TypedCastBug<U>) child;
    }
    
    
    // Run this to see a runtime exception caused through the cast in create():
    public static void main(String[] args) {
        TypedCastBug<Number> c = create();
        Number n = c.get();
    }
    
    
    // Instance data and methods:
    T t;
    void set(T t) { this.t = t; }
    T get() { return t; }
    
    
    // An example of a similar API that does cause javac to raise a warning:
//    static TypedCastBug<Object> willWarn = new TypedCastBug<Object>();
//    static <U> TypedCastBug<U> raisesTheWarning() {
//        return (TypedCastBug<U>) willWarn;  // Effectively the same as above
//    }
    
}