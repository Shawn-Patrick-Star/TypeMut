import java.util.Map;
import java.util.HashMap;

public class TestCase
{
    public static void main(String[] args)
    {
        Map myMap = new HashMap();
        myMap.put("key1","1");

        for (Map.Entry e : myMap.entrySet())
            System.out.println("Key = "+e.getKey() + " Value = "+e.getValue());
    }
}