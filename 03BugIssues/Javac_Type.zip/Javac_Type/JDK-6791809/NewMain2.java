public class NewMain2 {

    public static void main(String[] args) {
        int int_var = 5;
        float float_var = 7.8f;

        int_var+=float_var; //accepted but shouldn't

        int_var=(int) (int_var + float_var); //ok (should be ok and it is)
        int_var=int_var+float_var; //error (normal because types differ)
    }

}