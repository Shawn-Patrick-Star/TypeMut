    T2 extends Iface<T2> declared in class Acceptor
  where CAP#1 is a fresh type-variable:
    CAP#1 extends Iface<CAP#1> from capture of ?
1 error
originally reported in SO: stackoverflow.com/questions/23063474/why-does-this-java-8-program-not-compile
Dan Smith's analysis on this:

From overload resolution, we infer
{ t2 <: Object, Impl <: t2, t2 <: Iface<t2> }