>public class Outer<T> {
>  class Inner<U extends Number> {
>    U u;
>
>    void set(U u) {
>      this.u=u;
>    }
>  }
>
>  public static void main(String[] args) {
>    new Outer<Object>().new Inner().set("toto");
>  }
>}