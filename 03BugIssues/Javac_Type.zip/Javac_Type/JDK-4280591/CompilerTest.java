class CompilerTest {
    public static void main(String[] argv) {
        byte[] encoded = { '0', '1', '3', 'f', ')', 'O', '0', 'x' };
    }
}