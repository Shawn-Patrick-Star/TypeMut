//Fooable.java
public interface Fooable<T> {
    public boolean equals(T t);
}

//Foo.java
public class Foo<T extends Foo<T>> implements Fooable<T> {
    public boolean equals(T t) {
        return false;
    }
}

//Bar.java
public class Bar extends Foo<Bar> {
    public static void main(String[] args) {
        Bar a = new Bar();
        Bar b = new Bar();

        System.out.println(a.equals(b));
    }
}