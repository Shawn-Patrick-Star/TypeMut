import java.util.function.Function;

public class Test {
  public static void main(String[] args) {
    Test.test(2, Integer::new);
  }

  public static <In extends Number, Out extends Number> Out test(In in, Function<In, Out> f) {
    Out x = f.apply(in);
    return test(in, x);
  }

  public static <In extends Number, Out extends Number> Out test(In in, Out out) {
    return out;
  }
}