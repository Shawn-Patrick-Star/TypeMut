public class AccessBug {
   public static void main(String[] args) {
      new A3().test();
   }
}
   
class A1 {
   private int getI() {
      return 1;
   }
}
   
interface I1 {
    int getI();
}
   
abstract class A2 extends A1 implements I1 {
   public void test() {
      System.out.println(getI());
   }
}
   
class A3 extends A2 {
   public int getI() {
      return 2;
   }
}