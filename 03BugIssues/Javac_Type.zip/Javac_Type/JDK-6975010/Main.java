Contents of example/Main.java:

    package example;

    import example2.*;

    public class Main
    {
        public static void main(String[] arg)
        {
            Test t = new Test();
            System.out.println(t.getClass());
        }
    }

Contents of example/Test.java:

    package example;
    //public class Test {}

Contents of example2/Test.java:

    package example2;

    public class Test {}