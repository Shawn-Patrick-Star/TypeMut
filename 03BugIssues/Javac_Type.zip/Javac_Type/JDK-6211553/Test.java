class Test {
    public static void main(String[] args) {

        // Java bug!

        String a = null;

        Integer j = 8;
        Integer k = null;

        Integer i = (a != null)
                    ? 5  // okay with j, non-null, but fails on k below when this has Auto-boxing
                    : k;
    }
}