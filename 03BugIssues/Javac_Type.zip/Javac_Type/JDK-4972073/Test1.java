
//-- Code start here --
//Test1.java
import java.lang.reflect.*;

public class Test1 {
	public static void main(String[] args) {
		B b = new B<Sun1>();
	}
}