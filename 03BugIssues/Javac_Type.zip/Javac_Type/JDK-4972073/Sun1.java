
class Sun1 extends MyClass implements MyInterface<Sun1>, MyInterface<Sun1> {
	public String foo() {
		return "test";
	}
}