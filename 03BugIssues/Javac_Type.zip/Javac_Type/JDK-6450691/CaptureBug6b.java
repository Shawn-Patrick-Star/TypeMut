// this code compiles without warnings, has no casts,
// but throws a ClassCastException
public class CaptureBug6b {
	public static void main(String[] args) {
		P<? super B, ? extends A> p = new P<A,A>(new A());
		B b = p.get();
	}
}

class P<U, T extends U> {
	P(T v) {t = v;}
	T t;
	T get() {return t;}
}

class A {}
class B extends A {}