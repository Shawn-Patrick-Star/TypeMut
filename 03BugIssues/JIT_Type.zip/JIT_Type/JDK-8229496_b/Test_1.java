
public class Test {

    public static void vMeth() {
        int i11 = 1, i12, iArr1[] = new int[52];
        init(iArr1);
        for (i12 = 51; 1 < i12; i12 -= 3) {
            try {
                i11 = -3 % i12;
                iArr1[i12] = 0 / iArr1[i12];
            } catch (ArithmeticException a_e) {}
        }
        iArr1[i11] = 0;
    }

    public static void init(int[] iArr1) {
        for (int j = 0; j < iArr1.length; j++) {
            iArr1[j] =1;
        }
    }

    public static void main(String[] strArr) {
       for (int i = 0; i < 50000; i++) {
           vMeth();
       }
    }

}