
class Interval {
    int from, to;

    public Interval (int from, int to){
        this.from = from;
        this.to = to;
    }

    public int getLength() {
        return to - from;
    }

    public int getValue(int param) {
        return from + param;
    }

    public boolean contains(int param) {
        return param >= 0 && param < getLength();
    }

    public boolean containsValue(int value) {
        return value >= from && value < to;
    }
}