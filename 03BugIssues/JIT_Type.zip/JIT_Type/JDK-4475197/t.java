
class t {
    String getTypeName() {
        return "";
    }

    public void posGet_arr_int_int() {
        Iter iter = new Iter (new Interval[] {
            new Interval(0, 20),
            new Interval(0, 20),
            new Interval(0, 20),
            new Interval(0, 20),
            new Interval(0, 20),
            new Interval(0, 20)
        });

        int [] param = null;
        int len = 0;

        String meth = "" + getTypeName();

        while ((param = iter.getNext()) != null) {
            len = param[3] - param[2];
            for (int i = 0; i < len; i++) {
            }
        }
    }

    public static void main(String[] args) {
        t obj = new t();
        obj.posGet_arr_int_int();
    }
}