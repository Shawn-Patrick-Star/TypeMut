
class Iter {
    int [] oldVal;
    int [] curVal;
    int [] tmpVal;
    int [] result;

    Interval [] intervals; // array of the interval descriptors

    public int getParam(int pos) {
        return tmpVal[pos];
    }

    public Interval getInterval(int pos) {
        return intervals[pos];
    }

    public Iter(Interval [] intervals) {
        curVal = new int [intervals.length];
        tmpVal = new int [intervals.length];
        result = new int [intervals.length];
        oldVal = new int [intervals.length];
        this.intervals = intervals;

        for (int i = 0; i < curVal.length; i++) {
            curVal[i] = 0;
            tmpVal[i] = 0;
            oldVal[i] = 0;
        }
    }

    protected int [] getNextParameters() {
        if (curVal == null) {
            return null;
        }

        System.arraycopy(curVal, 0, tmpVal, 0, tmpVal.length);

        int i = curVal.length - 1;

        for (; i >= 0; i--) {
            curVal[i]++;
            if (intervals[i].contains(curVal[i])) {
                break;
            }
            curVal[i] = 0;
        }

        if (i < 0) {
            curVal = null;
        }

        for (i = 0; i < result.length; i++) {
            result[i] = intervals[i].getValue(tmpVal[i]);
        }
        return result;
    }

    public int [] getNext() {

        int [] res = null;
        boolean isNotValid = true;

        System.arraycopy(tmpVal, 0, oldVal, 0, tmpVal.length);

        res = getNextParameters();

        while (isNotValid && curVal != null) {
            isNotValid = false;
            for (int i = 0; i < curVal.length; i++) {
                if (!intervals[i].contains(tmpVal[i])) {
                    res = getNextParameters();
                    isNotValid = true;
                    break;
                }
            }
        }
        return res;
    }
}