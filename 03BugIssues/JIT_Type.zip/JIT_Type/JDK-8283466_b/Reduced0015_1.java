class Test {
  int a = 400;
  byte b[];
  void f(String[] c) {
    int i, d, e = 4, g, h[] = new int[a], j[] = new int[a];
    boolean k = false;
    for (d = 5; 8 > d;)
      try {
        i = 8 / j[1];
      } catch (ArithmeticException l) {
      }
    for (g = 1; g > d; g -= 3) {
      j[g] %= e;
      if (k)
        switch (d) {
        case 3:
          switch (0) {
          default:
            h[1] = 0;
          }
        case 5:
          b[1] = (byte)903453825;
        }
    }
  }
  public static void main(String[] m) {
    try {
      Test n = new Test();
      n.f(m);
    } catch (Exception ex) {
    }
  }
}
