public class Test {
    static int iFld = 2, x;
    static short limit = 10;

    public static void main(String[] args) throws Exception {
        for (int i = 0; i < 5000; i++) {
            try {
                test(i % 2 == 0, i % 3); 
            } catch (Exception e) {
            	// Expected
            }
        }
    }
    
    public static void test(boolean flag, int arg) throws Exception {
    	int sum = 1;
		int[] iArr2 = new int[4];
    	RuntimeException r = new RuntimeException("asdf");

    	for (int i = 0; i < limit; i+=2) {
			x = 5 / sum;
			if (Integer.compareUnsigned(i, iArr2.length) < 0) { // RC predicate with LoadI depedency
				iFld += iArr2[i]; // Range Check removed
				sum += iFld;
			} else {
				throw r; // UCT with -XX:+BailoutToInterpreterForThrows
			}
			if (i > 50) {
				break;
			}			
		}
    }
}
