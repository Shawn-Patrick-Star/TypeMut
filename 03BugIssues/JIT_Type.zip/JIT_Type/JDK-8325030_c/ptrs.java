# Java VM: OpenJDK 64-Bit Server VM (fastdebug 17.0.11-internal+0-adhoc.user.jdk17u-dev, mixed mode, tiered, compressed oops, compressed class ptrs, g1 gc, linux-amd64)

A DESCRIPTION OF THE PROBLEM :
I ran a test case on jdk17u-dev(17.0.11), and jvm crashed. When I enable -Xint or -Xcomp option, it works correctly.


STEPS TO FOLLOW TO REPRODUCE THE PROBLEM :
java Test

ACTUAL -
$ java Test
 1  Con  ===  0  [[]]  #top
# To suppress the following error report, specify this argument
# after -XX: or in .hotspotrc:  SuppressErrorAt=/macro.cpp:427
#
# A fatal error has been detected by the Java Runtime Environment:
#
#  Internal Error (/data/xiezifan/jdk17u-dev/src/hotspot/share/opto/macro.cpp:427), pid=998566, tid=998588
#  assert(false) failed: unknown node on this path
#
# JRE version: OpenJDK Runtime Environment (17.0.11) (fastdebug build 17.0.11-internal+0-adhoc.xiezifan.jdk17u-dev)
# Java VM: OpenJDK 64-Bit Server VM (fastdebug 17.0.11-internal+0-adhoc.xiezifan.jdk17u-dev, mixed mode, tiered, compressed oops, compressed class ptrs, g1 gc, linux-amd64)
# Problematic frame:
# V  [libjvm.so+0x13b5ed6]  PhaseMacroExpand::value_from_mem_phi(Node*, BasicType, Type const*, TypeOopPtr const*, AllocateNode*, Node_Stack*, int)+0xe46
#
# Core dump will be written. Default location: Core dumps may be processed with "/usr/share/apport/apport -p%p -s%s -c%c -d%d -P%P -u%u -g%g -- %E" (or dumping to /data/xiezifan/JVM-Tesing-by-Anti-Optimization/toreport/Test8918_01_20_17_50_43/reduce/core.998566)
#
# An error report file with more information is saved as:
# /data/xiezifan/JVM-Tesing-by-Anti-Optimization/toreport/Test8918_01_20_17_50_43/reduce/hs_err_pid998566.log
#
# Compiler replay data is saved as:
# /data/xiezifan/JVM-Tesing-by-Anti-Optimization/toreport/Test8918_01_20_17_50_43/reduce/replay_pid998566.log
#
# If you would like to submit a bug report, please visit:
#   https://bugreport.java.com/bugreport/crash.jsp
#
Aborted (core dumped)

---------- BEGIN SOURCE ----------
class Test {
    int var15;

    void mainTest() {
        int i2 = 38;
        for (int i = 0; i < 100; ++i)
            try {
                int var5 = Integer.valueOf(i2);
                synchronized (new Test()) {
                    int var18 = var5 - 71;
                    synchronized (Test.class) {
                        for (int var19 = 0; var19 < var18;) {
                            int var21 = Integer.valueOf(var19);
                        }
                    }
                }
                for (int var8 = 0; var8 < 20000; ++var8) ;
            } catch (ArithmeticException a_e) {
            }
    }

    public static void main(String[] strArr) {
        Test _instance = new Test();
        _instance.mainTest();
    }
}