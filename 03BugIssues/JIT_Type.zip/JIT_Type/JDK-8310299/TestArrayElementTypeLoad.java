
public class TestArrayElementTypeLoad {
    public static void main(String[] args) {
        TestFramework.run();
    }

    static final A[] array = new A[1];

    @Test
    @IR(phase = { CompilePhase.ITER_GVN1 }, failOn = { IRNode.SUBTYPE_CHECK })
    public static void test1(A a) {
        array[0] = a;
    }

    @Run(test = "test1")
    private void test1Runner() {
        test1(new A());
        test1(new B());
    }

    static class A {
    }

    static class B extends A {
    }
}