package test;

import java.util.ArrayList;
import java.util.List;


public class Hs {
  void foo(A a, A[] as) {
    for (A a1 : as) {
      B[] filtered = a.c(a1);
      for (B b : filtered)
        if (b == null) {
          System.out.println("bug");
        }
    }
  }
  
  public static void main(String[] args) {
    List<A> as = new ArrayList<A>();
    for (int i = 0; i < 5000; i++) {
      List<B> bs = new ArrayList<B>();
      for (int j = i; j < i + 1000; j++)
        bs.add(new B(j));
      as.add(new A(bs.toArray(new B[0])));
    }
    new Hs().foo(as.get(0), as.subList(1, as.size()).toArray(new A[0]));
  }
}