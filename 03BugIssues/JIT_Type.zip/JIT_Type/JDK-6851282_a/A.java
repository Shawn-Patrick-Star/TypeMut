
class A {
  final B[] bs;
  
  public A(B[] bs) {
    this.bs = bs;
  }
  
  final B[] c(final A a) {
    return new BoxedArray<B>(bs).filter(new Function<B, Boolean>() {
      public Boolean apply(B arg) {
        for (B b : a.bs) {
          if (b.d == arg.d)
            return true;
        }
        return false;
      }
    });
  }
}