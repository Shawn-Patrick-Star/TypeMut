class Test2 {
    static int N = 2000;
    static void test(float[] f, short[] s) {
        for (int i = 0; i < s.length/2; i++) {
            s[i*2] = Float.floatToFloat16(f[i*2]);
        }
    }

    public static void main(String[] strArr) {
      short[] s = new short[N];
      float[] f = new float[N];
      for (int i = 0; i < 10_000; i++) {
          test(f, s);
      }
    }
}
