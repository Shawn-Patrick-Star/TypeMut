
// java -XX:MaxVectorSize=16 -Xbatch Test
public class Test {

    public static long[] arr = new long[400];

    public static void bar() {
        for (int i = 304; i > 15; i -= 3) {
            int c = 16;
            do {
                for (int t = 1; t < 1; t++) {}
                arr[c + 1] >>= i;
            } while (--c > 0);
        }
    }

    public static void main(String[] args) {
        int iter = 100000;
        while (iter-- > 0) {
            bar();
        }
    }
}