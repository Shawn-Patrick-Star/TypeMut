public class InconsistentValue2 {
    public static int CHECKSUM = 0;

    public InconsistentValue2() {
    }

    public static void main(String[] var0) {
        byte var3 = 0;
        InconsistentValue2 var1 = new InconsistentValue2();
        var1.test(var3);
        System.out.println(Integer.toString(CHECKSUM));
    }

    int test(int var1) {
        for(int var6 = 0; var6 < 100; ++var6) {
            for(int var7 = var6; var7 < 100; ++var7) {
                byte var8 = 0;
                long var9 = 0L;

                while(true) {
                    long var11;
                    int var10000 = (var11 = var9 - 100L) == 0L ? 0 : (var11 < 0L ? -1 : 1);
                    CHECKSUM = Check.checksum(CHECKSUM, var9);
                    if (var10000 >= 0) {
                        var1 += var8;
                        break;
                    }
                    ++var9;
                }
            }
        }
        return var1;
    }
}