class Test {
    static int N = 1000;
    static void test(float[] f, short[] s) {
        for (int i = 0; i < s.length; i++) {
            s[i] = Float.floatToFloat16(f[i]);
            //f[i] = Float.float16ToFloat(s[i]);
        }
    }

    public static void main(String[] strArr) {
      short[] s = new short[N];
      float[] f = new float[N];
      for (int i = 0; i < 10_000; i++) {
          test(f, s);
      }
    }
}
