public final class BugTest {

  public static void main(String[] args) {
    BugTest b = new BugTest();
    while (true) {
      b.crashTimeParty();
    }
  }

  private void crashTimeParty() {
    int i = 0;
    int j = 0;

    if (someThing == 1)
      do {
        if (++i == 10)
          return;
      } while (true);
    else
      // This section isn't actually entered
      do {
        int x = 0;

        // Remove any of these = good.
        o[0] = myJ[x];
        o[0] = myJ[x];
        o[0] = myJ[x];
        o[0] = myJ[x];
        o[0] = myJ[x];
        o[0] = myJ[x];
        o[0] = myJ[x];
        o[0] = myJ[x];
        o[0] = myJ[x];
        
        if (++i == 6) // <=5 good. >=6 bad.
          return;
        
        // Remove this = good.
        o[0] = myJ[x];
      } while (true);
  }

  private int someThing = 1;

  private int o[] = null; // never really referenced.

  static final int[] myJ = new int[256];

  static final int a[] = null; // never really referenced.

}