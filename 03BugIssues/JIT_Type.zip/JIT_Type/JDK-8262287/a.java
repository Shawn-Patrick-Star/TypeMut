primitive class a {
  short b = 2;
  int c = 8;
}