public class MathBugTest {
  public static void main(String[] args) {
    // Note: it's really only necessary to run this loop 8 times to
    // reproduce the bug, but the 2000-length loop causes compilation
    // of Math.round() without any other command-line flags.
    // A bug in the d2l NaN case was causing overflow of the FPU
    // stack, yielding subsequent wrong results for flds.
    for (int i=0; i<2000; i++) {
        Math.round(Double.NaN);
    }
    if (Math.round(1d) != 1) {
        throw new RuntimeException("TEST FAILED");
    }
    System.out.println("Test passed.");
  }
}