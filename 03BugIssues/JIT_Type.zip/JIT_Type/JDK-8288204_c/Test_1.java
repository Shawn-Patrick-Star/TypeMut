class Test {
  int N;
  double[] dArrFld;
  int[] iArrFld;

  int iMeth() {
    double dArr[] = new double[N];
    long meth_res = Double.doubleToLongBits(checkSum(dArr));
    return (int) meth_res;
  }

  void mainTest(String[] strArr1) {
    int i = 47864, i27 = 0, i32, i37 = 39;
    short s4 = 21959;
    float f4;
    i ^= iMeth();
    for (; ; ) {
      for (i32 = 1; i32 < 46; i32++) i27 += s4;
      do
        for (f4 = 1; f4 < 1; ++f4) {
          dArrFld[(int) f4] = 53586;
          iArrFld[i37] *= 92.656F;
          dArrFld = double1array(N, 2.89809);
        }
      while (++i37 < 46);
      for (int ax$5 = 4; ax$5 < 6167; )
        try {
          long[] ax$3 = {1};
          for (int ax$2 = 0; ax$2 < 100000; ) {
            for (long duration : ax$3) {}
            String ax$0 = "test";
            ax$0 = ax$0 + ax$0;
            ax$0 = ax$0 + ax$0;
          }
        } catch (Throwable ax$4) {
        } finally {
        }
    }
  }

  public static void main(String[] strArr) {
    Test _instance = new Test();
    _instance.mainTest(strArr);
  }


  public static double checkSum(double[] a) {
    double sum = 0;
    for (int j = 0; j < a.length; j++) {
      sum += (a[j] / (j + 1) + a[j] % (j + 1));
    }
    return sum;
  }


  public static double[] double1array(int sz, double seed) {
    double[] ret = new double[sz];
    init(ret, seed);
    return ret;
  }


  public static void init(double[] a, double seed) {
    for (int j = 0; j < a.length; j++) {
      a[j] = (j % 2 == 0) ? seed + j : seed - j;
    }
  }
}