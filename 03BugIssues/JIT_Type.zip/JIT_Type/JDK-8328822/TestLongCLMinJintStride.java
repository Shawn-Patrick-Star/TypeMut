import java.util.Objects;

public class TestLongCLMinJintStride {
    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            test1(((long)Integer.MAX_VALUE) * 100, Long.MAX_VALUE);
            test2(Integer.MAX_VALUE, Long.MAX_VALUE, 0);
            testHelper(100, -1, Long.MAX_VALUE, 0);
        }
    }

    private static void test1(long stop, long range) {
        for (long i = stop; i >= 0; i += Integer.MIN_VALUE) {
            Objects.checkIndex(i, range);
        }
    }

    private static void test2(int stop, long range, int start) {
        testHelper(stop, Integer.MIN_VALUE, range, start);
    }

    private static void testHelper(int stop, int stride, long range, int start) {
        for (int i = stop; i >= start; i += stride) {
            Objects.checkIndex(i, range);
        }
    }
}
