# Java VM: Java HotSpot(TM) 64-Bit Server VM (19-ea+23-1706, mixed mode, emulated-client, sharing, tiered, compressed oops, compressed class ptrs, g1 gc, linux-amd64)
# Problematic frame:
# V  [libjvm.so+0x28dc40]  AccessInternal::PostRuntimeDispatch<G1BarrierSet::AccessBarrier<548964ul, G1BarrierSet>, (AccessInternal::BarrierType)2, 548964ul>::oop_access_barrier(void*)+0x0

and to an assertion failure in debug builds (log and replay files *_pid21435.log attached):

# To suppress the following error report, specify this argument
# after -XX: or in .hotspotrc:  SuppressErrorAt=/ciObject.hpp:144
#
# A fatal error has been detected by the Java Runtime Environment:
#
#  Internal Error[thread 21183 also had an error] (open/src/hotspot/share/ci/ciObject.hpp:144)
, pid=21182, tid=21195
#  assert(is_method_handle()) failed: bad cast
#
# JRE version: Java(TM) SE Runtime Environment (19.0+23) (fastdebug build 19-ea+23-1706)
# Java VM: Java HotSpot(TM) 64-Bit Server VM (fastdebug 19-ea+23-1706, mixed mode, emulated-client, sharing, tiered, compressed oops, compressed class ptrs, g1 gc, linux-amd64)
# Problematic frame:
# V  [libjvm.so+0x7b7214]  GraphBuilder::try_method_handle_inline(ciMethod*, bool)+0x454


ORIGINAL REPORT:

ADDITIONAL SYSTEM INFORMATION :
Arch: x86_64
OS: Ubuntu 20.04.4 LTS
HotSpot
- openjdk version "11.0.15" 2022-04-19
- OpenJDK Runtime Environment (build 11.0.15+10-Ubuntu-0ubuntu0.20.04.1)
- OpenJDK 64-Bit Server VM (build 11.0.15+10-Ubuntu-0ubuntu0.20.04.1, mixed mode, sharing)
javac: javac 11.0.15

A DESCRIPTION OF THE PROBLEM :
The problem was firstly found in the repo https://github.com/openjdk/jdk11u-dev (commit 9cb3797f). Unfortunately, it can still be reproduced on openjdk 11.0.15 with the following log:
#
# A fatal error has been detected by the Java Runtime Environment:
#
#  SIGSEGV (0xb) at pc=0x00007f1e92c6d944, pid=3242972, tid=3242987
#
# JRE version: OpenJDK Runtime Environment (11.0.15+10) (build 11.0.15+10-Ubuntu-0ubuntu0.20.04.1)
# Java VM: OpenJDK 64-Bit Server VM (11.0.15+10-Ubuntu-0ubuntu0.20.04.1, mixed mode, sharing, tiered, compressed oops, g1 gc, linux-amd64)
# Problematic frame:
# V  [libjvm.so+0x573944]
#
# No core dump will be written. Core dumps have been disabled. To enable core dumping, try "ulimit -c unlimited" before starting Java again
#
# An error report file with more information is saved as:
# /tmp/hs_err_pid3242972.log
#
# Compiler replay data is saved as:
# /tmp/replay_pid3242972.log
#
# If you would like to submit a bug report, please visit:
#   Unknown
#
Aborted

STEPS TO FOLLOW TO REPRODUCE THE PROBLEM :
1. type: javac Test.java
2. type: java -Xbatch Test

EXPECTED VERSUS ACTUAL BEHAVIOR :
EXPECTED -
HotSpot does NOT crash
ACTUAL -
HotSpot DID crash

---------- BEGIN SOURCE ----------
class Test {
  boolean bFld;

  void mainTest(String[] strArr1) {
    double d = 2.61331;
    int i, i30, i32;
    for (i30 = 830; i30 > 51; --i30) bFld = bFld;
    i32 = 1;
    while (++i32 < 908)
      for (int ax$2 = -3230; ax$2 < 9840; ax$2 += 2)
        try {
          java.lang.invoke.MethodHandle ax$0 = null;
          ax$0.invokeExact();
        } catch (Throwable ax$1) {
        } finally {
        }
    System.out.println("d i i30 = " + d);
  }

  public static void main(String[] strArr) {
    Test _instance = new Test();
    for (; ; ) _instance.mainTest(strArr);
  }
}