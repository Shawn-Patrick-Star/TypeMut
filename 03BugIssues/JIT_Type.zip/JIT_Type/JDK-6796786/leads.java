Looks like static field access of uninitialized class leads to wrong 1/-0 result in case server compiler is used.

The following test case demonstrates this:

======== TesterSmall_10.java ========
final class TesterSmall_10_Class_0 {
    static float var_1 = 1;
    float var_2 = 1;
}