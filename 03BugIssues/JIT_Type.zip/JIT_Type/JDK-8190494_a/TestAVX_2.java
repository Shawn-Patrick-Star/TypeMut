class TestAVX { 
    public static class SystemInfo{ 
        static { 
            System.loadLibrary("SystemInfo"); 
        } 
        public static native int getNumberOfHardwareThreads(); 
    } 

    static float f() {
        int value1 = SystemInfo.getNumberOfHardwareThreads(); 
        float value2 = (float)value1;
        return value2;
    }
    public static void main(String[] argv) throws Exception { 
        System.out.printf("%f\n", f()); 
    } 
}