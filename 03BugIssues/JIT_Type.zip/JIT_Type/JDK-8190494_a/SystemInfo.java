        public static class SystemInfo{
                static {
                        System.loadLibrary("SystemInfo");
                }
                public native int getNumberOfHardwareThreads();
        }