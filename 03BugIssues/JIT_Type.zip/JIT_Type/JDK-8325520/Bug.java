import jdk.incubator.vector.LongVector;

class Bug {
  public static void main(String[] args) {
    final long[] storage = new long[8];
    final int[] offsets = new int[]{4, 5, 6, 7};

    final LongVector ones = LongVector.broadcast(LongVector.SPECIES_256, 1);

    for (int i = 0 ; i < (1 << 30); i++) {
      ones.intoArray(storage, 0);
      LongVector a = LongVector.fromArray(LongVector.SPECIES_256, storage, 0, offsets, 0);
      LongVector b = LongVector.fromArray(LongVector.SPECIES_256, storage, 0, offsets, 0);

      if (ones.equals(a) || ones.equals(b)) {
        System.out.println(i);
        System.out.println(ones);
        System.out.println(a);
        System.out.println(b);
      }
    }
  }
}