public class MaxIntegerLoopingBug
{
    public static void main(String[] args)
    {
        // This works
        loopAndPrint(Integer.MAX_VALUE -1);
        // This doesn't
        loopAndPrint(Integer.MAX_VALUE);
    }

    public static void loopAndPrint(int max)
    {
        int a = -1;
        int i = 1;
        for (; i < max; i++)
        {
            a = i;
        }
        System.out.println("Expected: " + (max - 1));
        System.out.println("Actual  : " + a);
    }
}