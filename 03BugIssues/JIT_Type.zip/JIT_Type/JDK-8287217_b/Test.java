class Test {
  int N;
  long instanceCount;

  int iMeth(int i, long l, short s1) {
    float fArr[] = new float[N];
    Byte ax$1 = 0xFFFFFFFF;
    Byte ax$0 = 1;
    for (int ax$2 = 0; ax$2 < 10000; ax$2++)
      if ((ax$2 & 1) == 0) ax$0 = (byte) ax$0;
      else ax$1 = (byte) ax$1;
    long meth_res = Double.doubleToLongBits(checkSum(fArr));
    return (int) meth_res;
  }

  void mainTest(String[] strArr1) {
    short s = 21753;
    int i21 = 97;
    s = (short) iMeth(i21, instanceCount, s);
  }

  public static void main(String[] strArr) {
    Test _instance = new Test();
    for (; ; ) _instance.mainTest(strArr);
  }

  public static double checkSum(float[] a) {
    double sum = 0;
    for (int j = 0; j < a.length; j++) {
      sum += (a[j] / (j + 1) + a[j] % (j + 1));
    }
    return sum;
  }
}