
interface MyInterface {
     static void m() {}
}