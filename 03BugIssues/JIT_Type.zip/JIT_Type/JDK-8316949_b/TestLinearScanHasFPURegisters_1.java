package compiler.c1;

public class TestLinearScanHasFPURegisters {
    void test(String[] args) {
        String[] arr = new String[4];
        float f = -1;
        try {
            arr[0] = "-1"; // exception edge 1 with value -1
            if (args.length > 1) {
                f = 42;
                arr[1] = "42"; // exception edge 2 with value 42
            }
        } catch (Exception e) {
            // exception handler block with incoming phi for "f"
            for (int i = 0; i < 1; ++i) {
                f = f; // generates bytecodes, but no JIT IR
            }
        }
    }
    public static void main(String[] args) {
        TestLinearScanHasFPURegisters t = new TestLinearScanHasFPURegisters();
        for (int i = 0; i < 1000; ++i) {
            t.test(args);
        }
    }
}