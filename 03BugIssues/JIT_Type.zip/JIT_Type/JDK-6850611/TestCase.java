package test;

public class TestCase {

	public static void main(String[] args) {
		test();
	}

	private static void test() {
		for (int j = 0; j < 10; ++j) {
			long x = 0;
			for (int i = Integer.MIN_VALUE; i < Integer.MAX_VALUE; ++i) {
				x += i;
			}
			System.out.println("sum: " + x);
		}
	}
}