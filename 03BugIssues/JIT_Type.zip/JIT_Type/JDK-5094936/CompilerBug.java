
import be.arci.math.BigDecimal;
import be.arci.math.MathContext;

public class CompilerBug
{
     public static void main(String[] argv)
     {
     junk();
     }

    public static void junk()
    {
        BigDecimal one = BigDecimal.ONE;
        BigDecimal nine = new BigDecimal(9);
        MathContext context = new MathContext(16, MathContext.SCIENTIFIC);
        for (int i = 0; i < 10000000; ++i)
            System.out.println(one.divide(nine, context));
    }
}