public class Reduced {

    static long test() {
        int x = 6, y = 5;
        int[] iArr = new int[200];
        for (int i = 129; i > 5; i -= 2) { // OSR compiled
            try {
                y = iArr[i - 1];
                x = iArr[i + 1];
                x = 1 / i;
            } catch (ArithmeticException a_e) {
            }
        }
        Foo.empty();
        return x + y;
    }

    public static void main(String[] strArr) {
        new Reduced();
        for (int i = 0; i < 2000; i++) {
            test();
        }
    }
}

class Foo {
    public static void empty() {}
}
