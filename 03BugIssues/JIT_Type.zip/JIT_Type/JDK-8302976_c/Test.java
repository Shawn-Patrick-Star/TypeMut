public class Test {
    public static short test(float f) {
        return Float.floatToFloat16(f);
    }

    public static void main(String[] args) {
        float val = Float.float16ToFloat((short) 31745);
        for (int i = 0; i < 50_000; ++i) {
            if (test(val) != 31745) {
                throw new RuntimeException("Wrong result");
            }
        }
    }
}
