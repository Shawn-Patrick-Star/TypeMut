public class Test {

    public static final int N = 400;

    public static void vMeth() {
        int iArr[]=new int[N];

        int x = iArr[0];
        for (int i4 = 0; i4 < N; i4++) {
            x += Integer.reverseBytes(-(++iArr[i4]));
        }
    }

    public static void main(String[] strArr) {
        for (int i = 0; i < 10; i++) {
            vMeth();
        }
    }
}
