/*
 * Copyright (c) 2023, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

// Run with -XX:CompileCommand=compileonly,TestAll::test* -Xbatch
public class TestAllFix {
    public static short testFloatToFloat16(float f) {
        return Float.floatToFloat16(f);
    }

    public static float testFloat16ToFloat(short s) {
        return Float.float16ToFloat(s);
    }

    public static void run() {
        for (short sVal = Short.MIN_VALUE; sVal < Short.MAX_VALUE; ++sVal) {
            float fVal = Float.float16ToFloat(sVal);
            short sRes = testFloatToFloat16(fVal);
            if (sRes != sVal) {
                if (!Float.isNaN(fVal) ||
                    ((sRes & ~0x0200) != (sVal & ~0x0200)) ) {
                  System.out.println("1Inconsistent result for Float.floatToFloat16(" + sVal + "): " + sRes + " != " + sVal);
                }
            }
            float fRes = testFloat16ToFloat(sVal);
            if (!Float.isNaN(fRes) && fRes != fVal) {
                System.out.println("2Inconsistent result for Float.float16ToFloat(" + sVal + "): " + fRes + " != " + fVal);
            }
            short sfRes = Float.floatToFloat16(fRes);
            short sfVal = Float.floatToFloat16(fVal);
            if (sfRes != sfVal) {
                if (!Float.isNaN(fVal) ||
                    ((sfRes & ~0x0200) != (sfVal & ~0x0200)) ) {
                  System.out.println("3Inconsistent result for Float.float16ToFloat(" + sVal + "): " + Float.floatToFloat16(fRes) + " != " + Float.floatToFloat16(fVal));
                }
            }
        }
    }
    
    public static void main(String[] args) {
        // Run twice to trigger compilation
        for (int i = 0; i < 2; i++) {
            run();
        }
    }
}

