inline class MyValue1 {
    int[] array = new int[1];
}