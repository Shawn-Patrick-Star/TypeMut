public class Reproducer {

    public static void main(String[] args) {
        var end = new Fill() {
            @Override
            public void fill(double[] array) {

            }
        };
        Square square = new Square(new Id(new Square(end)));
        for (int i = 0; i < 1000; i++) {
            square.fill(new double[1000]);
        }
    }

    public interface Fill {

        default Fill inner() {
            return null;
        }

        default void fill(double[] array) {
            this.inner().fill(array);
            for (int i = 0; i < array.length; ++i) {
                array[i] = this.mapSingle(array[i]);
            }
        }

        default double mapSingle(double value) {
            throw new AssertionError();
        }
    }

    record Square(Fill inner) implements Fill {

        @Override
        public double mapSingle(double value) {
            return value * value;
        }
    }

    record Id(Fill inner) implements Fill {

        @Override
        public double mapSingle(double value) {
            return value;
        }
    }
}
