/*
 * Copyright (c) 2023, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

// Run with -XX:CompileCommand=compileonly,TestAll::test* -Xbatch
public class TestAllFloat {
    public static int testDoubleToFloatBits(double d) {
        return Float.floatToRawIntBits((float) d);
    }

    public static double testFloatBitsToDouble(int fbits) {
        return (double) Float.intBitsToFloat(fbits);
    }

    public static void run() {
        for (int iVal = Integer.MIN_VALUE; iVal < Integer.MAX_VALUE; ++iVal) {
            double dVal = (double) Float.intBitsToFloat(iVal);
            int iRes = testDoubleToFloatBits(dVal);
            if (iRes != iVal) {
                System.out.println("Inconsistent result for DoubleToFloat(" + iVal + "): " + iRes + " != " + iVal);
            }
            double dRes = testFloatBitsToDouble(iVal);
            if (!Double.isNaN(dRes) && dRes != dVal) {
                System.out.println("Inconsistent result for FloatToDouble(" + iVal + "): " + dRes + " != " + dVal);
            }
            int idRes = Float.floatToRawIntBits((float) dRes);
            int idVal = Float.floatToRawIntBits((float) dVal);
            if (idRes != idVal) {
                System.out.println("Inconsistent result for DoubleToFloat(" + iVal + "): " + idRes + " != " + idVal);
            }
        }
    }
    
    public static void main(String[] args) {
        // Run twice to trigger compilation
        for (int i = 0; i < 2; i++) {
            run();
        }
    }
}

