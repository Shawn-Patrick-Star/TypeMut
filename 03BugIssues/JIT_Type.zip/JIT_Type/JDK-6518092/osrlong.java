
public class osrlong {
    public static void main(String[] args) {
        while (true) {
            try {
                loop(30000);
            } catch (InternalError e) {
            }
        }
    }

    static volatile int one = 1;

    static int read(int n) throws InternalError {
        if (n == one) throw new InternalError();
        return one;
    }

    static long loop(int n) {
        long bytes = 0;
        while (n > 0) {
            int b = read(n);
            bytes += b;
            n -= b;
        }
        return bytes;
    }
}