
class T {
  public static void main(String[] args) {
    long c = 0;
    int expected = -2147483648;
    while (true) {
      long r = Integer.reverse(1);
      if (r != expected) {
        throw new AssertionError(
            String.format(
                "expected Integer.reverse(1) to be %d, but was %d after %d iterations",
                expected, r, c));
      }
      c++;
    }
  }
}