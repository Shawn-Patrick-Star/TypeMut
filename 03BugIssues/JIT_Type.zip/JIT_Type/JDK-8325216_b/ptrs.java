# Java VM: OpenJDK 64-Bit Server VM (19.0.2+7-44, mixed mode, sharing, tiered, compressed oops, compressed class ptrs, g1 gc, linux-amd64)
# Problematic frame:
# J 1130 c2 C.read([CI)V (28 bytes) @ 0x00007faca0b17c46 [0x00007faca0b17c20+0x0000000000000026]
#
# Core dump will be written. Default location: Core dumps may be processed with "/usr/share/apport/apport -p%p -s%s -c%c -d%d -P%P -u%u -g%g -- %E" (or dumping to /home/disk2/fuyao/projects/investigation/core.29031)
#
# An error report file with more information is saved as:
# /home/disk2/fuyao/projects/investigation/hs_err_pid29031.log
#
# If you would like to submit a bug report, please visit:
#   https://bugreport.java.com/bugreport/crash.jsp
#
Aborted (core dumped)

---------- BEGIN SOURCE ----------
public class C {
    static class SM {
        void sMatch(char[] buffer, int pos) {
            boolean x = ' ' == buffer[pos];
        }
    }

    static SM sm = new SM();

    static void m() {
        char[] buffer = { '.' };
        read(buffer, 0);
        read(buffer, -1);
    }

    static void read(char[] buffer, int pos) {
        for (int j = 0; j < 10; ++j) {
            match(buffer, pos);
            sm.sMatch(buffer, pos);
        }
    }

    static void match(char[] buffer, int pos) {
        char x = buffer[pos];
    }

    public static void main(String[] args) {
        for (int i = 0; i < 100_000; ++i) {
            try {
                m();
            } catch (IndexOutOfBoundsException e) {
            }
        }
    }
}