public class Puzzles {
	public static void main(String[] args) throws InterruptedException {
		int END = Integer.MAX_VALUE;
		int count = 0;
		for(int i = Integer.MAX_VALUE - 5; i <= END; i++) {
			System.out.println(END + " -> " + i + " = " + (i <= END));
			count++;
		}
		System.out.println("broken " + count);
	}
}