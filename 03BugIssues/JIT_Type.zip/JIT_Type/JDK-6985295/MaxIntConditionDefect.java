public class MaxIntConditionDefect {

    public static void main(String[] args) {
        int min = 1;
        int max = Integer.MAX_VALUE;
        System.out.println("max = " + max);
        long counter = 0;
        int i;
        for(i = min; i <= max; i++) {
            counter++;
            System.out.println("asking for");
        }
        System.out.println("iteration went " + counter + " times (" + i + ")");
        System.out.println("max = " + max);
    }

}