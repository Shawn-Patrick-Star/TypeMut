
class foo extends base implements I {
   public static void main(String[] args) {
      new derived1();   //Force load, so deoptimization does not occur
      //new derived2(); //Do not load, or bug goes away
      if (new foo().test(2) == null) {
         System.out.println("FAILED");
      }
      else {
         System.out.println("PASSED");
      }
   }
   public void f(){}
   I test(int i) {
      if (i == 1)
         return null;
      I result;
      if (i == 2)
         result = new derived1();
      else
         result = new derived2();
      if (result != null)
         return result;
      else
         return this;
   }
}