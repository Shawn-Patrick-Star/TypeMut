
class derived1 extends base implements I {
  public void f(){}
}