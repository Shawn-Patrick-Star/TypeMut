
class derived2 extends base implements I {
  public void f(){}
}