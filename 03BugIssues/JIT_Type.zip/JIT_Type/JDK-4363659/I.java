*/
interface I {
   void f();
}