
inline class Test0 {
    int x = 42;
    short[] array = new short[7];
}