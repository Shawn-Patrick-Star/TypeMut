import java.util.ArrayList;
import java.util.List;

class Test {
  int N;

  void vMeth(int i, int i1) {
    try {
      int ax$22 = 0x80018001;
      List ax$21 = new ArrayList();
      ax$21.set(ax$22, Boolean.TRUE);
    } catch (Throwable ax$25) {
    } finally {
    }
  }

  int iMeth(float f1) {
    int iArr2[] = new int[N];
    for (int ax$26 = 0; ax$26 < 8154; ) vMeth(177294371, 475509554);
    long meth_res = FuzzerUtils.checkSum(iArr2);
    return (int) meth_res;
  }

  void mainTest(String[] strArr1) {
    float f = 2.828F;
    f = iMeth(f);
  }

  public static void main(String[] strArr) {
    Test _instance = new Test();
    _instance.mainTest(strArr);
  }
}