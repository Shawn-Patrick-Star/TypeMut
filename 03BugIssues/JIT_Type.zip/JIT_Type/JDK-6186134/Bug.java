public class Bug {

  int num = 0;

  public Bug(int n) {
    num = n;
  }

  public boolean more() {
    return num-- > 0;
  }

  public ArrayList test1() {
    ArrayList res = new ArrayList();
    int maxResults = Integer.MAX_VALUE;
    int n = 0;
    boolean more = more();
    while ((n++ < maxResults) && more) {
      res.add(new Object());
      more = more();
    }
    return res;
  }

  public static void main(String[] pars) {
    System.out.print("Res: ");
    int n = Integer.parseInt(pars[0]);
    for (int i=0; i<n; i++) {
      Bug b = new Bug(10);
      System.out.print(b.test1().size()+",");
    }
    System.out.println();
  }
}