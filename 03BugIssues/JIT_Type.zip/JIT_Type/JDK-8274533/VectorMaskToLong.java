public class VectorMaskToLong {
    static final VectorSpecies<Integer> SPECIES = IntVector.SPECIES_128;
    static long maskFromToLongInt128VectorTest(long inputLong) {
        var vmask = VectorMask.fromLong(SPECIES, inputLong);
        return vmask.toLong();
    }

    static long expected(long inputLong) {
        return inputLong & (((1L << (SPECIES.length() - 1)) << 1) - 1);
    }

    public static void main(String[] args) {
        for (int i = 0; i < 100000; i++) {
            long res = maskFromToLongInt128VectorTest(-1);
            long exp = expected(-1);
            if (res != exp) {
                System.err.println("Failure: res = " + res + " exp = " + exp);
                System.exit(-1);
            }
        }
    }
}