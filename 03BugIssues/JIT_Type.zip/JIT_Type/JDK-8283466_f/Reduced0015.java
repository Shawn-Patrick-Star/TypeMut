class Test {
  int a = 400;
  byte b[];
  void mainTest() {
    int i, d, e = 4, g, h[] = new int[a], j[] = new int[a];
    boolean k = false;
    for (d = 5; 8 > d;)
      try {
        i = 8 / j[1];
      } catch (ArithmeticException l) {
      }
    for (g = 1; g > d; g -= 3) {
      j[g - 1] %= e;
      if (k)
        switch (d) {
        case 3:
          h[1] = 0;
        case 6:
          b[1] = 3;
        }
    }
  }
  public static void main(String[] m) {
    Test _instance = new Test();
    _instance.mainTest();
  }
}
