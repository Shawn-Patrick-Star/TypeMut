public class FailedToCatch {

    public static void main(String[] var0) {
        Object[] arr = new Object[10];
        int catchTime = 0;
        for(int i = 0; i < 20000; i++) {
            try {
                m(arr, 15, 20);
            } catch (ArrayIndexOutOfBoundsException var4) {
                catchTime++;
                for(int loopIndex = 1; loopIndex < 100; loopIndex++) {
                }
            }
        }
        System.out.println("Catch Time: " + catchTime);
    }
    static Object[] m(Object[] var0, int var1, int var2) {
        return Arrays.copyOfRange(var0, var1, var2, Object[].class);
    }
}