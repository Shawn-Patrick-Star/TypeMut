

primitive class MyValue {
    int b = 2;
}