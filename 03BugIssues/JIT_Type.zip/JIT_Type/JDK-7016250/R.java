
import java.dyn.*;

public class R { 
    public static void main(String... args) throws Throwable {
        MethodHandle mh1 = MethodHandles.identity(int.class);
        MethodHandle mh2 = MethodHandles.convertArguments(mh1, MethodType.methodType(short.class, int.class));
        short s = (short) mh2.invokeExact(123);
    }
}