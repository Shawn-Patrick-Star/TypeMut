class Test {
  int N = 256;
  long instanceCount;
  int iFld;

  double dMeth() {
    int i3, i4 = 72, iArr2[] = new int[N];
    double dArr[] = new double[N];
    for (i3 = 151; i3 > 1; i3--) {
      i4 ^= 126;
      iArr2[i3 + 1] = (int) instanceCount;
      iArr2[i3] = i4;
    }
    for (int ax$2 = 3499; ax$2 < 14327; ax$2 += 1) {}
    long meth_res = Double.doubleToLongBits(checkSum(dArr));
    return meth_res;
  }

  int iMeth(long l1, double d) {
    int iArr1[] = new int[N];
    float fArr[] = new float[N];
    iArr1[1] *= dMeth();
    long meth_res = Double.doubleToLongBits(checkSum(fArr));
    return (int) meth_res;
  }

  void vMeth(int i1, long l, int i2) {
    double d3 = 39.89739;
    i2 *= iMeth(instanceCount, d3);
  }

  void mainTest(String[] strArr1) {
    int i = 4;
    vMeth(iFld, instanceCount, i);
  }

  public static void main(String[] strArr) {
    Test _instance = new Test();
    for (int i; ; ) _instance.mainTest(strArr);
  }

  public static double checkSum(float[] a) {
    double sum = 0;
    for (int j = 0; j < a.length; j++) {
      sum += (a[j] / (j + 1) + a[j] % (j + 1));
    }
      return sum;
  }

  public static double checkSum(double[] a) {
    double sum = 0;
    for (int j = 0; j < a.length; j++) {
      sum += (a[j] / (j + 1) + a[j] % (j + 1));
    }
    return sum;
  }
}