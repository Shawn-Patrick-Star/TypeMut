is not thrown when incompatible class change is made.

This failure happens since jdk1.5.0-b19 with only the Client VM and
only in compiled mode on all platforms.

Tiger 1.5.0-beta-b18 passes this test successfully.

Steps to reproduce this bug:

javac Test.java
javac OtherTest.java

java -client -Xcomp Test


The test outputs:

% .../jdk1.5.0-b22/solaris-sparc/bin/java -client -Xcomp Test
>> Method Test.foo()...
>> Method Test.foo()...
## TEST FAILED:
## IncompatibleClassChangeError is NOT thrown.


% .../jdk1.5.0-b22/solaris-sparc/bin/java -client Test
>> Method Test.foo()...
>> TEST PASSED:
>> IncompatibleClassChangeError is correctly thrown.


% .../jdk1.5.0-b22/solaris-sparc/bin/java -server -Xcomp Test
>> Method Test.foo()...
>> TEST PASSED:
>> IncompatibleClassChangeError is correctly thrown.


The test sources:

Test.java
------------------------------------------------------------------------------
public class Test implements TestInterface1 {
    public final void foo() {
        System.out.println(">> Method Test.foo()...");
    }

    public static void main(String[] args) {
        try {
            TestInterface1 test = new Test();
            test.foo();
            TestInterface1 otherTest = new OtherTest();
            otherTest.foo();
        } catch (IncompatibleClassChangeError e) {
            System.out.println(">> TEST PASSED:");
            System.out.println(">> IncompatibleClassChangeError is correctly thrown.");
            System.exit(95);
        }

        System.out.println("## TEST FAILED:");
        System.out.println("## IncompatibleClassChangeError is NOT thrown.");
        System.exit(97);
    }
}