
class OtherTest implements TestInterface1 {
    public void foo() {
        System.out.println(">> Method OtherTest.foo()...");
    }
}