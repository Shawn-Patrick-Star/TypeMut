
interface TestInterface1 {
    void foo();
}