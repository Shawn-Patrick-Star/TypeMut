class T2 {
  void v(int p, byte o, int q) {
    int[] g = {};
    int[] y = {};
    int k = 1214167904;
    try {
      for (int z = 1; z < k; z++) g[z] = y[z + k];
    } catch (Throwable x) {
    } finally {
    }
  }

  void b() {
    for (int i = 2; ; ) v(40049, (byte) 35, i);
  }

  public static void main(String[] g) {
    new T2().b();
  }
}

