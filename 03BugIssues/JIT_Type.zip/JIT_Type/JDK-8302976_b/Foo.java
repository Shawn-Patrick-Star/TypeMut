

public class Foo {
  public static short bar(float f) {
    return Float.floatToFloat16(f);
  }
  public static void main(String[] args) {
    System.out.println(bar(Float.float16ToFloat((short) 31745)));
    System.out.println(Float.floatToFloat16(Float.float16ToFloat((short) 31745)));
  }
}