public class Reduced3 {
    static long instanceCount;
    static int iFld;

    public static void main(String[] strArr) {
        test(0);
    }

    static void test(int i1) {
        int i13, i15, i16 = 48, i17;
        for (i13 = 3; ; ++i13) {
            for (i15 = 5; i15 > 1; --i15) {
                instanceCount >>= i1 <<= i16;
            }
            i1 >>>= i16;
            for (i17 = 1; i17 < 5; i17++) {
                try {
                    i1 = 1;
                } catch (ArithmeticException a_e) {
                }
            }
        }
    }
}

