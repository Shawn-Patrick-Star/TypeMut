
Here is a simple class that shows the problem:

//////////////////////////
public class Test
{
public static void main (String[] args)
{
    final int size = 15;
    int[] xIn = new int[size];
    int[] yIn = new int[size];
    int[] xOut = new int[size];
    int[] yOut = new int[size];

    for (int i = 0; i < 10; ++i) {

        for (int j = 0; j < 1000; ++j)
            transformArrays(xIn, yIn, xOut, yOut);

        String msg = i + ". xOut= ";
        for (int x : xOut) 
            msg += x + ",";
        System.out.println(msg);
    }
}

private static void transformArrays (int xIn[], int yIn[],
             int xOut[], int yOut[])
{
    for (int i = 0; i < xIn.length; i++) {
        xOut[i] = xIn[i];
        yOut[i] = yIn[i];
        add11(xOut, yOut, i);
    }
}

static void add11 (int x[], int y[], int i)
{
    x[i] += 11;
    y[i] += 11;
}
}