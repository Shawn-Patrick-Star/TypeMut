 import jdk.incubator.vector.IntVector;
 import jdk.incubator.vector.VectorMask;


public class Test {
     private static int ARR_LEN = 1024;
     private static final int NUM_ITER = 2000;

     public static Object test() {
         boolean[] arr = new boolean[ARR_LEN];
         VectorMask<Integer> vm = VectorMask.fromArray(IntVector.SPECIES_128, arr, 0);

         for (int ic = 0; ic < NUM_ITER; ic++) {
             for (int i = 0; i < ARR_LEN; i += 16){
                 vm = vm.and(vm);
             }
         }
         return vm;
     }


     public static void main(String[] args) {
         for (int i = 0; i < NUM_ITER; i++) {
             test();
         }
         System.out.println("PASS");
     }
 }