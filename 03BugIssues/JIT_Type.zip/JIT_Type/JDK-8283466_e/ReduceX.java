class Test {
  int a;
  long b;
  int c;
  void d() {
    int f = 0, g, h = 1, i = 3, j, k = 7, l[] = new int[a];
    FuzzerUtils.init(l, 6);
    for (g = f; g < 8;) {
      b = c;
      switch (i) {
      case 7:
        h -= 4;
        for (j = 2; j > f; j -= 3) {
          l[j] = g;
          try {
            h = l[1] % k;
          } catch (ArithmeticException m) {
          }
          b = k;
          switch (g) {
          case 2:
            i -= i;
          }
        }
      }
    }
    while (f < 3)
      ;
  }
  public static void main(String[] n) {
    Test o = new Test();
    o.d();
  }
}
class FuzzerUtils {
    static void init(int[] a, int seed) {
        for (int j = 0; j < a.length; j++) {
            a[j] = (j % 2 == 0) ? seed + j : seed - j;
        }
    }
}
