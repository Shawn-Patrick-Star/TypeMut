class Test {
  boolean bFld;

  void mainTest(String[] strArr1) {
    double d = 2.61331;
    int i, i30, i32;
    for (i30 = 830; i30 > 51; --i30) bFld = bFld;
    i32 = 1;
    while (++i32 < 908)
      for (int ax$2 = -3230; ax$2 < 9840; ax$2 += 2)
        try {
          java.lang.invoke.MethodHandle ax$0 = null;
          ax$0.invokeExact();
        } catch (Throwable ax$1) {
        } finally {
        }
    System.out.println("d i i30 = " + d);
  }

  public static void main(String[] strArr) {
    Test _instance = new Test();
    for (; ; ) _instance.mainTest(strArr);
  }
}