   3   │ public class aastore00101m031 {
   4   │     public static boolean run() {
   5   │         Object[] createIntfArray = SupplierHolder.createIntfArray();
   6   │         byte createByte = SupplierHolder.createByte();
   7   │         createIntfArray[createByte] = SupplierHolder.createObject();
   8   │         return true;
   9   │     }
  10   │
  11   │     public static void main(String[] args) {
  12   │         run();
  13   │     }
  14   │ }