public class Test {
    static int iFld;
    static int limit = 0;

    public static void main(String[] args) {
        test();
    }
    
    static void test() {
        short x = -100;
        for (int i = 0; i < limit; i++) {
            x++;
        }
        x++;
        
        switch (x) {
            case -32767: // Short.MIN_VALUE + 1
            case 32767:  // Short.MAX_VALUE
                iFld = 2;
        }
    }
}

