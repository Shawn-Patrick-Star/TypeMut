// Reproduces all the way back to 7u.
// javac TestX2.java
// java -XX:CompileCommand=quiet -XX:CompileCommand=compileonly,TestX2::test -XX:-TieredCompilation -XX:CompileThreshold=100 -XX:-BackgroundCompilation TestX2
public class TestX2 {
    static final int[] A = new int[2];

    public static void main(String[] args) {
        int gold = test(-2);

        for (int i = 0; i < 20_000; i++) {
            test(0);
            test(2);
            test(-2);
        }

        int res = test(-2);
        if (res != gold) {
            throw new AssertionError("wrong result: " + res + ", gold: " + gold);
        }
    }

    static int test(int start) {
        try {
            // CmpU Condition: start <u A.length = 2
            return A[start];
        } catch (ArrayIndexOutOfBoundsException ex) {
            // From CmpU Condition: start >=u A.length = 2
            int i = start;
            while (i < 3) {
                // Truncating induction-variable update.
                i = (i + 1) & 0x7fff;
                if (i < 1) {
                    break;
                }
            }
            return i;
        }
    }
}
