public class H {
    static boolean flag;
    static int[] iArr = new int[10000];
    
    public static void main(String[] args){
        for (int i = 0; i < 10000; i++) {
            try {
                flag = !flag;
                test();
            } catch (Exception e) {}
        }
    }
    
    static void test() {
        int x = flag ? Integer.MIN_VALUE : 3;
        dontInline();
        for (int i = 0; i < x; i++) {
            iArr[i*2] = 666 + i; // stride to avoid ArrayFill
        }
    }
    
    static void dontInline() {}
}
