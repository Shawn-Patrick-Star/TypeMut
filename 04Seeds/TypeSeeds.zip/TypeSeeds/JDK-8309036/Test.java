
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public class Test {
    public static void main(String[] args) throws Exception {
        for (int i = 0; i < 100_000; ++i) {
            test();
        }
    }

    static MethodHandle mh;

    public static void test() throws Exception {
        mh = MethodHandles.lookup().findStatic(Test.class, "test", MethodType.methodType(void.class));
    }
}
