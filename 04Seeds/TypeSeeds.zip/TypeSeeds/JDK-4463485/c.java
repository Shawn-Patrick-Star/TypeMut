// ------------------------------------------------------------
// t1.java
class c
{
    private int val;

    void setVal( int x )
    {
        this.val = x;
    }
}