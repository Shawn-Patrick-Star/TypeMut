class Test {
    static int array[] = new int[100];

    static int test() {
        int res = 0;
        for (int i = 1; i < 100; ++i) {
            try {
                res = array[i - 1];
                int x = (42 % i);
            } catch (ArithmeticException e) {
            }
        }
        return res;
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10_000; i++) {
            test();
        }
    }
}
