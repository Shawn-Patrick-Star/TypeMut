public class Test2 {
    static boolean bFld;
    static int iFld;

    public static void main(String[] args) {
        bFld = false;
        for (int i = 0; i < 50000; i++) {
            test(i % 2 == 0);
        }
        bFld = true;
        test(true);
    }

    static void test(boolean flag) {
        Super a = new A();
        Super b = new B();
        Super s = (flag ? a : b);
        check();
    }

    static void check() {
        if (bFld) {
            iFld = 34;
        }
    }
}

class Super {}
class A extends Super {}
class B extends Super {}
