public class Test {
    static final Object GOLD = test();

    public static Object test() {
        double x = 1.0;
        try {    
            return Long.remainderUnsigned(1, (long)(x % x));
        } catch (ArithmeticException e) {
            return e;
        }
    }    

    public static void main(String[] args) {
        System.out.println(GOLD);
        for (int i = 0; i < 1000_000; i++) {
            test();
	}
        System.out.println(test());
    }
}
