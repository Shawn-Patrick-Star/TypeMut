public class Reduced {
    static int x = 34;

    public static void main(String[] strArr) {
        for (int i = 0; i < 2; i++) {
            test();
        }
    }

    static int test() {
        int a = 5, b = 6;
        long lArr[] = new long[2];

        for (long i = 159; i > 1; i -= 3) {
            a += 3;
            for (int j = 1; j < 4; j++) {
                if (a == 9) {
                    if (x == 73) {
                        try {
                            b = 10 / (int) i;
                        } catch (ArithmeticException a_e) {
                        }
                    }
                }
            }
        }
        return b;
    }
}
