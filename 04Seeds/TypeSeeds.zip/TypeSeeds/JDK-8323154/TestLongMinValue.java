public class TestLongMinValue {
    static long limit = 0;
    static long res = 0;

    static void test() {
        for (long i = 0; i >= limit + (Long.MIN_VALUE+1); i += Long.MIN_VALUE) {
            res += 42;
        }
    }

    public static void main(String[] args) {
        test();
    }
}
