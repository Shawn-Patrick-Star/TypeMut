public class Test {
    static final int RANGE = 1024 * 16;
    static final int ITER = (RANGE / 2) - 1;  // 8191

    static short[] sArr1 = new short[RANGE];
    static short[] sArr2 = new short[RANGE];
    static int[] out = new int[ITER];
    static int[] golden = new int[ITER];

    static {
        for (int i = 0; i < RANGE; i++) {
            sArr1[i] = (short) i;
            sArr2[i] = (short) i;
        }

        for (int i = 0; i < ITER; i++) out[i] = 1;
        test(out);
        System.arraycopy(out, 0, golden, 0, ITER);
    }

    public static void main(String[] args) {
        for (int k = 0; k < 10000; k++) {
            for (int i = 0; i < ITER; i++) out[i] = 1;
            test(out);
            for (int i = 0; i < ITER; i++) {
                if (out[i] != golden[i]) {
                    throw new RuntimeException(
                        "Mismatch at " + i + ": " + out[i] + " != " + golden[i]
                    );
                }
            }
        }
    }

    static void test(int[] out) {
        for (int t = 0; t < 10; t++) {
            for (int i = 0; i < ITER - 2; i += 4) {
                out[i]     = sArr1[2*i] * sArr2[2*i+1] + sArr1[2*i+1] * sArr2[2*i];
                out[i + 1] = sArr1[2*i+2] * sArr2[2*i+2] + sArr1[2*i+3] * sArr2[2*i+3];
            }
        }
    }
}