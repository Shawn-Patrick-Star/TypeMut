public class Reduced {
    long x;
    int iArrFld[];

    public static void main(String[] strArr) {
        Reduced obj = new Reduced();
        for (int i = 0; i < 100; i++) {
            obj.test();
        }
    }

    void test() {
        for (int i = 7; i < 152; i++) {
            x = 0;
        }
        for (int i = 3; i < 273; i++) {
            for (long j = 3; j < 97; j++) {
                if (i == 7) {
                    for (int k = 2; k > 1; k--) {
                        iArrFld[1] = i;
                    }
                }
            }
        }
    }
}
