public class Test {
    public static void main(String[] args) {
        int[] a = new int[1005];
        for (int i = 0; i < 10000; i++) {
            test((i % 2) == 0, a);
        }
    }

    static void test(boolean flag, int[] a) {
        int x = (flag) ? 1000 : 2147483646;
        for (int i = ((Integer) (0)); i <= x; i += 4) {
            if (!flag) {
                return;
            }
            a[i] = 34;
        }
    }
}