
class BMI {
    static int shift(int a, int b) {
        return a >> b;
    }

    public static void main(String[] args) {
        shift(42, 23);
    }
}