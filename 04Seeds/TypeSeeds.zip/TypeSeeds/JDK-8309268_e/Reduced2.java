public class Reduced2 {
    static int N = 400;
    static long instanceCount;

    public static void main(String[] strArr) {
        for (int i = 0; i < 10; i++) {
            test();
        }
    }

    static void test() {
        int i, i1 = 10, iArr[] = new int[N];
        for (i = 1; i < 63; ++i) {
            i1 += Math.min(instanceCount, iArr[i]--);
        }
    }
}
