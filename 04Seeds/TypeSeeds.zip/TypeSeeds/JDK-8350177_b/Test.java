

public class Test {
    public static byte[] array = fill(new byte[10000]);

    public static byte[] fill(byte[] a) {
        for (int i = 0; i < a.length; i++) {
            a[i] = (byte)i;
        }
        return a;
    }

    static final byte[] GOLD = test();

    public static byte[] test() {
        byte[] out = new byte[10000];
        for (int i = 0; i < out.length; i++) {
            out[i] = ((byte)Integer.bitCount(array[i]));
        }
        return out;
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10_000; i++) {
            test();
	}

        byte[] res = test();
        for (int i = 0; i < 10_000; i++) {
            if (res[i] != GOLD[i]) {
                throw new RuntimeException("value mismatch: " + res[i] + " vs " + GOLD[i]);
	    }
	}
    }
}
