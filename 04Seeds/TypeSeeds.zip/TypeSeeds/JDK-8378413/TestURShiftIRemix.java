public class TestURShiftIRemix {

    static int test(int y, int[] arr) {
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            int x = arr[i];
            // Commute puts y in in(1), LShiftI in in(2).
            // remix_address_expressions swap_edges: LShiftI in in(1), y in in(2).
            // Pattern would be matched by JDK-8377389 but node wasn't put on the worklist.
            sum += ((x << 3) + y) >>> 3;
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] arr = new int[1];
        for (int i = 0; i < 20_000; i++) {
            test(42, arr);
        }
    }
}
