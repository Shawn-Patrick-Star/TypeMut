
public class Foo {
  private static int[] a = new int[100];
  private static long val = 0;

  private static void bar() {
    int i = 0;
    for (i = 3; i < 50; i++)
      a[i] += 1;
    val += i;
  }

  public static void main(String[] strArr) {
    bar();
    System.out.println(val);
  }
}