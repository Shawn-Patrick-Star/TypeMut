// java -XX:CompileCommand=compileonly,Test4::test* -XX:CompileCommand=printcompilation,Test4::test* -Xcomp Test4.java

public class Test4 {
    public static void main(String[] args) {
        boolean gold = testA1(256);

        for (int i = 0; i < 10000; i++) {
            boolean val = testA1(256);
            if (val != gold) { throw new RuntimeException("wrong value: " + gold + " vs " + val); }
        }
    }

    public static boolean flag = true;

    static boolean testA1(int n) {
        int a = flag ? -3 : Integer.MAX_VALUE;
        // RegionNode::optimize_trichotomy
        // thinks that the comparisons below operate on the same inputs compare(n, a),
        // but misses to check the Opcode for CmpI vs CmpU.
        if (a > n || Integer.compareUnsigned(n, a) > 0) {
            return true;
        }
        return false;
    }
}
