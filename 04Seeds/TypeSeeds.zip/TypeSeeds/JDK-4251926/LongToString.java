
public class LongToString {
    private long millis = 0L;
    public double toSecs() {
        return millis / 1000.0;
    }
    public String toString() {
        return Double.toString(toSecs());
    }
    private void increment() {
        millis += 1;
    }

    public static void main(String[] arg) {
        LongToString instance = new LongToString();
        for (int i = 0; i < 500; i += 1) {
            System.out.println(Integer.toString(i) +
			       ": " + instance.toString());
            instance.increment();
        }
    }
}