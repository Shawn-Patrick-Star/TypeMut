// Run with:
// java -XX:CompileOnly=Reduced2::test -XX:-TieredCompilation -Xbatch -XX:VerifyIterativeGVN=10 Reduced2.java
public class Reduced2 {
    static long lFld;

    public static void main(String[] strArr) {
        for (int i = 0; i < 100; i++) {
            test();
        }
    }

    static void test() {
        long l3 = 0;
        int i13 = 1;
        for (l3 = 8; l3 < 200; ++l3) {
            for (int i12 = 1; i12 < 2; i12++) {
                i13 <<= 73;
            }
        }
        for (int i14 = 1; 2 > i14; ++i14) {
            i13 &= l3;
            lFld = i13;
        }
    }
}

