// java --enable-preview -Xcomp  -XX:CompileCommand=compileonly,Test::test -XX:+StressUnstableIfTraps -XX:RepeatCompilation=100 Test.java
public class Test {
    static B bFld, bFld2;
    static boolean flag;

    public static void main(String[] args) {
        new B(); // Make sure loaded
        for (int i = 0; i < 10000; i++) {
            test();
        }
    }

    static void test() {
        B b1 = bFld;
        B b2 = bFld2;

        while (flag) {
            if (b1.o != b2.o) {
                A a = (A) b2.o;
            }
        }
    }
    
    static class A {}
    
    static class B {
        Object o;
    }
}

