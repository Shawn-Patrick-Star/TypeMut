class Reduced {
    static boolean bFld;
    static int iArr[] = new int[0];

    public static void main(String[] strArr) {
        test();
    }

    static void test() {
        int x = 8;
        int y = 4;
        for (int i : iArr) {
            x += 2;
            if (bFld) {
                x = 3;
            } else {
                y = 2;
            }
            for (int j = 0; j < 10; j++) {
                x = 0;
                y += 5;
                if (bFld) ;
                else {
                    iArr[1] = 5;
                }
            }
        }
    }
}
