/*
 * Copyright (c) 2022, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

// java -XX:+StressIGVN -XX:StressSeed=873 -XX:-TieredCompilation -Xcomp -XX:CompileCommand=compileonly,Test8290246::run Test8290246 

public class Test8290246 {
    
    static class Item {
        static boolean enabled;
        boolean isEnabled() {
            return enabled;
        }
    }

    static class NotLoaded {
        static boolean armed;
        static boolean isArmed() {
            return armed;
        }
    }

    public static Item run(Item[] items) {
        int currentIndex = -1;
        int matches = 0;
        int firstMatch = -1;
        int[] indexes = null;

        for (int j = 0; j < items.length; j++) {
            Item item = items[j];
            if (item.isEnabled()) {
                if (matches == 0) {
                    firstMatch = j;
                    matches++;
                } else {
                    if (indexes == null) {
                        indexes = new int[items.length];
                        indexes[0] = firstMatch;
                    }
                    indexes[matches++] = j;
                }
            }
            if (NotLoaded.isArmed()) { // Uncommon trap
                currentIndex = matches - 1;
            }
        }

        if (matches == 0) {
            // no op
        } else if (matches == 1) {
            return items[firstMatch];
        } else {
            return items[indexes[(currentIndex + 1) % matches]];
        }
        return null;
    }

    public static void main(String[] args) {
        Item[] items = new Item[42];
        java.util.Arrays.fill(items, new Item());
        Item.enabled = true;
        for (int i = 0; i < 20000; i++ ) {
            run(items);
        }
    }
}
