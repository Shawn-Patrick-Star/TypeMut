public class Reduced {
    static boolean bFld;

    public static void main(String[] strArr) {
        test();
    }

    static void test() {
        int i, i1 = 0, i28, i30 = 0, iArr[] = new int[10];
        boolean bArr[] = new boolean[10];
        i = 1;
        while (++i < 5) {
            try {
                i1 = iArr[i - 1];
                i1 = 2 / i;
            } catch (ArithmeticException a_e) {
            }
            if (bFld) {
                switch (i) {
                    case 4:
                        for (i28 = 3; 100 > i28; i28++) {
                            i1 -= i28;
                        }
                        if ((i30 -= 3) > 0) {
                            switch (i30) {
                                case 4:
                                    bArr[i - 1] = bFld;
                                    iArr[i] = 6;
                            }
                        }
                }
            }
        }
    }
}
