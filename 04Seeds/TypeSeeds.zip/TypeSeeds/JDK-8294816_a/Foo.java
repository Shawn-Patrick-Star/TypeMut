public class Foo {

    private static final int SIZE = 256;

    private static int val = 65536;
    private static short[] a = new short[SIZE];
    private static short[] b = new short[SIZE];

    public static void bar() {
        for (int i = 0; i < SIZE; i++) {
            b[i] = (short) Math.min(a[i], val);
        }
    }

    public static void main(String[] args) throws Exception {
        Class.forName("java.lang.Math");
        a[100] = 100;
        bar();
        System.out.println(b[100]);
    }
}

// $ java Foo
// 100
// $ java -Xcomp -XX:-TieredCompilation -XX:CompileOnly=Foo.bar Foo
// 0
