class Test4 {
    static final int RANGE = 1024;
    static final int ITER  = 10_000;

    static void init(int[] dataI, float[] dataF) {
        for (int i = 0; i < RANGE; i++) {
            dataI[i] = i + 1;
            dataF[i] = i + 0.1f;
        }
    }

    static void test(int[] dataIa, int[] dataIb, float[] dataFa, float[] dataFb) {
        for (int i = 0; i < RANGE; i+=2) {
            dataFa[i + 0] = dataIa[i + 0] * 1.3f;
            dataIb[i + 0] = (int)dataFb[i + 0] * 11;
            dataIb[i + 1] = (int)dataFb[i + 1] * 11;
            dataFa[i + 1] = dataIa[i + 1] * 1.2f;
        }
    }

    static void verify(String name, int[] data, int[] gold) {
        for (int i = 0; i < RANGE; i++) {
            if (data[i] != gold[i]) {
                throw new RuntimeException(" Invalid " + name + " result: data[" + i + "]: " + data[i] + " != " + gold[i]);
            }
        }
    }

    static void verify(String name, float[] data, float[] gold) {
        for (int i = 0; i < RANGE; i++) {
            if (data[i] != gold[i]) {
                throw new RuntimeException(" Invalid " + name + " result: data[" + i + "]: " + data[i] + " != " + gold[i]);
            }
        }
    }

    public static void main(String[] args) {
        int[] dataI = new int[RANGE];
        int[] goldI = new int[RANGE];
        float[] dataF = new float[RANGE];
        float[] goldF = new float[RANGE];
        init(goldI, goldF);
        test(goldI, goldI, goldF, goldF);
        for (int i = 0; i < ITER; i++) {
            init(dataI, dataF);
            test(dataI, dataI, dataF, dataF);
        }
        verify("test", dataI, goldI);
        verify("test", dataF, goldF);
    }
}

