public class Test {
    static int micro2() {
        int[] arr = new int[4];
        synchronized(Test.class) {}
        arr[0] = 5;
        arr[1] = 5;
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 32; j++) {
                switch (i) {
                    case -1:
                        break;
                    case 0:
                        arr[3] = 5;
                }
            }
        }
        return arr[0] + arr[3];
    }

    private static final int N = 100000;
    public static void main(String[] args) {
        int res = 0;
        for (int i = 0; i < N; i++) {
            res += micro2();
        }
        if (res != 10 * N) {
            throw new RuntimeException("Unexpected result: " + res);
        }
    }
}

