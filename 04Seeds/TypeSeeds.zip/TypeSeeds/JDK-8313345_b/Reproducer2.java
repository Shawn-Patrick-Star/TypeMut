public class Reproducer2 {

    public static void main(String[] args) {
        A a = new A();
        B b = new B();
        double[] c = new double[1000];
        for (int i = 0; i < 1000; i++) {
            a.fill(c);
            b.fill(c);
        }
    }

    public static class A {
        void fill(double[] array) {
            for (int i = 0; i < array.length; ++i) {
                array[i] = this.transform(array[i]);
            }
        }

        public double transform(double value) {
            return value * value;
        }
    }

    public static class B extends A {
        public double transform(double value) {
            return value * 1.1;
        }
    }
}
