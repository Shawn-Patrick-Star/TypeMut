public class Test {

    public static double test() {
        double d = 0.1;
        double res = d % 42.0 % 43.0 % 44.0 % 45.0 % 46.0 % 47.0;
        res = 0;
        return res;
    }

    public static void main(String[] args) {
        for (int i = 0; i < 100_000_000; i++) {
            test();
        }
    }
}
