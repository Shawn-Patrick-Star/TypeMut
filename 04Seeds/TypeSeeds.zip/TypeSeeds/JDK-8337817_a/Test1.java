public class Test1 {
    static final int RANGE = 1024*16;
    static final int ITER  = RANGE/2 - 1;

    static short[] sArr1 = new short[RANGE];
    static short[] sArr2 = new short[RANGE];
    static final int[] GOLDEN_K;

    static {
        for (int i = 0; i < RANGE; i++) {
            sArr1[i] = (short)(i);
            sArr2[i] = (short)(i);
        }
        GOLDEN_K = testk(new int[ITER]);
    }


    public static void main(String[] args) {
        for (int i = 0; i < ITER; i++) {
            compare(testk(new int[ITER]), GOLDEN_K, "testk");
        }
    }

    public static void compare(int[] out, int[] golden, String name) {
        for (int i = 0; i < ITER; i++) {
            if (out[i] != golden[i]) {
                throw new RuntimeException("wrong value: " + name + " i=" + i + " out_i=" + out[i] + " golden_i=" + golden[i]);
            }
        }
    }

    public static int[] testk(int[] out) {
        for (int i = 0; i < ITER-2; i+=2) {
            // Unrolled, with some swaps that prevent vectorization.
            out[i+0] += ((sArr1[2*i+0] * sArr2[2*i+1]) + (sArr1[2*i+1] * sArr2[2*i+0])); // bad
            out[i+1] += ((sArr1[2*i+2] * sArr2[2*i+2]) + (sArr1[2*i+3] * sArr2[2*i+3])); // ok
        }
        return out;
    }
}

