// java -XX:CompileCommand=compileonly,TestX1::test -XX:CompileCommand=printcompilation,TestX1::test -Xbatch TestX1.java
public class TestX1 {
    public static void main(String[] args) {
        int gold = test(-2);

        for (int i = 0; i < 10_000; i++) {
            test(2);
            test(-2);
        }

        int res = test(-2);
        if (res != gold) {
            throw new AssertionError("wrong result: " + res + ", gold: " + gold);
        }
    }

    private static int test(int start) {
        // CmpU Condition: start <u 2
        if (Integer.compareUnsigned(start, 2) < 0) {
            return 0;
        }
        // Now, correct:        start >=u 2
        // But filtered_int_type mistakes it as a CmpI.
        // Bad CmpU assumption: start >=  2

        int i = start;
        while (i < 3) {
            // While condition: i <= 2

            // char-truncation of iv: has_truncation_wrap
            // We try to see if the char-truncation can be removed.
            //
            // Computing loop entry type:
            //   While condition: i <= 2
            //   Bad assumption from CmpU: start >= 2
            //   -> entry type i = 2
            //
            // Together with the backedge type, we get the complete phi type:
            //   i in [1..2]
            //
            // The truncation below would be a no-op for input ranges [0 .. 32767].
            // Since [1..2] is a subrange: remove truncation!
            //
            // But: the correct CmpU assumption would only be:
            //   start >=u 2
            // And that allows almost all values (except 0 and 1), in particular
            // it allows the whole negative int range.
            // And the while condition also allows all negative ints.
            // And for negative ints, the truncation is NOT a no-op.
            i = (i + 1) & 0x7fff;

            // Continuing after the backedge would mean:
            //   i >= 1
            // Together with while condition:
            //   i <= 2
            // We get a backedge type:
            //   i in [1..2]
            if (i < 1) {
                break;
            }
        }
        return i;
    }
}
