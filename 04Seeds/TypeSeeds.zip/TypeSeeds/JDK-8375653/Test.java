// -Xcomp -XX:CompileOnly=Test::test Test.java
public class Test {
    public static void main(String[] args) {
        for (int i = 0; i < 20000; i++) {
            test(true, 1, 100, 2);
	    test(false, 1, 100, 2);
        }
    }

    private static void test(boolean b, int start, int limit, int step) {
        int v2 = b ? 1 : -1;
	int v1 = 0;
	for (int i = start; i < limit; i *= step) {
            if (Integer.compareUnsigned(v1, v2) < 0) {
                v1 = 2;
	    } else {
                v1 = 0;
            }
	}
    }
}

