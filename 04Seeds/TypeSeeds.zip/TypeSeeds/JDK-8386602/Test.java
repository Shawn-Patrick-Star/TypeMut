// java --enable-preview -Xbatch -XX:-TieredCompilation -XX:+StressUnstableIfTraps -XX:CompileCommand=compileonly,Test::test -XX:CompileCommand=repeatcompilation,Test::test,100 Test.java
public class Test {
    static Integer iFld = 123;

    public static void main(String[] args) {
        for (int i = 0; i < 10_000; i++) {
            test(123);
        }
    }

    static boolean test(Integer o) {
        return o == 123 && o == iFld;
    }
}
