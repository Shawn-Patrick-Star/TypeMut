class Test2 {
    static int N;
    static void test() {
      int iArr2[] = new int[N];
      short s1 = 1;
      double d = 1.0;
      for (int i = 49; i > 8; i--) {
          for (int j = 7; j > i; j -= 3) {
              if (i == 8) {
                  s1 *= iArr2[1];
              }
              d = iArr2[j];
          }
      }
      Double.doubleToLongBits(d);
    }
    public static void main(String[] strArr) {
      for (int i = 0; i < 10_000; i++) {
          test();
      }
    }
}
