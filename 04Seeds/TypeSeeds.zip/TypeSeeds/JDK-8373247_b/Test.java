public class Test {

    public static final int N = 400;

    public static long instanceCount=-28302L;
    public static double dFld=0.65085;
    public static float fFld=-106.290F;
    public static volatile int iFld=198;
    public static long lArrFld[]=new long[N];
    public static boolean bArrFld[]=new boolean[N];

    static {
        FuzzerUtils.init(Test.lArrFld, 2404633767L);
        FuzzerUtils.init(Test.bArrFld, false);
    }

    public static long vSmallMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long iMeth1_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;

    public static int iMeth() {

        int i2=0;

        i2 += (int)((--Test.instanceCount) + i2);
        long meth_res = i2;
        iMeth_check_sum += meth_res;
        return (int)meth_res;
    }

    public static void vSmallMeth(int i, int i1) {


        i -= (int)(Test.lArrFld[(i1 >>> 1) % N]--);
        i *= iMeth();
        vSmallMeth_check_sum += i + i1;
    }

    public static void vMeth(double d2) {

        int i4=-1, i5=2, i6=16519, i7=-75, i8=-26, i9=-14, iArr[]=new int[N];
        byte by1=118;
        boolean b1=false;

        FuzzerUtils.init(iArr, 96);

        i4 <<= i4;
        for (i5 = 6; i5 < 357; i5++) {
            try {
                i6 = (iArr[i5 - 1] % i4);
                i6 = (-218 % i5);
                i6 = (i6 % -84);
            } catch (ArithmeticException a_e) {}
            Test.instanceCount *= 8;
            Test.instanceCount = Test.instanceCount;
            d2 += -126.783F;
            i7 = 1;
            while (++i7 < 5) {
                for (i8 = 1; i8 < 1; ++i8) {
                    i6 += (i8 - by1);
                    Test.lArrFld[i7 - 1] = by1;
                    if (b1) {
                        if (b1) {
                            i4 -= (int)d2;
                            Test.instanceCount += i8;
                            Test.bArrFld[i5 - 1] = true;
                        } else {
                            by1 = (byte)Test.instanceCount;
                        }
                    } else if (b1) {
                        iArr[i8] = i8;
                    } else {
                        i9 = i9;
                    }
                }
            }
        }
        vMeth_check_sum += Double.doubleToLongBits(d2) + i4 + i5 + i6 + i7 + i8 + i9 + by1 + (b1 ? 1 : 0) +
            FuzzerUtils.checkSum(iArr);
    }

    public static long lMeth() {

        int i3=36020, i10=-125, i11=-38798, i12=-4, i13=-7, i14=-12109, i15=-2, i16=-4;
        byte by=69;

        i3 = (int)((i3 = (int)(4228501300389568015L + (by -= (byte)i3))) - Test.instanceCount);
        vMeth(Test.dFld);
        i10 = 1;
        do {
            i3 += (int)Test.instanceCount;
        } while (++i10 < 162);
        for (i11 = 9; i11 < 156; ++i11) {
            for (i13 = 1; i13 < 11; ++i13) {
                i14 += i14;
                for (i15 = 2; i15 > 1; --i15) {
                    Test.instanceCount = i10;
                    i3 = i12;
                    i16 = (int)Test.instanceCount;
                    Test.fFld = 35L;
                    i16 += (i15 * i15);
                    i16 >>= i14;
                    Test.instanceCount += (i15 * i15);
                }
            }
        }
        long meth_res = i3 + by + i10 + i11 + i12 + i13 + i14 + i15 + i16;
        lMeth_check_sum += meth_res;
        return (long)meth_res;
    }

    public static int iMeth1(boolean b, double d, double d1) {

        int i17=-54343, i18=-9, i19=51381, i20=-107, iArr1[]=new int[N];
        float fArr[]=new float[N];

        FuzzerUtils.init(fArr, -1.576F);
        FuzzerUtils.init(iArr1, 7110);

        lMeth();
        for (i17 = 381; i17 > 18; i17 -= 2) {
            Test.instanceCount += i18;
            i18 *= -10;
            Test.instanceCount = i17;
            fArr[i17 - 1] = i18;
            i18 = i18;
            i18 += i18;
            if (b) continue;
            for (i19 = i17; i19 < 9; ++i19) {
                iArr1[i19 + 1] += (int)Test.instanceCount;
                iArr1[i17 - 1] += i18;
                i20 = i18;
                i18 = i18;
                i20 += 9;
            }
        }
        long meth_res = (b ? 1 : 0) + Double.doubleToLongBits(d) + Double.doubleToLongBits(d1) + i17 + i18 + i19 + i20
            + Double.doubleToLongBits(FuzzerUtils.checkSum(fArr)) + FuzzerUtils.checkSum(iArr1);
        iMeth1_check_sum += meth_res;
        return (int)meth_res;
    }

    public void mainTest(String[] strArr1) {


        for (int smallinvoc=0; smallinvoc<661; smallinvoc++) vSmallMeth(iMeth(), (int)(((-2836562714996675934L *
            iMeth1(true, Test.dFld, Test.dFld)) + Test.iFld) / (Test.iFld | 1)));
        Test.iFld += (int)Test.fFld;
        Test.iFld = Test.iFld;

        FuzzerUtils.out.println("Test = " + Test.instanceCount);

        FuzzerUtils.out.println("Test.instanceCount Test.dFld Test.fFld = " + Test.instanceCount +
            "," + Double.doubleToLongBits(Test.dFld) + "," + Float.floatToIntBits(Test.fFld));
        FuzzerUtils.out.println("Test.iFld Test.lArrFld Test.bArrFld = " + Test.iFld + "," +
            FuzzerUtils.checkSum(Test.lArrFld) + "," + FuzzerUtils.checkSum(Test.bArrFld));
        FuzzerUtils.out.println("Test = " + Test.instanceCount);

        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("iMeth1_check_sum: " + iMeth1_check_sum);
    }
    public static void main(String[] strArr) {

        try {
            Test _instance = new Test();
            for (int i = 0; i < 10; i++ ) {
                _instance.mainTest(strArr);
            }
         } catch (Exception ex) {
            FuzzerUtils.out.println(ex.getClass().getCanonicalName());
         }
    }
}
///////////////////////////////////////////////////////////////////////
//DEBUG  Test ->  Test
//DEBUG  main ->  main
//DEBUG  mainTest ->  mainTest
//DEBUG  vSmallMeth ->  vSmallMeth mainTest Test
//DEBUG  iMeth ->  iMeth vSmallMeth mainTest Test
//DEBUG  iMeth1 ->  iMeth1 mainTest
//DEBUG  lMeth ->  lMeth iMeth1 mainTest
//DEBUG  vMeth ->  vMeth lMeth iMeth1 mainTest
//DEBUG  Depth = 3
//DEBUG  Classes = 1
//DEBUG  static objects = {}
