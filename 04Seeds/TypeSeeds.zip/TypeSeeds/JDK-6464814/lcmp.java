
public class lcmp {
    public static long test(long a) {
        if (a != 10) {
            return 2;
        } else {
            return 1;
        }
    }

    static volatile long value = 10;
    static volatile long value2 = 0;

    public static void main(String[] args) {
        long total = 0;
        for (int i = 0; i < 20000; i++) {
            total += test(value);
            total += test(value2);
        }
        System.out.println(total);
    }
}