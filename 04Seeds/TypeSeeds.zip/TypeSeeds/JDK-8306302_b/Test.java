class Test {
    static final int RANGE = 1024;
    static final int ITER  = 10_000;

    static void init(double[] dataF) {
        for (int i = 0; i < RANGE; i++) {
            dataF[i] = i * 0.5;
        }
    }

    static void test(double[] dataFa, double[] dataFb, double[] dataFc) {
        for (int i = 0; i < RANGE; i++) {
            dataFc[i] = (dataFa[i] == dataFb[i]) ? dataFa[i] : dataFb[i];
        }
    }

    public static void main(String[] args) {
        double[] dataFa = new double[RANGE];
        double[] dataFb = new double[RANGE];
        double[] dataFc = new double[RANGE];
        init(dataFa);
        init(dataFb);
        init(dataFc);
        for (int i = 0; i < ITER; i++) {
            test(dataFa, dataFb, dataFc);
        }
    }
}

