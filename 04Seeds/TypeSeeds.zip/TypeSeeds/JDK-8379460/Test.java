public class Test {

    public static final int N = 400;

    public static long instanceCount=39329L;
    public static volatile short sFld=-23809;
    public static boolean bFld=false;
    public static volatile int iFld=56416;
    public static byte byFld=50;
    public static double dFld=-116.53908;
    public float fFld=0.609F;
    public int iFld1=0;
    public static long lArrFld[][]=new long[N][N];
    public static float fArrFld[]=new float[N];
    public static int iArrFld[]=new int[N];

    static {
        FuzzerUtils.init(Test.lArrFld, -94L);
        FuzzerUtils.init(Test.fArrFld, 1.664F);
        FuzzerUtils.init(Test.iArrFld, 2);
    }

    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    public static void vMeth2(int i) {

        int i1=38257, i2=-51444, i3=-12, i4=-11, i5=33146, iArr1[]=new int[N];
        float f=84.370F;
        byte by=27;
        long l=-6L;

        FuzzerUtils.init(iArr1, 2);

        Test.sFld = (short)i;
        for (i1 = 7; i1 < 159; i1 += 2) {
            i -= (int)Test.instanceCount;
            for (i3 = 1; i3 < 20; i3++) {
                iArr1[i3] += -20;
                iArr1[i1 + 1] += (int)Test.instanceCount;
                Test.instanceCount = i;
                switch ((i1 % 2) + 72) {
                case 72:
                    Test.instanceCount -= 38299;
                    break;
                case 73:
                    i4 += (int)f;
                    break;
                }
                i4 = (int)Test.instanceCount;
                by += (byte)(i3 * i3);
            }
            i5 = 1;
            do {
                i4 *= i;
                l <<= i1;
            } while (++i5 < 20);
        }
        vMeth2_check_sum += i + i1 + i2 + i3 + i4 + Float.floatToIntBits(f) + by + i5 + l + FuzzerUtils.checkSum(iArr1);
    }

    public static void vMeth1() {

        int i6=104, i7=-217, i8=-63, i9=335, i10=-14, iArr2[][]=new int[N][N];
        float f1=1.251F;
        byte byArr[]=new byte[N];

        FuzzerUtils.init(byArr, (byte)-84);
        FuzzerUtils.init(iArr2, 41137);

        vMeth2(i6);
        for (i7 = 6; i7 < 168; i7++) {
            Test.lArrFld[i7 - 1][i7] <<= i7;
            Test.sFld = (short)i7;
            for (i9 = 1; i9 < 10; i9++) {
                i10 += (((i9 * i10) + i6) - i6);
                switch ((((i10 >>> 1) % 7) * 5) + 123) {
                case 126:
                    Test.lArrFld[i9 + 1] = Test.lArrFld[i7 - 1];
                    Test.sFld += (short)(-13 + (i9 * i9));
                    Test.instanceCount += (((i9 * f1) + i8) - i10);
                    break;
                case 151:
                    if (Test.bFld) break;
                    byArr[i7 + 1] <<= (byte)i10;
                    Test.instanceCount = i7;
                    i6 = (int)f1;
                    break;
                case 132:
                    Test.iFld <<= (int)2958556254752639491L;
                case 157:
                    i10 -= (int)Test.instanceCount;
                case 129:
                case 133:
                    byArr[i7] += Test.byFld;
                    break;
                case 143:
                    iArr2[i7][i7] = Test.byFld;
                default:
                    Test.instanceCount %= (i8 | 1);
                }
            }
        }
        vMeth1_check_sum += i6 + i7 + i8 + i9 + i10 + Float.floatToIntBits(f1) + FuzzerUtils.checkSum(byArr) +
            FuzzerUtils.checkSum(iArr2);
    }

    public static void vMeth() {

        int i11=217, i12=-5663, i13=-64, i14=14, iArr[]=new int[N];

        FuzzerUtils.init(iArr, 5);

        iArr = (iArr = (iArr = (iArr = FuzzerUtils.int1array(N, (int)-238))));
        vMeth1();
        Test.dFld *= Test.instanceCount;
        Test.instanceCount = Test.iFld;
        for (i11 = 1; i11 < 129; ++i11) {
            for (i13 = 1; i13 < 12; ++i13) {
                Test.byFld += (byte)i13;
                i14 = (int)Test.instanceCount;
            }
            Test.iFld += (i11 * i11);
            Test.iFld += (-12 + (i11 * i11));
        }
        vMeth_check_sum += i11 + i12 + i13 + i14 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest(String[] strArr1) {

        int i15=-151, i16=-169, i17=147, i18=-8, i19=-40595;
        float f2=1.629F;
        double d=-24.1385;
        long l1=81L;

        vMeth();
        for (i15 = 4; 175 > i15; ++i15) {
            Test.fArrFld[i15] = fFld;
            i16 = (int)Test.dFld;
            Test.iFld = i15;
            f2 = 1;
            do {
                fFld += f2;
                Test.iFld = (int)Test.instanceCount;
                i16 -= (int)Test.instanceCount;
            } while (++f2 < 147);
            try {
                i16 = (Test.iFld / -29512);
                i16 = (Test.iFld / Test.iArrFld[i15]);
                i16 = (i16 / 19);
            } catch (ArithmeticException a_e) {}
            Test.iFld = i16;
            fFld = Test.iFld;
            Test.iFld += (((i15 * i16) + Test.iFld) - i16);
            for (d = 147; d > i15; d -= 3) {
                i16 = i15;
                Test.iFld -= i17;
                Test.sFld = (short)593118488L;
                if (false) break;
            }
            l1 = 1;
            do {
                Test.sFld += (short)fFld;
                switch ((((i16 >>> 1) % 2) * 5) + 99) {
                case 104:
                    Test.iFld += (int)(l1 - Test.instanceCount);
                    switch ((i15 % 6) + 29) {
                    case 29:
                        for (i18 = 3; i18 > 1; --i18) {
                            if (Test.bFld) break;
                            Test.instanceCount = Test.instanceCount;
                            Test.instanceCount += (long)1.101441;
                        }
                        fFld -= f2;
                        Test.instanceCount += (-42581 + (l1 * l1));
                        break;
                    case 30:
                        Test.iFld = i15;
                        break;
                    case 31:
                        i16 = iFld1;
                        break;
                    case 32:
                        iFld1 += i15;
                        break;
                    case 33:
                        i17 -= Test.iFld;
                        break;
                    case 34:
                        if (Test.bFld) continue;
                    default:
                        Test.instanceCount &= Test.iFld;
                    }
                    break;
                case 106:
                    Test.iFld = (int)Test.instanceCount;
                default:
                    iFld1 = i15;
                }
            } while ((l1 += 3) < 147);
        }

        FuzzerUtils.out.println("i15 i16 f2 = " + i15 + "," + i16 + "," + Float.floatToIntBits(f2));
        FuzzerUtils.out.println("d i17 l1 = " + Double.doubleToLongBits(d) + "," + i17 + "," + l1);
        FuzzerUtils.out.println("i18 i19 Test = " + i18 + "," + i19 + "," + Test.instanceCount);

        FuzzerUtils.out.println("Test.instanceCount Test.sFld Test.bFld = " + Test.instanceCount +
            "," + Test.sFld + "," + (Test.bFld ? 1 : 0));
        FuzzerUtils.out.println("Test.iFld Test.byFld Test.dFld = " + Test.iFld + "," +
            Test.byFld + "," + Double.doubleToLongBits(Test.dFld));
        FuzzerUtils.out.println("fFld iFld1 Test.lArrFld = " + Float.floatToIntBits(fFld) + "," + iFld1 + "," +
            FuzzerUtils.checkSum(Test.lArrFld));
        FuzzerUtils.out.println("Test.fArrFld Test.iArrFld Test = " +
            Double.doubleToLongBits(FuzzerUtils.checkSum(Test.fArrFld)) + "," +
            FuzzerUtils.checkSum(Test.iArrFld) + "," + Test.instanceCount);

        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }
    public static void main(String[] strArr) {

        try {
            Test _instance = new Test();
            for (int i = 0; i < 10; i++ ) {
                _instance.mainTest(strArr);
            }
         } catch (Exception ex) {
            FuzzerUtils.out.println(ex.getClass().getCanonicalName());
         }
    }
}
