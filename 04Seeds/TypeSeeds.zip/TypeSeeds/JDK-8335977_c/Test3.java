public class Test3 {
    static boolean bFld;
    static int iFld;

    public static void main(String[] args) {
        bFld = false;
        for (int i = 0; i < 10000; i++) {
            test(i % 2 == 0);
        }
        bFld = true;
        test(true);
    }

    static int test(boolean flag) {
        Super a = new A();
        Super b = new B();
        Super s = (flag ? a : b);
        check();
        return a.i + b.i + s.i;
    }

    static void check() {
        if (bFld) {
            iFld = 34;
        }
    }
}

class Super {
    int i;
}
class A extends Super {}
class B extends Super {}
