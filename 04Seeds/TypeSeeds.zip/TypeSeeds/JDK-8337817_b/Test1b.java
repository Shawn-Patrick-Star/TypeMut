public class Test1b {
    static final int RANGE = 1024*16;
    static final int ITER  = RANGE/2 - 1;

    static short[] sArr1 = new short[RANGE];
    static short[] sArr2 = new short[RANGE];
    static final int[] GOLDEN_K;

    static {
        for (int i = 0; i < RANGE; i++) {
            sArr1[i] = (short)(i);
            sArr2[i] = (short)(i);
        }
        GOLDEN_K = testk(generate());
    }


    public static void main(String[] args) {
        for (int i = 0; i < ITER; i++) {
            compare(testk(generate()), GOLDEN_K, "testk");
        }
    }

    public static int[] generate() {
        int[] a = new int[ITER];
        for (int i = 0; i < ITER; i++) {
            a[i] = 1;
        }
        return a;
    }

    public static void compare(int[] out, int[] golden, String name) {
        long err = 0;
        for (int i = 0; i < ITER; i++) {
            if (out[i] != golden[i]) {
                err++;
                System.out.println("wrong: i=" + i + " out_i=" + out[i] + " golden_i=" + golden[i]);
            }
        }
        if (err > 0) {
            throw new RuntimeException("errors: " + err);
        }
    }

    public static int[] testk(int[] out) {
        for (int i = 0; i < ITER-2; i+=4) {
            // Unrolled, with some swaps that prevent vectorization.
            out[i+0] = ((sArr1[2*i+0] * sArr2[2*i+1]) + (sArr1[2*i+1] * sArr2[2*i+0])); // bad
            out[i+1] = ((sArr1[2*i+2] * sArr2[2*i+2]) + (sArr1[2*i+3] * sArr2[2*i+3])); // ok
            // 2-element gap
        }
        return out;
    }
}

