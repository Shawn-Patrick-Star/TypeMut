public class TestUnorderedReduction {
    static final int RANGE = 512;
    static final int ITER  = 10;

    public static void main(String[] args) throws Exception {
        final TestUnorderedReduction testUnorderedReduction = new TestUnorderedReduction();
        for (int i = 0; i < 500; i++) {
            testUnorderedReduction.runTests();
        }
    }

    public void runTests() throws Exception {
        int[] data = new int[RANGE];

        init(data);
        for (int i = 0; i < ITER; i++) {
            int r1 = test2(data, i);
            int r2 = ref2(data, i);
            if (r1 != r2) {
                throw new RuntimeException("Wrong result test2: " + r1 + " != " + r2);
            }
        }
    }

    static int test2(int[] data, int sum) {
        for (int i = 0; i < RANGE; i+=8) {
            sum += 3 * data[i+0];
            sum += 3 * data[i+1];
            sum += 3 * data[i+2];
            sum += 3 * data[i+3];
            sum += 3 * data[i+4];
            sum += 3 * data[i+5];
            sum += 3 * data[i+6];
            sum += 3 * data[i+7];
        }
        return sum;
    }

    static int ref2(int[] data, int sum) {
        for (int i = 0; i < RANGE; i+=8) {
            sum += 3 * data[i+0];
            sum += 3 * data[i+1];
            sum += 3 * data[i+2];
            sum += 3 * data[i+3];
            sum += 3 * data[i+4];
            sum += 3 * data[i+5];
            sum += 3 * data[i+6];
            sum += 3 * data[i+7];
        }
        return sum;
    }

    static void init(int[] data) {
        for (int i = 0; i < RANGE; i++) {
            data[i] = 1;
        }
    }
}