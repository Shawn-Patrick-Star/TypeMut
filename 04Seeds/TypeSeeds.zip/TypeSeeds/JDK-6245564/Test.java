
class Test {

        float [] fresults  = new float[50];
        int fc = 0;

// variable names copied from SizeRequirements.java's expandedTile function:

        private  void smallTest (int allocated, long min, long pref, long max ) {
                float totalPlay = Math.min(allocated - pref, max - pref);
                fresults[fc] = totalPlay;
                fc++;
        }


        public Test() {

        for (int i=0; i<5; i++) {
                smallTest(88, 48, 48, 65582);
                smallTest(88, 48, 48, 65582);
                smallTest(88, 48, 48, 65582);
        }
        for (int i=0; i<15; i++) {
                System.out.println("result " + i + " = " + fresults[i]);
        }

        try {
                int x = System.in.read();
        } catch (Exception e) {
        }

        fc = 0;
        for (int i=0; i<5; i++) {
                smallTest(88, 48, 48, 65582);
                smallTest(88, 48, 48, 65582);
                smallTest(88, 48, 48, 65582);
        }
        for (int i=0; i<15; i++) {
                System.out.println("result " + i + " = " + fresults[i]);
        }

        } // end constructor

        public static void main(String [] args) {
                Test t = new Test();
        } // end main



}