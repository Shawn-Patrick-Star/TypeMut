// java -Xbatch -XX:CompileCommand=compileonly,Test::test -XX:CompileCommand=printcompilation,Test::test Test.java
//
// gold: [true, false, false]
// res:  [true, false, true]
// Exception in thread "main" java.lang.AssertionError: mismatch!
//     at Test.main(Test.java:19)

import java.util.Arrays;

public class Test {
    static boolean[] x = new boolean[] {true, false};

    static boolean[] test() {
        // copyOf should pad with "false", but C2 seems to pad with "true"
        return Arrays.copyOf(x, 3);
    }

    public static void main(String[] args) {
        boolean[] gold = test();
        for (int i = 0; i < 100_000; i++) {
            test();
        }
        boolean[] res = test();
        System.out.println("gold: " + Arrays.toString(gold));
        System.out.println("res:  " + Arrays.toString(res));
        if (Arrays.hashCode(gold) != Arrays.hashCode(res)) {
            throw new AssertionError("mismatch!");
        }
        System.out.println("ok");
    }
}
