public class Reduced {
    static int N;
    static long x;

    public static void main(String[] strArr) {
        try {
            test();
        } catch (RuntimeException e) {
            // Expected
        }
    }

    static int test() {
        int i6 = 2, i10 = 3, i11, iArr[] = new int[N];
        long l = 3151638515L;
        double dArr[] = new double[N];
        dontInline();
        int i;
        for (i = 7; i < 221; i++) {
            i6 *= i6;
        }
        for (int j = 9; 83 > j; ) {
            for (i11 = 1; i11 < 6; ++i11) {
                l *= i;
                l += 3;
            }
        }
        x += i6;
        return 34;
    }

    static int dontInline() {
        throw new RuntimeException();
    }

}
