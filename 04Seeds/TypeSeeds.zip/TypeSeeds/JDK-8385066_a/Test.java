// Similiar to compiler/arraycopy/TestLoadBypassACWithWrongMem.java

import java.util.Arrays;

public class Test {
    static int test1(int[] src) {
        short[] lcShortArr = new short[Utils.ARRAY_SIZE];
        int[] lcIntArr = new int[Utils.ARRAY_SIZE];
        float lcFloat1 = 807.76886f;
        int lcInt1 = 180;
        int lcInt2 = 180;
        float[] lcFloatArr1 = new float[Utils.ARRAY_SIZE];
        float[] lcFloatArr2 = new float[Utils.ARRAY_SIZE];
        byte[] lcByteArr = new byte[Utils.ARRAY_SIZE];
        double[] lcDoubleArr = new double[Utils.ARRAY_SIZE];
        for (int lcInt = 0; lcInt < lcShortArr.length; lcInt++) {
            lcShortArr[lcInt] = ((short) ((((short) (lcInt)) * 10) + 34));
        }
        for (int lcInt = 0; lcInt < lcIntArr.length; lcInt++) {
            lcIntArr[lcInt] = (((int) (lcInt)) * 100) + 12;
        }
        for (int lcInt = 0; lcInt < lcFloatArr1.length; lcInt++) {
            lcFloatArr1[lcInt] = (((float) (lcInt)) * 1.5F) + 7.89F;
        }
        for (int lcInt = 0; lcInt < lcFloatArr2.length; lcInt++) {
            lcFloatArr2[lcInt] = (((float) (lcInt)) * 1.5F) + 7.89F;
        }
        for (int lcInt = 0; lcInt < lcByteArr.length; lcInt++) {
            lcByteArr[lcInt] = ((byte) ((((byte) (lcInt)) * 5) + 12));
        }
        for (int lcInt = 0; lcInt < lcDoubleArr.length; lcInt++) {
            lcDoubleArr[lcInt] = (((double) (lcInt)) * 1.5) + 7.89;
        }
        int[] dst = new int[10];
        for (lcInt1 = 0; lcInt1 < 333; lcInt1++) {
            System.arraycopy(src, 0, dst, 0, 10);
            src[1] = 0x42;
            lcInt1 = Integer.MAX_VALUE; 
            if (((((138) < 0) || ((Utils.gbInt1) < 0)) || ((Utils.gbInt1) > lcFloatArr1.length)) || ((138) > (Utils.gbInt1))) {
                Arrays.fill(lcFloatArr1, 0, lcFloatArr1.length, (Utils.gbFloat));
            } else {
                Arrays.fill(lcFloatArr1, (138), (Utils.gbInt1), (Utils.gbFloat));
            }
            
            for (lcInt1 = 0; lcInt1 < 333; lcInt1++) {
                if (((((21) < 0) || ((lcInt1) < 0)) || ((lcInt1) > lcByteArr.length)) || ((21) > (lcInt1))) {
                    Arrays.fill(lcByteArr, 0, lcByteArr.length, ((byte)14));
                } else {
                    Arrays.fill(lcByteArr, (21), (lcInt1), ((byte)14));
                }
                
                if (((((296) < 0) || ((Utils.gbInt2) < 0)) || ((Utils.gbInt2) > lcDoubleArr.length)) || ((296) > (Utils.gbInt2))) {
                    Arrays.fill(lcDoubleArr, 0, lcDoubleArr.length, (434.9028512233689));
                } else {
                    Arrays.fill(lcDoubleArr, (296), (Utils.gbInt2), (434.9028512233689));
                }
                
                Arrays.fill(lcShortArr, ((short)935));
                
                Arrays.fill(lcFloatArr2, (lcFloat1));
                
                if (((((lcInt2) < 0) || ((623) < 0)) || ((623) > lcIntArr.length)) || ((lcInt2) > (623))) {
                    Arrays.fill(lcIntArr, 0, lcIntArr.length, (Utils.gbInt2));
                } else {
                    Arrays.fill(lcIntArr, (lcInt2), (623), (Utils.gbInt2));
                }
            }
            
            Arrays.fill(lcIntArr, 0, lcIntArr.length, (255));
        }
        return dst[1];
    }

    static int test2(int[] src) {
        int[] dst = ((int[]) (src.clone()));
        src[1] = 0x42;
        return dst[1];
    }
    
    static Object test5_src = null;
    
    static int test3() {
        int[] dst = new int[10];
        System.arraycopy(Test.test5_src, 0, dst, 0, 10);
        ((int[]) (Test.test5_src))[1] = 0x42;
        System.arraycopy(Test.test5_src, 0, dst, 0, 10);
        return dst[1];
    }

    public static void main(String[] args) {
        try {
            int[] src = new int[10];
            for (int i = 0; i < 20000; i++) {
                Arrays.fill(src, 0);
                int res = Test.test1(src);
                if (res != 0) {
                    throw new RuntimeException((("bad result: " + res) + " != ") + 0);
                }
                Arrays.fill(src, 0);
                res = Test.test2(src);
                if (res != 0) {
                    throw new RuntimeException((("bad result: " + res) + " != ") + 0);
                }
                Arrays.fill(src, 0);
                Test.test5_src = src;
                res = Test.test3();
                if (res != 0x42) {
                    throw new RuntimeException((("bad result: " + res) + " != ") + 0x42);
                }
            }
            System.out.println("Success");
        } catch (Exception ex) {
            System.out.println(ex.getClass().getCanonicalName());
        } catch (Throwable ex) {
            System.out.println(ex.getClass().getCanonicalName());
        }
    }
}

class Utils {

    public static int ARRAY_SIZE = 80;

    public static float gbFloat = 807.76886f;

    public static int gbInt2 = 180;

    public static int gbInt1 = 180;

}