public class Test {

    public static final int N = 400;

    public static long instanceCount=-6994725162317209500L;
    public static byte byFld=54;
    public static short sFld=14399;
    public static float fArrFld[]=new float[N];
    public static long lArrFld[]=new long[N];

    static {
        FuzzerUtils.init(Test.fArrFld, -70.38F);
        FuzzerUtils.init(Test.lArrFld, -10L);
    }

    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long vMeth2_check_sum = 0;

    public static void vMeth2(long l1, int i4, int i5) {

        int i6=-48040, i7=219, i8=8, i9=1, i10=-11, i11=135, i12=183, iArr3[]=new int[N];
        boolean b=false;
        double d=2.130529;

        FuzzerUtils.init(iArr3, -62);

        Test.fArrFld[(i4 >>> 1) % N] = i4;
        i6 = 1;
        do {
            Test.fArrFld[i6 - 1] -= i6;
        } while (++i6 < 256);
        for (i7 = 1; i7 < 121; i7++) {
            Test.instanceCount += i7;
        }
        i9 = 290;
        do {
            for (i10 = 6; i10 > i9; i10 -= 2) {
                b = b;
                i11 -= (int)Test.instanceCount;
                iArr3[i9 + 1] -= (int)Test.instanceCount;
                i12 = 1;
                while (++i12 < 1) {
                    i5 = -75;
                    d = i12;
                    l1 += (i12 * i9);
                    i5 *= (int)Test.instanceCount;
                }
            }
        } while (--i9 > 0);
        vMeth2_check_sum += l1 + i4 + i5 + i6 + i7 + i8 + i9 + i10 + i11 + (b ? 1 : 0) + i12 +
            Double.doubleToLongBits(d) + FuzzerUtils.checkSum(iArr3);
    }

    public static void vMeth1(int i2, int i3, long l) {

        short s=16180;
        int i13=6, i14=7796, i15=11943, i16=167, i17=-2, iArr1[]=new int[N], iArr2[]=new int[N];

        FuzzerUtils.init(iArr1, -74);
        FuzzerUtils.init(iArr2, -68);

        iArr1 = iArr2;
        vMeth2(Test.instanceCount, i3, i3);
        i3 = i2;
        i2 += s;
        for (i13 = 7; i13 < 388; i13++) {
            Test.lArrFld[i13] += Test.instanceCount;
            for (i15 = 1; i15 < 4; ++i15) {
                float f=-2.262F;
                switch (((i13 % 9) * 5) + 36) {
                case 59:
                case 78:
                    i17 = 2;
                    do {
                        Test.instanceCount -= i2;
                        i14 += (i17 ^ i14);
                        i16 += i17;
                        i14 = i13;
                    } while (--i17 > 0);
                    break;
                case 53:
                    Test.instanceCount >>>= l;
                    Test.instanceCount -= i3;
                    break;
                case 72:
                    Test.byFld += (byte)i15;
                case 55:
                    iArr2[i13] = -7;
                    break;
                case 76:
                    l <<= Test.instanceCount;
                    break;
                case 52:
                    f *= Test.instanceCount;
                    break;
                case 68:
                    f *= 2287639666843948595L;
                    break;
                case 39:
                    try {
                        i14 = (89 % i2);
                        iArr2[i13] = (i13 % 193);
                        i3 = (iArr1[i15] % iArr1[i15 - 1]);
                    } catch (ArithmeticException a_e) {}
                    break;
                default:
                    l ^= i14;
                }
            }
        }
        vMeth1_check_sum += i2 + i3 + l + s + i13 + i14 + i15 + i16 + i17 + FuzzerUtils.checkSum(iArr1) +
            FuzzerUtils.checkSum(iArr2);
    }

    public static void vMeth() {

        int i18=-214, i19=-9, i20=-6, i21=-5, i22=2, i23=83, i24=-221, i25=-234, i26=4;
        double d1=0.6433;

        vMeth1(i18, i18, Test.instanceCount);
        i18 += Test.byFld;
        for (i19 = 10; i19 < 255; i19++) {
            for (i21 = 1; i21 < 7; ++i21) {
                Test.instanceCount = i22;
                d1 += i21;
                for (i23 = 1; i23 < 2; i23++) {
                    Test.instanceCount -= i18;
                }
                i22 -= (int)Test.instanceCount;
                switch (i19 % 2) {
                case 0:
                    for (i25 = 1; i25 < 2; i25++) {
                        Test.instanceCount += (i25 - i25);
                        i24 += i25;
                        Test.instanceCount += i22;
                    }
                    Test.byFld -= (byte)11L;
                    break;
                case 1:
                    Test.instanceCount -= Test.instanceCount;
                    break;
                default:
                    i26 &= (int)Test.instanceCount;
                }
            }
        }
        vMeth_check_sum += i18 + i19 + i20 + i21 + i22 + Double.doubleToLongBits(d1) + i23 + i24 + i25 + i26;
    }

    public void mainTest(String[] strArr1) {

        int i=-48932, i1=43832, i27=-80, i28=5, i29=2, i30=-22167, i31=36, i32=3, iArr[]=new int[N];
        boolean b1=true;
        float f1=-1.827F;
        double d2=2.110684;

        FuzzerUtils.init(iArr, -11);

        for (i = 1; 170 > i; i++) {
            iArr[i] = i;
            i1 -= Integer.reverseBytes(i1++);
        }
        vMeth();
        b1 = b1;
        Test.instanceCount <<= -163;
        for (i27 = 2; 154 > i27; i27++) {
            Test.instanceCount -= -1475;
        }
        Test.byFld = (byte)i27;
        i28 &= i27;
        i29 = 1;
        while (++i29 < 366) {
            if (b1) continue;
            iArr[i29 - 1] = i29;
            Test.instanceCount >>>= Test.instanceCount;
            iArr[i29] = -32790;
        }
        if (b1) {
            i1 |= i29;
            i28 = (int)f1;
        } else if (b1) {
            f1 -= (float)-13.31367;
            iArr[(-106 >>> 1) % N] += i28;
        } else {
            i1 -= i28;
        }
        Test.lArrFld[(6 >>> 1) % N] = Test.sFld;
        iArr[(i29 >>> 1) % N] <<= 0;
        f1 *= i29;
        i30 = 1;
        do {
            for (i31 = 3; i31 < 94; ++i31) {
                d2 -= Test.instanceCount;
                i1 *= i29;
                Test.sFld += (short)f1;
                i1 /= (int)(i | 1);
            }
        } while (++i30 < 266);

        FuzzerUtils.out.println("i i1 b1 = " + i + "," + i1 + "," + (b1 ? 1 : 0));
        FuzzerUtils.out.println("i27 i28 i29 = " + i27 + "," + i28 + "," + i29);
        FuzzerUtils.out.println("f1 i30 i31 = " + Float.floatToIntBits(f1) + "," + i30 + "," + i31);
        FuzzerUtils.out.println("i32 d2 iArr = " + i32 + "," + Double.doubleToLongBits(d2) + "," +
            FuzzerUtils.checkSum(iArr));
        FuzzerUtils.out.println("Test = " + Test.instanceCount);

        FuzzerUtils.out.println("Test.instanceCount Test.byFld Test.sFld = " + Test.instanceCount + ","
            + Test.byFld + "," + Test.sFld);
        FuzzerUtils.out.println("Test.fArrFld Test.lArrFld Test = " +
            Double.doubleToLongBits(FuzzerUtils.checkSum(Test.fArrFld)) + "," +
            FuzzerUtils.checkSum(Test.lArrFld) + "," + Test.instanceCount);

        FuzzerUtils.out.println("vMeth2_check_sum: " + vMeth2_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }
    public static void main(String[] strArr) {

        try {
            Test _instance = new Test();
            for (int i = 0; i < 10; i++ ) {
                _instance.mainTest(strArr);
            }
         } catch (Exception ex) {
            FuzzerUtils.out.println(ex.getClass().getCanonicalName());
         }
    }
}
///////////////////////////////////////////////////////////////////////
//DEBUG  Test ->  Test
//DEBUG  main ->  main
//DEBUG  mainTest ->  mainTest
//DEBUG  vMeth ->  vMeth mainTest
//DEBUG  vMeth1 ->  vMeth1 vMeth mainTest
//DEBUG  vMeth2 ->  vMeth2 vMeth1 vMeth mainTest
//DEBUG  Depth = 3
//DEBUG  Classes = 1
//DEBUG  static objects = {}

