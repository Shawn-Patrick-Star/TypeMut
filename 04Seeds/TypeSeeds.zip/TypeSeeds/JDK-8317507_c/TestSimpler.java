// Run on a debug build with -Xcomp -XX:CompileOnly=TestSimpler::test -XX:CompileCommand=dontinline,TestSimpler::dontInline
class TestSimpler {

    static int dontInline() {
        return 0;
    }

    static float test(float inc) {
        int i = 0, j = 0;
        float f = dontInline();
        while (i++ < 128) {
            for (j = 0; j < 16; j++) {
                f += inc;
            }
        }
        return f;
    }

    public static void main(String[] args) {
        TestSimpler.test(0);
    }
}
