public class TestSpeculativeTypes {
    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            test1(false);
            inlined1(true, true);
            inlined2(false);
        }
    }

    private static Object test1(boolean flag1) {
        return inlined1(flag1, false);
    }

    private static Object inlined1(boolean flag1, boolean flag2) {
        if (flag1) {
            return inlined2(flag2); // C1
        }
        return null;
    }

    private static Object inlined2(boolean flag2) {
        if (flag2) {
            return new C1();
        }
        return notInlined1(); // C2
    }

    private static Object notInlined1() {
        return new C2();
    }

    static class C1 {

    }

    static class C2 {

    }
}
