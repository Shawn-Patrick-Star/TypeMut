class TestMin {
    static int RANGE;

    public static void main(String[] args) {
        int[] a = new int[RANGE];
        for (int i = 0; i < 10000; i++) {
            try {
                test(a, 0);
            } catch (ArrayIndexOutOfBoundsException e) {
            }
        }
    }

    static void test(int[] a, int invar) {
        a[new Integer(0)] = 0;

        Object o;
        for (int i = 0; i < 1; i++) {
            o = 1;
        }

        for (int j = 0; Integer.valueOf(j) < 1;) {
            j = 0;
        }
    }
}
