public class Reduced {
    static int N;

    public static void main(String[] strArr) {
         test();
    }

    static void test() {
        int i1 = 4, i4;
        boolean bArr[] = new boolean[N];
        float f = 80.869F;
        do {
            for (i4 = i1; ; i4++) {
                switch (18) {
                    case 18:
                        if (bArr[i4] = f > i4) {}
                }
            }
        } while (i1 > 0);
    }
}
