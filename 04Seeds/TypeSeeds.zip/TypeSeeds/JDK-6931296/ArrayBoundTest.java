public class ArrayBoundTest {

    public static void main(String[] args) {
        byte bb[] = {  1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        try {
            write(bb, -1, 4);
            System.out.println("BAD");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("OK");
        }
    }

    static public void write(byte b[], int off, int len)
    {   
        for (int i = 0; i < len; ++ i)
            write(b[off + i]);
    }

    static  private void write(byte b) {
        
    }

}