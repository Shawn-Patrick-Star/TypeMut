public class Test {

  public static void main(String[] args) {

    String original = "another_query.0.0.0";

 int k=0;

    for (;k<100;) {

      String another_query ="another_query";

      int i = 0 , j = 0;

      String concat_string = new StageId(another_query, 0) +  "." + i + "." + j;

      if (!original.equals(concat_string)) {

        break;

      }
	  k++;
System.out.println(concat_string);
    }

		
  }

}

class StageId {

  private final QueryId queryId;

  private final int id;

  public StageId(String s, int id) {

    this(new QueryId(s), id);

  }

  public StageId(QueryId queryId, int id) {

    this.queryId = queryId;

    this.id = id;

  }

  public String toString() {

    return queryId + "." + id;

  }

}

class QueryId {

  private String s;

  public QueryId(String s) {

    this.s = s;

  }

  public String toString() {

    return s;

  }

}


 