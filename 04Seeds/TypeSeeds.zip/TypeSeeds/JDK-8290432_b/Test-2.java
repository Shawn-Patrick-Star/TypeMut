class Test {
    static boolean bFld;

    public static void main(String[] strArr) {
        test(5);
    }

    static int test(int i1) {
        int i2, i3 = 0, i4, i5 = 0, i6;
        for (i2 = 0; 4 > i2; ++i2) {
            for (i4 = 1; i4 < 5; ++i4) {
                i3 -= --i1;
                i6 = 1;
                while (++i6 < 2) {
                    dontInline();
                    if (bFld) {
                        i1 = 5;
                    }
                }
                if (bFld) {
                    break;
                }
            }
        }
        return i3;
    }

    static void dontInline() {}
}
