/*
 * Copyright (c) 2023, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
/home/xiezf/repository/JVM-Tesing-by-Anti-Optimization/toreport/TestLoopLimitOverflowDuringCCP_09_28_10_53_34/9 * questions.
 */

/*
 * @test
 * @bug 8309266
 * @summary Integer overflow in LoopLimit::Value during PhaseCCP::analyze, triggered by the Phi Node from "flag ? Integer.MAX_VALUE : 1000"
 * @run main/othervm -Xbatch -XX:CompileOnly=compiler.loopopts.TestLoopLimitOverflowDuringCCP::* compiler.loopopts.TestLoopLimitOverflowDuringCCP
 */

package compiler.loopopts;

public class TestLoopLimitOverflowDuringCCP {
    static boolean flag;

    public static void main(String[] strArr) {
        for (int i = 0; i < 10000; i++) {
            flag = !flag;
            test();
        }
    }

    public static void test() {

        // modified code:
        int limit;
        for (int var0 = 0; var0 < 16; var0++) {
            for (int var1 = 0; var1 < var0; var1++) {
                limit = new MyInteger((int) (flag ? Integer.MAX_VALUE : 1000)).value;
                if (var0 % 2 == 0 && var1 % 2 == 0) {
                    break;
                }
            }
        }
        limit = new MyInteger(
                (int) (Integer.valueOf(new MyInteger((int) (flag ? Integer.MAX_VALUE : 1000)).value))).value;
        synchronized (TestLoopLimitOverflowDuringCCP.class) {
            for (int var11 = 0; var11 < 16; var11++) {
                for (int var12 = 0; var12 < var11; var12++) {
                    limit = Integer.valueOf(
                            new MyInteger((int) (new MyInteger((int) (flag ? Integer.MAX_VALUE : 1000)).value)).value);
                    if (var11 % 2 == 0 && var12 % 2 == 0) {
                        break;
                    }
                }
            }
            synchronized (TestLoopLimitOverflowDuringCCP.class) {
                limit = Integer.valueOf(new MyInteger((int) (new MyInteger(
                        (int) (Integer.valueOf(Integer.valueOf(new MyInteger((int) (Integer.valueOf(new MyInteger(
                                (int) (flag ? Integer.MAX_VALUE : 1000)).value))).value)))).value)).value);
                int i = 0;
                while (i < limit) {
                    i += 3;
                    if (flag) {
                        return;
                    }
                }
            }
        }

        // original code:
        // int limit = flag ? Integer.MAX_VALUE : 1000;
        // int i = 0;
        // while (i < limit) {
        // i += 3;
        // if (flag) {
        // return;
        // }
        // }
    }
}

class MyInteger {
    public int value;

    public MyInteger(int value) {
        this.value = value;
    }

    public int v() {
        return value;
    }
}
