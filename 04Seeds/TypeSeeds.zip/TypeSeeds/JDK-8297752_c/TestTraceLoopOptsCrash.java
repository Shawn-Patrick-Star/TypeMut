// java -Xcomp -XX:+TraceLoopOpts -XX:CompileCommand=compileonly,*Test*::* TestTraceLoopOptsCrash.java
public class TestTraceLoopOptsCrash {

    static int[] a = new int[100];
    static int iFld;

    public static void main(String[] args) {
        test();
    }

    public static void test() {

        int zero = -2;
        int limit = 2;

        for (; limit < 4; limit *= 2);
        for (int i = 2; i < limit; i++) {
            zero = 99;
        }

        for (int i = zero; i < 100; i++) {
            iFld = a[i];
        }
    }
}
