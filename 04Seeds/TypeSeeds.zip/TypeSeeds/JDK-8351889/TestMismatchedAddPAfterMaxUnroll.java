public class TestMismatchedAddPAfterMaxUnroll {
    private static C[] arrayField = new C[4];

    public static void main(String[] args) {
        C c = new C();
        Object lock = new Object();
        for (int i = 0; i < 20_000; i++) {
            arrayField[3] = null;
            test1(3, c, arrayField, true, true, lock);
            arrayField[3] = null;
            test1(3, c, arrayField, true, false, lock);
            arrayField[3] = null;
            test1(3, c, arrayField, false, false, lock);
            arrayField[3] = c;
            test1(3, c, arrayField, false, false, lock);
        }
    }

    static class C {

    }

    private static void test1(int j, C c, C[] otherArray, boolean flag, boolean flag2, Object lock) {
        C[] array = arrayField;
        int i = 0;
        for (;;) {
            synchronized (lock) {}
            if (array[j] == null) {
                break;
            }
            otherArray[i] = c;
            i++;
            if (i >= 3) {
                return;
            }
        }
        if (flag) {
            if (flag2) {
            }
        }
        array[j] = c;
    }
}
