class Reduced1 {
  int N;
  long instanceCount;
  int iFld;
  int iFld1;
  short sFld;
  void vMeth(long l, int i1, int i2) {
    int i3, i11;
    for (i3 = 6; 43 > i3; ++i3)
      switch (i3) {
      case 9:
        for (i11 = i3; i11 < 11; ++i11)
          sFld = (short)iFld1;
      }
  }
  int iMeth(int i) {
    int i14;
    double dArr[] = new double[N];
    vMeth(instanceCount, iFld1, iFld1);
    for (i14 = 8; 4 > i14;)
      ;
    long meth_res = Double.doubleToLongBits(FuzzerUtils.checkSum(dArr));
    return (int)meth_res;
  }
  void mainTest(String[] strArr1) { iMeth(iFld); }
  public static void main(String[] strArr) {
    try {
      Reduced1 _instance = new Reduced1();
      _instance.mainTest(strArr);
    } catch (Exception ex) {
    }
  }
}
