public class Reduced {
    static int zero = 0;

    public static void main(String[] args) {
        for (int i = 0; i < 100000; i++) {
            test();
        }
    }

    static void test() {
        int h[] = new int[zero];
        for (int m = 0; m < 5; m++) {
            try {
                for (int f = -400; f < 1; f++) {
                    h[f] = 1; // Out of bounds store.
                }
            } catch (ArrayIndexOutOfBoundsException i) {
                // Expected
            }
        }
    }
}

