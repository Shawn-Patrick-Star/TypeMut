public class TestStackedConcatsInline {
    public static void main (String... args) {
        for (int i = 0; i < 1_000_000; i ++) {
            f(" ");
        }
    }

    static String f(String c) {
        String s =  " ";
        s = s + s;
        s = s + (s == c ? s : " ");
        return s;
    }
}
