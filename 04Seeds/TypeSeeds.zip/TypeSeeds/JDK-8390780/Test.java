/*
java -XX:CompileOnly=Test::* -Xcomp -XX:-TieredCompilation Test.java
CompileCommand: compileonly Test.* intx compileonly = 1111
0.0
0.0 
java -Xint  Test.java
0.0
-0.0
*/
class Test {
    public static void main(String... args) {
        f(0.0, 0.0);
        f(1.0, 0.0);
    }

    static void f(double x, double y) {
        System.out.println((0.0 - x) * (0.0 - y));
    }
}