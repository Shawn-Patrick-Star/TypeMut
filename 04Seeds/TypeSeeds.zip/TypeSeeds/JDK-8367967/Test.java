public class Test {
    static int iFld;
    static long lFld;
    static int limit = 1000;
    static boolean flag;

    public static void main(String[] args) {
        testInt();
        testLong();
    }

    static void testInt() {
        int zero = 0;
 
        // Make sure loop is not counted such that it is not removed. Created a more complex graph for CCP.
        for (int i = 1; i < limit; i*=4) {
            zero = 34;
        }
        int three = flag ? 0 : 3;
        iFld = three % zero; // phi[0..3] % phi[0..34]
    }
    
    static void testLong() {
        long zero = 0;
 
        // Make sure loop is not counted such that it is not removed. Created a more complex graph for CCP.
        for (int i = 1; i < limit; i*=4) {
            zero = 34;
        }
        long three = flag ? 0 : 3;
        lFld = three % zero; // phi[0..3] % phi[0..34]
    }
}
