class MyClass {
    final long l = -31;
    final char c = 4;
}

class MainClass {
    MyClass field;

    void test(int arg) {
        MyClass vt = new MyClass();
        char[] array = new char[1];
        char c = (char)-1;
        for (int i = 0; i < 10; ++i) {
            arg *= 5;
            if (arg < 1) {
                field = vt;
            }
            if (field.l > 1) {
            }
            array[0] = (char)(c - 42);
            c = vt.c;
        }
    }

    public static void main(String[] args) {
        MainClass t = new MainClass();
        for (int i = 0; i < 1_000_000; ++i) {
            t.test(i);
        }
    }
}

