public class Reduced {
    static long lFld;


    public static void main(String[] strArr) {
        test();
    }

    static long test() {
        int x = 10;
        int y = -17;
        int iArr[] = new int[10];
        for (int i = 1; i < 7; i++) {
            for (int j = 1; j < 2; j++) {
                x <<= lFld;
            }
            y &= x;
            y >>= 1;
        }
        return iArr.length;
    }
}

