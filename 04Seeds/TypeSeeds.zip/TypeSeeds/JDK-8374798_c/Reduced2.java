public class Reduced2 {
    public static int iFld = 0;

    public static void mainTest() {
        int iArrFld[] = new int[10];
        int i1 = 0, i2 = -1, i3 = 0;

        for (int i11 : iArrFld) {
            iFld = i11;
            for (i1 = 0; i1 < 10; i1++) {
                iFld <<= i3;
                iFld >>= i2;
                i3 = i2;
            }

            int i16 = 0;
            do {
                for (int f3 = 1; f3 < 1; f3 += 3) {
                    i2 = -1;
                }
            } while (++i16 < 5);
        }
    }

    public static void main(String[] strArr) {
        mainTest();
    }
}
