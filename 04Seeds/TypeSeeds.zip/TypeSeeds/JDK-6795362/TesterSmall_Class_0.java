class TesterSmall_Class_0 {
    static long var_bad = -1L;

    public TesterSmall_Class_0()
    {
      var_bad >>= 65;
      var_bad /= 65;
    }
}