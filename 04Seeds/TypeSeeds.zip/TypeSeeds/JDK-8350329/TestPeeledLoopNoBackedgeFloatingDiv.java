public class TestPeeledLoopNoBackedgeFloatingDiv {
    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            test1(1000, 0, false, false);
        }
        test1(1, 0, false, false);
    }

    private static int test1(int stop, int res, boolean alwaysTrueInPeeled, boolean alwaysFalse) {
        stop = Integer.max(stop, 1);
        for (int i = stop; i >= 1; i--) {
            res = res / i;
            if (alwaysFalse) {

            }
            if (alwaysTrueInPeeled) {
                break;
            }
            alwaysTrueInPeeled = true;
        }
        return res;
    }

}
