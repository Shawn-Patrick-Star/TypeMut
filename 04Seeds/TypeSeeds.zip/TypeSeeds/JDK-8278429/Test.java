
public class Test {

    static class MyClass {
        int val;
        
        public MyClass(int val) {
            this.val = val;
        }
    }

    static class AbstractClass {
        final int unused;

        public AbstractClass() {
            unused = 42;
        }
    }

    static class HolderWithSuper extends AbstractClass {
        final MyClass obj;

        public HolderWithSuper(MyClass obj) {
            this.obj = obj;
        }
    }

    static class Holder {
        final MyClass obj;

        public Holder(MyClass obj) {
            this.obj = obj;
        }
    }

    static class GenericHolder {
        final Object obj;

        public GenericHolder(Object obj) {
            this.obj = obj;
        }
    }

    public static int testSlow(int val) {
        MyClass obj = new MyClass(val);
        HolderWithSuper h1 = new HolderWithSuper(obj);
        GenericHolder h2 = new GenericHolder(h1);
        return ((HolderWithSuper)h2.obj).obj.val;
    }

    public static int testFast(int val) {
        MyClass obj = new MyClass(val);
        Holder h1 = new Holder(obj);
        GenericHolder h2 = new GenericHolder(h1);
        return ((Holder)h2.obj).obj.val;
    }

    public static void main(String[] args) {
        for (int i = 0; i < 100_000; ++i) {
            testSlow(i);
            testFast(i);
        }
    }
}
