class Reduced {
    static long lFld;
    static short sFld;

    public static void main(String[] strArr) {
        Math.min(3,3); // Make sure Math is loaded.
        test();
    }

    static void test() {
        long x = 50398;
        for (int i = 1; i < 100; i++) {
            lFld = --x;
            x = Math.min(sFld, lFld);
        }
    }
}
