// Run with:
//   java -Xbatch -XX:CompileCommand=compileonly,TestStrEquals::test TestStrEquals.java
//
public class TestStrEquals {
    static String other = "xyz";

    public static boolean test() {
        boolean x = true;
        String s = "abcdefghijklmnop";
        byte[] a = new byte[32];

        for (int i = 0; i < 32; i++) {
            // StrEquals gets ctrl after loop, but memory input from middle of the loop body.
            x = s.equals(other);
            a[i] = (byte)(i * 5);
        }
        // StrEquals is moved here, but memory input is before the last store in the loop.
        return x;
    }

    public static void main(String[] argv) {
        for (int i = 0; i < 10_000; i++) {
            test();
        }
    }
}
