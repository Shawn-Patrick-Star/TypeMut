public class Test2 {

    public static final int N = 400;

    public static long instanceCount=-23L;
    public static int iFld=-62957;
    public static float fFld=0.785F;
    public static boolean bFld=true;
    public static double dFld=70.114733;
    public float fFld1=0.767F;
    public static volatile int iArrFld[]=new int[N];
    public long lArrFld[]=new long[N];
    public int iArrFld1[]=new int[N];

    static {
        FuzzerUtils.init(Test2.iArrFld, 47104);
    }

    public static long vMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public static long lMeth1_check_sum = 0;

    public static long lMeth1(short s) {

        float f1=-1.9F;
        int i2=-15, i3=22163, i4=-169, i5=1, i6=-5209, i7=-60332, i8=-19341;
        byte by=101;

        f1 += Test2.instanceCount;
        Test2.instanceCount += (long)f1;
        for (i2 = 16; i2 < 366; i2++) {
            Test2.iFld -= i2;
            i4 = by;
            Test2.instanceCount *= 2;
            i3 = 5;
            for (i5 = 1; i5 < 5; ++i5) {
                try {
                    Test2.iFld = (i6 / -111);
                    i6 = (i5 / -5715);
                    i3 = (-224 % i4);
                } catch (ArithmeticException a_e) {}
                f1 += (1 + (i5 * i5));
                Test2.iFld -= by;
                for (i7 = 1; i7 < 2; ++i7) {
                    i8 += i3;
                    Test2.instanceCount += Test2.instanceCount;
                    Test2.instanceCount >>>= i5;
                }
            }
        }
        long meth_res = s + Float.floatToIntBits(f1) + i2 + i3 + i4 + by + i5 + i6 + i7 + i8;
        lMeth1_check_sum += meth_res;
        return (long)meth_res;
    }

    public static long lMeth(float f, int i1) {

        short s1=-13913;
        int iArr1[]=new int[N];
        byte byArr[]=new byte[N];

        FuzzerUtils.init(iArr1, 140);
        FuzzerUtils.init(byArr, (byte)92);

        iArr1[(i1 >>> 1) % N] = (byArr[(i1 >>> 1) % N]--);
        Test2.instanceCount = ((Test2.iFld--) + lMeth1(s1));
        long meth_res = Float.floatToIntBits(f) + i1 + s1 + FuzzerUtils.checkSum(iArr1) + FuzzerUtils.checkSum(byArr);
        lMeth_check_sum += meth_res;
        return (long)meth_res;
    }

    public static void vMeth(int i, long l) {

        int i9=69, i10=-119, i11=0, i12=13, i13=13, i14=-137, i15=5, i16=99, iArr[]=new int[N];

        FuzzerUtils.init(iArr, -159);

        iArr[(-81 >>> 1) % N] *= (int)lMeth(Test2.fFld, Test2.iFld);
        l = Test2.instanceCount;
        i *= (int)l;
        for (i9 = 13; i9 < 241; ++i9) {
            for (i11 = 1; i11 < 7; i11++) {
                i10 += (int)Test2.fFld;
            }
            for (i13 = 1; i13 < 7; ++i13) {
                for (i15 = 1; 2 > i15; i15++) {
                    Test2.iFld ^= 28686;
                    if (Test2.bFld) {
                        Test2.fFld = i14;
                    }
                    i14 *= (int)Test2.dFld;
                    if (Test2.bFld) {
                        i12 ^= Test2.iFld;
                        i10 += (4 + (i15 * i15));
                    } else {
                        iArr[i13] = (int)Test2.dFld;
                    }
                }
            }
        }
        vMeth_check_sum += i + l + i9 + i10 + i11 + i12 + i13 + i14 + i15 + i16 + FuzzerUtils.checkSum(iArr);
    }

    public void mainTest2(String[] strArr1) {

        int i17=47814, i18=-7, i20=13, i21=30749, i22=235, i23=150;
        short s2=-13646;
        double dArr[]=new double[N];

        FuzzerUtils.init(dArr, 0.58125);

        Test2.iFld *= Test2.iFld;
        vMeth(Test2.iFld, Test2.instanceCount);
        Test2.iArrFld[(17985 >>> 1) % N] = Test2.iFld;
        fFld1 += 2;
        Test2.iFld = Test2.iFld;
        for (i17 = 177; i17 > 1; i17--) {
            i18 += -105;
            try {
                Test2.iArrFld[i17 + 1] = (i17 / 113);
                Test2.iFld = (-20783 % i18);
                i18 = (Test2.iFld % Test2.iFld);
            } catch (ArithmeticException a_e) {}
        }
        for (int i19 : Test2.iArrFld) {
            Test2.iFld = (int)Test2.instanceCount;
            lArrFld = FuzzerUtils.long1array(N, (long)136L);
            Test2.iFld ^= i18;
            for (i20 = 1; 63 > i20; i20 += 3) {
                Test2.fFld -= i21;
                fFld1 = (float)-89.49150;
                for (i22 = i20; i22 < 4; i22++) {
                    switch ((((i17 >>> 1) % 10) * 5) + 9) {
                    case 22:
                        i19 *= (int)fFld1;
                        break;
                    case 38:
                    case 56:
                        if (Test2.bFld) continue;
                        break;
                    case 28:
                        i19 *= i22;
                        break;
                    case 20:
                        switch (((Test2.iFld >>> 1) % 7) + 28) {
                        case 28:
                            Test2.iArrFld[i20 + 1] >>= (int)74229484688062886L;
                            break;
                        case 29:
                            i19 -= Test2.iFld;
                            switch ((i22 % 7) + 81) {
                            case 81:
                                dArr[i22 - 1] *= i17;
                                Test2.instanceCount += (i22 ^ i18);
                            case 82:
                                iArrFld1[i20] -= -82;
                                if (Test2.bFld) break;
                                Test2.iArrFld = iArrFld1;
                                i21 += (i22 * i22);
                                break;
                            case 83:
                            case 84:
                                i23 ^= i23;
                                break;
                            case 85:
                                Test2.instanceCount = i22;
                                break;
                            case 86:
                                i23 = i21;
                                break;
                            case 87:
                                Test2.instanceCount = Test2.instanceCount;
                                break;
                            }
                            break;
                        case 30:
                            Test2.instanceCount = i22;
                            break;
                        case 31:
                            s2 = (short)Test2.fFld;
                        case 32:
                            Test2.iFld = i21;
                            break;
                        case 33:
                            i23 = i18;
                            break;
                        case 34:
                            Test2.instanceCount += (((i22 * Test2.iFld) + i23) - Test2.instanceCount);
                            break;
                        default:
                            i23 <<= i23;
                        }
                        break;
                    case 34:
                        fFld1 -= Test2.fFld;
                        break;
                    case 33:
                        i23 = i21;
                        break;
                    case 52:
                        dArr[i20 + 1] -= 13L;
                        break;
                    case 31:
                        try {
                            i19 = (i21 / Test2.iArrFld[i22 + 1]);
                            Test2.iArrFld[i20] = (i19 / 2069194686);
                            i19 = (Test2.iArrFld[i20] / 47309);
                        } catch (ArithmeticException a_e) {}
                        break;
                    case 30:
                        iArrFld1 = Test2.iArrFld;
                        break;
                    default:
                        i19 = (int)Test2.instanceCount;
                    }
                }
            }
        }

        FuzzerUtils.out.println("i17 i18 i20 = " + i17 + "," + i18 + "," + i20);
        FuzzerUtils.out.println("i21 i22 i23 = " + i21 + "," + i22 + "," + i23);
        FuzzerUtils.out.println("s2 dArr Test2 = " + s2 + "," + Double.doubleToLongBits(FuzzerUtils.checkSum(dArr))
            + "," + Test2.instanceCount);

        FuzzerUtils.out.println("Test2.instanceCount Test2.iFld Test2.fFld = " + Test2.instanceCount +
            "," + Test2.iFld + "," + Float.floatToIntBits(Test2.fFld));
        FuzzerUtils.out.println("Test2.bFld Test2.dFld fFld1 = " + (Test2.bFld ? 1 : 0) + "," +
            Double.doubleToLongBits(Test2.dFld) + "," + Float.floatToIntBits(fFld1));
        FuzzerUtils.out.println("Test2.iArrFld lArrFld iArrFld1 = " + FuzzerUtils.checkSum(Test2.iArrFld) + ","
            + FuzzerUtils.checkSum(lArrFld) + "," + FuzzerUtils.checkSum(iArrFld1));
        FuzzerUtils.out.println("Test2 = " + Test2.instanceCount);

        FuzzerUtils.out.println("lMeth1_check_sum: " + lMeth1_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }
    public static void main(String[] strArr) {

        try {
            Test2 _instance = new Test2();
            for (int i = 0; i < 10; i++ ) {
                _instance.mainTest2(strArr);
            }
         } catch (Exception ex) {
            FuzzerUtils.out.println(ex.getClass().getCanonicalName());
         }
    }
}
///////////////////////////////////////////////////////////////////////
//DEBUG  Test2 ->  Test2
//DEBUG  main ->  main
//DEBUG  mainTest2 ->  mainTest2
//DEBUG  vMeth ->  vMeth mainTest2
//DEBUG  lMeth ->  lMeth vMeth mainTest2
//DEBUG  lMeth1 ->  lMeth1 lMeth vMeth mainTest2
//DEBUG  Depth = 3
//DEBUG  Classes = 1
//DEBUG  static objects = {}
