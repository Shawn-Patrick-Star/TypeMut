// java -Xbatch -XX:-TieredCompilaion Test.java
public class Test {
    static final int SIZE = 1000;
    public static void main(String[] args) {
        byte[] buf = new byte[SIZE];
        for (int i = 0; i < 5_000; i++) {
            testUModI(i, buf);
            testUDivI(i, buf);
        }
    }

    static void testUModI(int n, final byte[] buffer) {
        for (int i = 1; i < SIZE; i++) {
            buffer[i] = (byte) Integer.remainderUnsigned(n, i);
        }
    }

    static void testUDivI(int n, final byte[] buffer) {
        for (int i = 1; i < SIZE; i++) {
            buffer[i] = (byte) Integer.divideUnsigned(n, i);
        }
    }
}
