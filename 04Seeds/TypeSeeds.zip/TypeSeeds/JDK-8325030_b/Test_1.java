
class Test {
    static class A {
        int a;
    }

    public static void main(String[] strArr) {
        int i2 = 0;
        for (int i = 0; i < 50; ++i)
            try {
                synchronized (new A()) {
                    synchronized (Test.class) {
                        for (int var19 = 0; var19 < Integer.valueOf(i2);) {
                            Integer.valueOf(var19);
                        }
                    }
                }
                for (int var8 = 0; var8 < 10000; ++var8) ;
            } catch (ArithmeticException a_e) {
            }
    }
}