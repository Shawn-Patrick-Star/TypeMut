class Test4 {
    static long count;
    static float fval;
    static float arr2[][];
    static float arr[];

    public static void main(String[] argv) {
        test();
    }

    static void test() {
        int x = 1;
        // Sufficiently many iterations to trigger OSR
        for (int j = 0; j < 100_000; j++) {
            for (int i = 1; i > x; --i) {
                float v = arr[0] + fval;
                arr2[i + 1][x] = v;
                count += v;
            }
        }
    }
}
