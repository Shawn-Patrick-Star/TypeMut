
class Test {
  static long val;
  static int iArrFld[] = new int[10];

  static void test() {
    iArrFld[0] = (int)(val >> -1);
    iArrFld[1] = (int)(val >> -1);
  }
  public static void main(String[] strArr) {
    for (int i = 0; i < 10_000; i++) {
      test();
    }
  }
}