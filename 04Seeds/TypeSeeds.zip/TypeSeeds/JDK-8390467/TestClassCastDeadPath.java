public class TestClassCastDeadPath {
    public static void main(String[] args) {
        B b = new B();
        C c = new C();
        A.class.cast(b);
        test1(c);
    }

    private static void test1(Object o) {
        if (!(o instanceof I)) {
            throw new RuntimeException("never taken");
        }
        A.class.cast(o);
    }

    static abstract class A {

    }

    static class B extends A {

    }

    interface I {

    }

    static class C implements I {

    }

}
