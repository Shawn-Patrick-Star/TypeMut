public class Reduced {
    static int iArrFld[] = new int[400];

    public static void main(String[] strArr) {
        for (int i = 0; i < 10; i++) {
            test(1);
        }
    }

    static void test(int i3) {
        int i6 = 156, i8 = 13;
        int i4 = 1;
        do {
            for (int i5 = 1; 7 > i5; i5++) {
                for (int i7 = 2; i4 < i7; i7 -= 3) {
                    try {
                        i8 = (iArrFld[i4 + 1] % i7);
                        i6 = (iArrFld[i4 - 1] / iArrFld[5]);
                        i3 = (10883 / iArrFld[i7 - 1]);
                    } catch (ArithmeticException a_e) {
                    }
                }
            }
        } while (++i4 < 250);
    }
}

