class Test {
    static final int RANGE = 543;
    static final int ITER  = 10_000;

    static void init(int[] data) {
        for (int i = 0; i < RANGE; i++) {
            data[i] = i + 1;
        }
    }

    static void test(int[] a, int[] b, int[] c) {
        for (int i = RANGE-1; i > 0; i--) {
            c[i] = b[i] * a[i];
        }
    }

    public static void main(String[] args) {
        int[] a = new int[RANGE];
        int[] b = new int[RANGE];
        int[] c = new int[RANGE];
        init(a);
        init(b);
        for (int i = 0; i < ITER; i++) {
            test(a, b, c);
        }
    }
}
