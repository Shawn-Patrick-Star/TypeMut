public class Reduced3 {
    static final int RANGE = 1024;
    static int aI[] = new int[RANGE];

    public static void main(String[] strArr) {
        test();
    }

    static int test() {
        int res = 0;
        for (int i = 0; i < RANGE; i+=8) {
            res += aI[i+0] * 11;
            res += aI[i+1] & 13;
            res += aI[i+2] * 11;
            res += aI[i+3] * 11;
            res += aI[i+4] * 11;
            res += aI[i+5] * 11;
            res += aI[i+6] * 11;
            res += aI[i+7] * 11;
        }
        return res;
    }
}

