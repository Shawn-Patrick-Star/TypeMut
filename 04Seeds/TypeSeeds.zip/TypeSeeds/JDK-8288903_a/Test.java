public class Test {

    static final int N = 40;

    static void lMeth() {
        int iArr[]=new int[N];
        float fArr[][]=new float[N][N];

        long l = 0;
        do {
            for (int i = 0; i < 1; ++i) {
                for (int j = (int)l; j < 1; j++) {
                    fArr[i][j] = Integer.reverseBytes(iArr[j]--);
                }
            }
        } while (++l < 1);
    }

    public static void main(String[] strArr) {

        for (int i = 0; i < 10; i++) {
            lMeth();
        }
    }
}
