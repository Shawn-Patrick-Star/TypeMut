class Test {
  int N = 400;
  byte byArrFld[] = new byte[N];
  void mainTest(String[] strArr1) {
    int i = 9, i17 = 32040, i18 = 14, i19 = 159, i20 = 13, i21 = 7, i22 = 58,
        iArr[] = new int[N], iArr4[] = new int[N];
    boolean b3 = false;
    for (i17 = 5; 228 > i17; ++i17) {
      try {
        i = (46318 / iArr4[i17 - 1]);
      } catch (ArithmeticException a_e) {
      }
      i19 = 1;
      do
        for (i20 = 1; i20 > i17; i20 -= 3) {
          iArr4[i20 - 1] %= (i18 | 1);
          iArr4[i19 - 1] -= i19;
          if (b3)
            switch ((i17 % 5) + 3) {
            case 3:
              switch (0 + 20) {
              default:
                iArr[i17 + 1] *= 0f;
              }
            case 5:
              i += 22490;
            case 6:
              byArrFld[i20 + 1] = (byte)223;
            case 7:
              i18 = (int)5442422125903453825L;
            }
        }
      while (++i19 < 113);
    }
  }
  public static void main(String[] strArr) {
    try {
      Test _instance = new Test();
      for (int i = 0; i < 10; i++)
        _instance.mainTest(strArr);
    } catch (Exception ex) {
    }
  }
}
