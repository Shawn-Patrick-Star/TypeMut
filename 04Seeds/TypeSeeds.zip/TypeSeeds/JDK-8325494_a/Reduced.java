public class Reduced {
    static boolean bFld;
    static int iArrFld[];
    static long lArrFld[];

    public static void main(String[] strArr) {
        test();
    }

    static long test() {
        int i6 = 1, i7, i11;
        do {
            for (i7 = 1; i7 < 9; ++i7) {
                for (i11 = 2; i6 < i11; i11 -= 2) {
                    if (bFld) {
                        break;
                    }

                    lArrFld[i11 + 1] = 6;
                    iArrFld[i11 % 20] = 3;
                }
            }
        } while (++i6 < 8);

        return i6;
    }
}

