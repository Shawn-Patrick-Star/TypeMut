public class TestArrayAccessAboveRCAfterSplitIf {
    private static volatile int volatileField;

    public static void main(String[] args) {
        int[] array = new int[1000];
        for (int i = 0; i < 20_000; i++) {
            test(array, array, 0, 2, true);
            inlined(42, array, array, 0, 2, 10, true);
            inlined(2, array, array, 0, 2, 10, true);
            inlined(42, array, array, 0, 2, 10, false);
            inlined(2, array, array, 0, 2, 10, false);
        }
        test(array, array, -1, 2, true);
    }

    private static int test(int[] array1, int[] array2, int i, int l, boolean flag) {
        for (int j = 0; j < 10; j++) {
        }
        int k;
        for (k = 1; k < 2; k *= 2) {

        }
        int m;
        for (m = 0; m < 10; m+=k) {

        }
        return inlined(k, array1, array2, i, l, m, flag);
    }

    private static int inlined(int k, int[] array1, int[] array2, int i, int l, int m, boolean flag) {
        int v;
        int[] array;
        if (array1 == null) {
        }
        if (l == 10) {

        }
        if (flag) {
            if (k == 2) {
                v = array1[i];
                array = array1;
                if (l == m) {
                }
            } else {
                v = array2[i];
                array = array2;
            }
            v += array[i];
        } else {
            if (k == 2) {
                v = array1[i];
                array = array1;
                if (l == m) {
                }
            } else {
                v = array2[i];
                array = array2;
            }
            v += array[i];
        }
        return v;
    }
}
