class Test2 {
    static final int RANGE = 1024;
    static final int ITER  = 10_000;

    static void initNaN(float[] dataF, int offset) {
        for (int i = 0; i < RANGE; i++) {
            dataF[i] = i + ((i + offset) % 5) * 10;
            if (i % (offset + 5) == 0) {
                dataF[i] = Float.NaN;
            }
        }
    }

    static void test(float[] a, float[] b, float[] r) {
        for (int i = 0; i < RANGE; i++) {
            //
            // The gt / lt / ge / le cases lead to wrong result with NaN (-Xbatch or -Xcomp)
            //
            r[i] = (a[i] > b[i]) ? a[i] : b[i];
            // r[i] = (a[i] < b[i]) ? a[i] : b[i];
            // r[i] = (a[i] >= b[i]) ? a[i] : b[i];
            // r[i] = (a[i] <= b[i]) ? a[i] : b[i];
            //
            // The eq / neq cases lead to VM assert (with -Xcomp)
            //
            // r[i] = (a[i] == b[i]) ? a[i] : b[i];
            // r[i] = (a[i] != b[i]) ? a[i] : b[i];
        }
    }

    public static void main(String[] args) {
        float[] a = new float[RANGE];
        float[] b = new float[RANGE];
        float[] r = new float[RANGE];
        float[] r2 = new float[RANGE];
        initNaN(a, 0);
        initNaN(b, 1);
        test(a, b, r2);
        for (int i = 0; i < ITER; i++) {
            test(a, b, r);
        }
        verify(r, r2, a, b);
    }

    static void verify(float[] r, float[] r2, float[] a, float[] b) {
        boolean failed = false;
        for (int i = 0; i < RANGE; i++) {
            if (r[i] != r2[i] && !( Float.isNaN(r[i]) && Float.isNaN(r2[i]) )) {
                System.out.println("fail: " + i + " " + r[i] + " != " + r2[i] + " : " + a[i] + " " + b[i]);
                failed = true;
            }
        }
        if (failed) {
            throw new RuntimeException("There were wrong results");
        }
    }
}

