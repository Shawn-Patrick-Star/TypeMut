// Run with:
//   java -Xbatch -XX:CompileCommand=compileonly,TestArraysHashCode::* TestArraysHashCode.java
//
import java.util.Arrays;

public class TestArraysHashCode {
    public static int test() {
        byte[] a = new byte[32];
        int x = 0;
        for (int i = 0; i < 32; i++) {
            x = Arrays.hashCode(a);
            a[i] = 1;
        }
        // Arrays.hashCode sinks down here,
        // because of missing aliasing analysis.
        // It bypasses the store in the loop,
        // and produces the wrong result.
        return x;
    }

    public static void main(String[] argv) {
        int gold = test();
        for (int i = 0; i < 10_000; i++) {
            int res = test();
            if (gold != res) {
                throw new RuntimeException("wrong result: " + gold + " vs " + res);
            }
        }
    }
}
