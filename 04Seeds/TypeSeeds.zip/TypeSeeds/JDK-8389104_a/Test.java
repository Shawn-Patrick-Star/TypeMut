public class Test {
    public static void main(String[] args) {
        boolean gold = testA1(256);
        for (int i = 0; i < 10000; i++) {
            boolean val = testA1(256);
            if (val != gold) {
                throw new RuntimeException((("wrong value: " + gold) + " vs ") + val);
            }
        }
    }

    public static boolean flag = true;

    static boolean testA1(int n) {
        int a = ((Integer) (flag ? -3 : Integer.MAX_VALUE));
        if ((a > n) || ((n + Integer.MIN_VALUE) > (a + Integer.MIN_VALUE))) {
            return true;
        }
        return false;
    }
}
