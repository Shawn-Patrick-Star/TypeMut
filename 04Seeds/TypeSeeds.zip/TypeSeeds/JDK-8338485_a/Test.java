class Test {
  int a = 6;
  long b;
  int[] iArr9 = { 1, 2 };

  void f() {
    int o = -158;
    int j[] = new int[a];
    for (long e = 7; e < 91; ++e)
      b -= 0;
    for (int d = 3; d > -1; d--) {
      int i13 = d;
      try {
        for (int i0 = 5; i0 < 15; i0++) {
          for (int i11 = o - 1; i11 >= 0; i11--)
            d = iArr9[i11];
        }
      } finally {
        d = i13;
      }
      for (o = 0; o < 2; ++o) ;
    }
  }

  public static void main(String[] l) {
    try {
      Test m = new Test();
      for (int i = 0; i < 1000000; i++)
        m.f();
    } catch (Exception ex) {
    }
  }
}