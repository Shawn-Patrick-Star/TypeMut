public class Reduced {
    static long x;

    static void test() {
        int i3 = 4;
        float f1 = 90;
        int i4 = 2, i5;
        float fArr[] = new float[1000];

        for (float f2 : fArr) { // OSR, 563
            i4 = 1;
            while (++i4 < 4) // CL 577
            {
                for (i5 = i4; i5 < 1; i5++) { // 588
                    x += 9;
                    fArr[5] = x;
                    switch (i4 % 2) {
                        case 5:
                            i3 += 4;
                            f1 -= i3;
                    }
                }
            }
        }
        x += i4 + i4;
        A.foo();
    }

    public static void main(String[] strArr) {
        new Reduced();
        for (int i = 0; i < 1000; i++) {
            test();
        }
    }
}

class A {
    static void foo() {
    }
}
