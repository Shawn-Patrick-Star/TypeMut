/*
 * Copyright (c) 2024, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

// java -XX:CompileCommand=quiet -XX:CompileCommand=compileonly,Reproducer::test* -XX:-TieredCompilation -Xbatch Reproducer.java

public class Reproducer {

    static class MyClass {
        final int val;

        public MyClass(int val) {
            this.val = val;
        }
    }

    public static MyClass testMyClass(boolean alwaysFalse, int limit) {
        for (int i = 0; ; ++i) {
            MyClass obj = new MyClass(42);
            if (alwaysFalse || i > 10) {
                return obj;
            }
            if (i == limit) {
              return null;
            }
        }
    }

    public static String testString(boolean alwaysFalse, int limit) {
        for (int i = 0; ; ++i) {
            String s = new String("42");
            if (alwaysFalse || i > 10) {
                return s;
            }
            if (i == limit) {
              return null;
            }
        }
    }

    public static void main(String[] args) {
        // Warmup
        for (int i = 0; i < 50_000; ++i) {
            testMyClass(false, 10);
            testString(false, 10);
        }
        // Trigger deoptimization
        MyClass obj = testMyClass(false, 11);
        if (obj.val != 42) {
            throw new RuntimeException("Test failed, val = " + obj.val);
        }
        String s = testString(false, 11);
        System.out.println(s);
    }
}
