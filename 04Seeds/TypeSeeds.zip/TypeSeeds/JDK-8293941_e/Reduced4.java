public class Reduced4 {
    static double dFld;

    public static void main(String[] strArr) {
        for (int i = 0; i < 100000; i++) {
            test();
        }
    }

    static boolean test() {
        int i10, i11, i12, i13 = 7, i14;
        for (i10 = 9; 59 > i10; i10 += 2) {
            for (i12 = 3; i12 > i10; i12 -= 3) {
                for (i14 = i12; i14 < 1; ++i14) {
                    if (i13 != 0) {
                        return 2 > 0;
                    }
                }
                try {
                    i11 = i10 % i13;
                } catch (ArithmeticException a_e) {
                }
            }
        }
        Float.floatToIntBits(1);
        return 2 > 0;
    }
}
