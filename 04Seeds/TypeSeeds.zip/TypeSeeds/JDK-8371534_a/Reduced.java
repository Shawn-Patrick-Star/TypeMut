public class Reduced {
    static long lFld;
    static int iFld;

    public static void main(String[] strArr) {
        for (int i = 0; i < 100; i++) {
            test();
        }
    }

    static void test() {
        int x = -6;
        long l;
        for (float f1 = 241; f1 > 13; f1--) {
            for (l = 1; l < 7; l++) {
                iFld = x;
            }
            x += iFld;
            lFld &= x;
            lFld >>>= l;

        }
    }
}

