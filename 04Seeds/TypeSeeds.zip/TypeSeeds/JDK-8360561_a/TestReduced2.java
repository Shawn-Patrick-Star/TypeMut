class TestReduced2 {
    static boolean bFld;

    public static void main(String[] strArr) {
        test();
    }

    static void test() {
        int x = 7;
        int y = 4;
        for (int i = 3; i < 12; i++) {
            if (x != 0) {
                A.foo();
            }
            for (int j = 1; j < 8; j++) {
                x = -195;
                if (bFld) {
                    y += 2;
                }
            }
        }
    }

    static void foo() {
    }
}


class A {
    static void foo() {
    }
}
