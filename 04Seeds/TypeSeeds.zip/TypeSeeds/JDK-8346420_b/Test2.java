public class Test2 {
    static boolean flag;
    static int one = 1;

    public static void main(String[] args) {
        for (int i = 0; i < 10000; i++) {
            test1();
            test2();
        }
    }

    // JDK-8346420
    // java -XX:CompileOnly=Test2::test1 -Xcomp Test2.java
    // -> wrongly takes branch
    static void test1() {
        int minimum, maximum;
        if (flag) {
            minimum = 0;
            maximum = 1;
        } else {
            // Always goes to else-path
            minimum = Integer.MIN_VALUE;
            maximum = Integer.MAX_VALUE;
        }
        // one < INT_MIN || one > MAX_INT
        // 1 < INT_MIN    || 1 > MAX_INT
        //    false          false
        // => false
        //
        // C2 transforms this into:
        // one - minimum >=u (maximum - minimum) + 1
        // 1    - INT_MIN >=u (INT_MAX - INT_MIN) + 1
        // INT_MIN + 1    >=u -1                  + 1
        // INT_MIN + 1    >=u 0
        // => true
        if (one < minimum || one > maximum) {
            // Case: hi > lo, lo_test = lt, hi_test = le
            throw new RuntimeException();
        }
    }

    // java -XX:CompileOnly=Test2::test2 -Xcomp Test2.java
    // -> "fatal error: no reachable node should have no use"
    //
    // The node in question is created in addition "lo = lo + 1", which seems is not used?
    // Then we do "adjusted_val = n - lo", so it seem we are using it?
    // Ah, it seems we transform it, and it does not keep a reference to lo. And then we destruct the hook,
    // but probably do not put the "lo" back on the worklist?
    // If this case hits an assert right away, who knows if the code is correct or ever tested well enough.
    static void test2() {
        int minimum, maximum;
        if (flag) {
            minimum = 0;
            maximum = 1;
        } else {
            minimum = Integer.MIN_VALUE;
            maximum = Integer.MAX_VALUE;
        }
        if (one <= minimum || one > maximum) {
            // Case: hi > lo, lo_test = le, hi_test = le
            throw new RuntimeException();
        }
    }
}
