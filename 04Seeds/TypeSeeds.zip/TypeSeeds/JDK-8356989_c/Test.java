import java.util.ArrayList;

public class Test {

    public static void test() {
        ArrayList<String> list = new ArrayList<String>();
        list.add(0, "A");
        list.add(0, "B");
        if (list.get(1) == null) {
            throw new RuntimeException("Unexpected null");
        }
    }

    public static void main(String[] args) {
        for (int i = 0; i < 100_000; ++i) {
            test();
        }
    }
}
