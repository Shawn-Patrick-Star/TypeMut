import java.math.*;

public class test {
 public static void main( String[] args ) {
   double dvalue = 0.0d;
   float  fvalue = 0.0f;
   Double x1, y1;
   Float  x2, y2;
   if (Double.doubleToLongBits(Math.abs(dvalue)) != ((Double.doubleToLongBits(dvalue)<<1)>>>1)) {
    System.out.println( "Conversation error for Double");
   }
   if (Float.floatToIntBits(Math.abs(fvalue)) != ((Float.floatToIntBits(fvalue)<<1)>>>1)) {
    System.out.println( "Conversation error for Float");
   }

   x1 = new Double(Math.abs(dvalue));
   y1 = new Double(dvalue);
   if (!x1.equals(y1)) {
    System.out.println("Equals error for Double");
   }
   x2 = new Float(Math.abs(fvalue));
   y2 = new Float(fvalue);
   if (!x2.equals(y2)) {
    System.out.println("Equals error for Float");
   }
 }
}