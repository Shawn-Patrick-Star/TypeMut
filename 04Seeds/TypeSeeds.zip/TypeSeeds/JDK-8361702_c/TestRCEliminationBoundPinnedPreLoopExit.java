import java.util.Arrays;

public class TestRCEliminationBoundPinnedPreLoopExit {

    static final int nbIterations = 100;

    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            test1(0);
            test1(0);
        }
    }

    private static float test1(int k) {
        float v = 0;
        int j = 0;
        int[] lengths = new int[2];
        test1Helper(lengths);
        int constantFoldedTo4AfterCCP = 2;
        for (; constantFoldedTo4AfterCCP < 4; constantFoldedTo4AfterCCP *= 2);

        int constantFoldedTo0AfterCCPAnd1RoundLoopOpts;
        for (constantFoldedTo0AfterCCPAnd1RoundLoopOpts = 0; constantFoldedTo0AfterCCPAnd1RoundLoopOpts < 40; constantFoldedTo0AfterCCPAnd1RoundLoopOpts += constantFoldedTo4AfterCCP) {
        }
        constantFoldedTo0AfterCCPAnd1RoundLoopOpts -= 40;
        for (int i = 0; i < nbIterations; i++) {
            int arrayLength2 = Integer.max(Integer.min(lengths[j * k], 1000), 0);
            float[] array = new float[arrayLength2];
            v += array[(constantFoldedTo0AfterCCPAnd1RoundLoopOpts + 1) * i];

            int arrayLength = Integer.max(Integer.min(lengths[k], 1000), 0);

            v += arrayLength & constantFoldedTo0AfterCCPAnd1RoundLoopOpts;

            j = 1;
        }
        return v;
    }

    private static void test1Helper(int[] lengths) {
        lengths[0] = nbIterations+1;
        lengths[1] = nbIterations+1;
    }
}
