public class Reduced {
    public static void main(String[] args) {
        for (int i =0; i< 1000; i++) test(4, null);
    }

    static void test(int x, A a) {
        Object[] objects = { new Object() };
        Object object = new Object();
        for (int i = 0; i < 150; i++) {
            try {
                objects[x] = object;
                object = new byte[10];
            } catch (Exception e) {
            }
            try {
                a.foo();
            } catch (Exception e) {
            }
        }
    }
}

class A {
    void foo() {}
}
