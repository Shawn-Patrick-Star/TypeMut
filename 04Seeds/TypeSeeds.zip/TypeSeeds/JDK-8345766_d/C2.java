public class C2 {
    private static final double Z = 0.3;
    final static int N = 10000000;
    static double res[] = new double[N];

    public static double process(final double x) {
        double w = (double) 0.1;
        double p = 0;
        p = (double) (3.109615012413746E307 % (w % Z));
        p = (double) (7.614949555185036 / (x % 3.6));    // <- return value only dependents on this line
        return (double) (x * p);
    }

    public static void main(String[] args) {
        for (int i = 0; i < N; i++) {
            // process(1.0E-15d);
            res[i] = process(i / 10000);
        }

        for (int i = 0; i < N; i += 1000000) {
            System.out.println(res[i]);
        }
    }
}