class Test {

    public static double checkSum(float[] a) {
        double sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += a[j];
        }
        return sum;
    }

    static final int N = 32;
    static float a[] = new float[N];
    static void f() {
        int b[] = new int[N];
        for (int h = 1; h < 32; h++) {
            a[h] = b[h - 1]--;
            b[h]--;
        }
        boolean c[] = new boolean[N];
    }
    static void o() throws Exception {
        f();
        double s = checkSum(a);
        System.out.println(s);
        if (s < -31 || s > -29) {
            throw new Exception("expected s: -30, actual s: " + s);
        }
    }
    public static void main(String[] q) throws Exception {
        Test.o();
        Test.o();
    }
}
