public class Reduced {
    static long lFld = 4482272172956477350L;
    static long result;

    public static void main(String[] args) {
        for (int i = 0; i < 10000; i++) {
            test();
            if (result != 4482272172956477350L) {
                // Wrongly outputs the cut input 263219110
                throw new RuntimeException("Wrong result: " + result);
            }
        }
    }

    static void test() {
        long x = lFld;
        try {
            result = Integer.bitCount((int)x); // Cut input: 263219110
            throw new RuntimeException();
        } catch (RuntimeException e) {
        }
        result = x;
    }
}
