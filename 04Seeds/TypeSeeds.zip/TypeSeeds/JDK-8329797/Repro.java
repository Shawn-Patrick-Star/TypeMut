class Repro {
  public static class Dummy {
    long i;
    public Dummy(long i) { this.i = i; }
  }
  public static long test(Dummy[] arr) {
    long result = 0;
    for (int i = 0; i < arr.length; ++i) {
      Dummy d = arr[i];
      result += Math.max(d.i, 1);
    }
    return result;
  }
  public static void main(String []args) throws Exception {
    Dummy[] arr = new Dummy[100];
    for (int i = 0; i < 100; ++i) {
      arr[i] = new Dummy(i - 50);
    }
    for (int i = 0; i < 10000; ++i) {
      test(arr);
    }
  }
}