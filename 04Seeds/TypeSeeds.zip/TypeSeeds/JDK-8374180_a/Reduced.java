public class Reduced {
    static byte byFld;

    public static void main(String[] strArr) {
        test();
    }

    static void test() {
        int k, i17 = 0;
        long lArr[] = new long[400];
        for (int i = 9; i < 54; ++i) {
            for (int j = 7; j > 1; j--) {
                for (k = 1; k < 2; k++) {
                    i17 >>= i;
                }
                byFld += j ^ i17;
                for (int a = 1; a < 2; a++) {
                    i17 = k;
                }
            }
        }
    }
}
