
public class foo {
    public static void main(String[] args) {

        for(int idx=0; idx < 10000; idx++)
            bar(0x6EEEEEE, 0x5FFFFFFF);

        System.out.println("bar results in " + bar(0x6EEEEEE, 0x5FFFFFFF) );
    }

    static int bar(int a1, int a2) {
        int v1, v2, v3, v4;

        v3 = 0x6FEFEFEF;
        v4 = 0x5FFFFFFF;
        v2 = v3 + 12;
        v1 = v2 + (v4 + 98);
        v2= (a1*v1) * v3;
        v1 = (a2 + v2);
        return v1;
    }
}