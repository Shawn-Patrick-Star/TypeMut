
class NewException extends Exception {
  public NewException() {
    super();
  }

  public NewException(String s) {
    super(s);
  }
}