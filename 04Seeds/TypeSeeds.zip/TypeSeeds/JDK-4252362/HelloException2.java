	
class HelloException2 extends Object {
  static int count = 0;
  static Exception e;

  public static void main(String[] args) throws Exception {
    for(int i=0; i<10001; i++) 
      blah();
  }

  public static void blah() throws Exception{
    try {
      buildE();
      throw e;
    } catch (NewException e) {
      System.out.println("new excpetion");
    }
  }

  public static void buildE() {
    e = new NewException();
  }
}