class TestReduced {
    public static void main(String[] args) {
        try {
            System.out.print(printFinalState());
        } catch (Throwable ex) { }
    }

    static String printFinalState() {
        String result = "Victim.observeMe = ";
        result += Victim.observeMe;
        return result;
    }
}

class Base {
    double d;
    int i;
    char c = Character.valueOf('3');
    float f = Float.valueOf(0.0F);
    short s;

    { // Class initilizer
        Long.valueOf(2);
        i = Integer.valueOf(4);
        i = Byte.valueOf((byte)4);
        i = '@';
        double unused1 = Float.valueOf(0.57265735F);
        d = Character.valueOf('>');
        long unused2 = Byte.valueOf((byte)1);
        d = f;
        f *= Short.valueOf((short)7);
    }
}

final class Sub extends Base {
    static long staticlong;
    char c;
    Long boxedL = 1048571L;
    long primitiveL;
    Short incorrectlyFoldedShort = 187;

    { // Class initializer
        new Base().d = staticlong = Character.valueOf('"');
        i = true ? Byte.valueOf((byte)9) : 4;
        d = Short.valueOf((short)97);
        f %= f *= incorrectlyFoldedShort;
        i = 2;
        staticlong = incorrectlyFoldedShort;
    }
    short unused3 = s = Double.valueOf(0.07356672796882191).shortValue();
}

class Culprit {
    double iBecomeNan = 1.0007086624001162;

    { // Class initializer
        new Base().i = Integer.valueOf(2022672784).valueOf(5);
        new Base().i = Integer.valueOf(6058048);
        new Sub().i = Character.valueOf('~');
        new Sub().primitiveL = new Sub().incorrectlyFoldedShort + new Sub().c;
        iBecomeNan += new Sub().incorrectlyFoldedShort;
        int unused4 = Character.valueOf(' ') * Integer.valueOf(801);
        try {
            iBecomeNan = Short.valueOf((short)5);
            Sub.staticlong = new Sub().boxedL /= 23851;
            Float.valueOf(1.0003039F);
            iBecomeNan += Float.valueOf(3.4028235E38F);
        } finally {
            new Sub();
        }
        char unused5 = new Base().c;
        // What happens here???
        new Sub().incorrectlyFoldedShort = new Sub().incorrectlyFoldedShort;
        new Sub().d = new Sub().i = new Sub().i = Byte.valueOf((byte)19);
        // C2 believes incorrectlyFoldedShort is 0 and emits iBecomeNan % 0.
        iBecomeNan %= new Sub().incorrectlyFoldedShort;
    }
}

class OtherBase1 {
    double d = new Culprit().iBecomeNan;
}

class OtherSub1 extends OtherBase1 {
    byte b;
}


class OtherBase2 {
    static char c;
}

class OtherSub2 extends OtherBase2 {
    static double d = new Culprit().iBecomeNan;
    static short s;
}


class SomeOtherThing {
    byte b = new OtherSub1().b;
    char c = OtherSub2.c <<= OtherSub2.s;
    double d = new Culprit().iBecomeNan;
}


class OtherBase3 {
    static char c = new SomeOtherThing().c;
}

class Victim extends OtherBase3 {
    static double observeMe = new Culprit().iBecomeNan;
}

