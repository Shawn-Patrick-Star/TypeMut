public class Reduced {
    static long lFld;
    static long lArr[] = new long[400];

    static void test() {
        int i = 1;
        do {
            long x = -1;
            lArr[i] = i;
            lFld += i | x;
        } while (++i < 355);
    }

    public static void main(String[] strArr) {
        for (int i = 0; i < 100; i++) {
            test();
        }
    }
}

