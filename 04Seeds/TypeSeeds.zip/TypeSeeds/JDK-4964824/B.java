// A.java
class B {}