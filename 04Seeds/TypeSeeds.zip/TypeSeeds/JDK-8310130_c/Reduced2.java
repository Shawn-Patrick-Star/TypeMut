public class Reduced2 {
    static int aI[] = new int[1000];

    public static void main(String[] strArr) {
        test();
    }

    static long test() {
        long res = 0;
        for (int i = 0; i < aI.length; i++) {
            int v = aI[i];
            aI[0] = 0;
            res |= v;
        }
        return res;
    }
}

