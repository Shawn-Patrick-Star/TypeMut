
public class TesterSmall {
    public static void main(String[] args)
    {
        try {
            TesterSmall_Class_0 t = new TesterSmall_Class_0();
        } catch (Throwable e) {
          System.out.println("Got exception " + e);
        }
    }
}