
import java.lang.reflect.*;

public class b6389127 {
    static class A { 
        private void method() {
        }
    }
    static class B extends A {
        private void method() {
        }
    }
    static class C extends B {
        private void method() {
        }
    }


    public static void main(String[] args) throws Exception {
        // force C to be loaded
        Class c3 = C.class;

        Method method = B.class.getDeclaredMethod ("method", new Class[0]);
        method.setAccessible(true);

        B rcvr = new B();
        for (int i = 0; i < 10000; i++) {
            method.invoke(rcvr, null);
        }
    }
}