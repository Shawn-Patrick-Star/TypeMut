public class Test {

    public static final int N = 400;

    public static long instanceCount=-8252433380640215179L;
    public static float fFld=70.800F;
    public static byte byFld=-31;
    public static int iArrFld[]=new int[N];

    static {
        FuzzerUtils.init(Test.iArrFld, 0);
    }

    public static long vMeth_check_sum = 0;
    public static long vMeth1_check_sum = 0;
    public static long iMeth_check_sum = 0;

    public static int iMeth(int i1) {

        byte by=-30;
        int i2=185, i3=177, i4=23071, i5=-213, i6=-2;
        long l1=63207L;
        boolean b=true;

        i1 %= (int)(i1 | 1);
        by = (byte)i1;
        i2 = 1;
        while (++i2 < 226) {
            l1 = 7;
            do {
                i1 = i2;
                Test.instanceCount %= (i3 | 1);
                Test.iArrFld = Test.iArrFld;
                i3 += (int)1.426F;
                for (i4 = 1; i4 < 1; ++i4) {
                    Test.fFld += (((i4 * i5) + by) - i4);
                    i1 += 91;
                    Test.instanceCount += l1;
                    i6 -= i5;
                }
                Test.iArrFld = Test.iArrFld;
                b = false;
            } while (--l1 > 0);
        }
        long meth_res = i1 + by + i2 + l1 + i3 + i4 + i5 + i6 + (b ? 1 : 0);
        iMeth_check_sum += meth_res;
        return (int)meth_res;
    }

    public static void vMeth1() {

        int i=14, i7=11, i8=-54, i9=27855, i10=-34, i11=-175;
        double d=-2.50914;
        long lArr[]=new long[N];

        FuzzerUtils.init(lArr, -56769L);

        switch ((((int)(237 - lArr[(i >>> 1) % N])) >>> 1) % 1) {
        case 0:
            i += iMeth(i);
            i = (int)Test.instanceCount;
            break;
        }
        for (i7 = 7; i7 < 338; ++i7) {
            i -= i8;
            Test.instanceCount *= i;
        }
        i9 = 1;
        do {
            Test.byFld += (byte)(i9 ^ Test.instanceCount);
            Test.instanceCount = i9;
            i10 = 1;
            while (++i10 < 6) {
                d += d;
                Test.iArrFld[i9 + 1] >>= i11;
                i8 = i9;
                i8 = 227;
                i8 -= i11;
            }
        } while (++i9 < 274);
        vMeth1_check_sum += i + i7 + i8 + i9 + i10 + Double.doubleToLongBits(d) + i11 + FuzzerUtils.checkSum(lArr);
    }

    public static void vMeth(long l) {

        int i12=-2, i13=60745, i14=9, i15=-85, i16=-94, i17=250, i18=247, i19=107;
        double d1=0.73661;
        long lArr1[]=new long[N];

        FuzzerUtils.init(lArr1, 33873L);

        vMeth1();
        lArr1 = lArr1;
        for (i12 = 9; i12 < 254; ++i12) {
            for (i14 = 7; i14 > 1; i14--) {
                for (i16 = 1; i16 < 2; i16++) {
                    i17 >>= i12;
                }
                i13 = i13;
                Test.byFld += (byte)(i14 ^ i17);
                lArr1[i14 - 1] = 6;
                for (i18 = 1; i18 < 2; i18++) {
                    i15 *= i14;
                    i19 += i18;
                    i15 -= (int)-4285354987L;
                    Test.fFld = (float)d1;
                    i17 += (i18 ^ i16);
                }
            }
        }
        vMeth_check_sum += l + i12 + i13 + i14 + i15 + i16 + i17 + i18 + i19 + Double.doubleToLongBits(d1) +
            FuzzerUtils.checkSum(lArr1);
    }

    public void mainTest(String[] strArr1) {

        int i20=-54972, i21=-39549, i22=45036, i23=-53024, i24=-4, i25=133, i26=7274, i27=193, i28=-179, i29=-129,
            i30=-177;
        double d2=-1.87772;
        boolean b1=false;

        vMeth(Test.instanceCount);
        for (i20 = 7; 145 > i20; i20++) {
            Test.iArrFld = Test.iArrFld;
            i21 >>= 17;
            i21 *= i20;
            if (b1) {
                Test.byFld += (byte)i20;
                for (i22 = 4; 182 > i22; i22++) {
                    Test.instanceCount -= 19190;
                }
                i24 = 182;
                while (--i24 > 0) {
                    i25 = 1;
                    do {
                        Test.byFld = (byte)i24;
                        Test.instanceCount = Test.instanceCount;
                        i23 = (int)Test.instanceCount;
                        Test.iArrFld[i25 + 1] += (int)Test.instanceCount;
                        i21 += (i25 - i24);
                        Test.instanceCount *= i21;
                    } while (--i25 > 0);
                    for (i26 = 1; i26 < 1; i26++) {
                        i27 = i23;
                        Test.iArrFld[i26 + 1] *= -51397;
                        Test.fFld -= 8;
                        i28 *= (int)-126.1000F;
                        i23 = i26;
                        i23 = -2028;
                        i27 = (int)Test.instanceCount;
                        i28 = (int)Test.instanceCount;
                        Test.instanceCount = i28;
                    }
                }
            } else if (b1) {
                for (i29 = 7; i29 < 182; ++i29) {
                    i27 += (i29 * i29);
                    i30 *= (int)d2;
                }
            } else {
                try {
                    i30 = (i30 / 8215);
                    i30 = (Test.iArrFld[i20] / 57274);
                    i21 = (i28 % i24);
                } catch (ArithmeticException a_e) {}
            }
        }

        FuzzerUtils.out.println("i20 i21 i22 = " + i20 + "," + i21 + "," + i22);
        FuzzerUtils.out.println("i23 i24 i25 = " + i23 + "," + i24 + "," + i25);
        FuzzerUtils.out.println("i26 i27 i28 = " + i26 + "," + i27 + "," + i28);
        FuzzerUtils.out.println("i29 i30 d2 = " + i29 + "," + i30 + "," + Double.doubleToLongBits(d2));
        FuzzerUtils.out.println("b1 Test = " + (b1 ? 1 : 0) + "," + Test.instanceCount);

        FuzzerUtils.out.println("Test.instanceCount Test.fFld Test.byFld = " + Test.instanceCount +
            "," + Float.floatToIntBits(Test.fFld) + "," + Test.byFld);
        FuzzerUtils.out.println("Test.iArrFld Test = " + FuzzerUtils.checkSum(Test.iArrFld) + "," +
            Test.instanceCount);

        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }
    public static void main(String[] strArr) {

        try {
            Test _instance = new Test();
            for (int i = 0; i < 10; i++ ) {
                _instance.mainTest(strArr);
            }
         } catch (Exception ex) {
            FuzzerUtils.out.println(ex.getClass().getCanonicalName());
         }
    }
}
///////////////////////////////////////////////////////////////////////
//DEBUG  Test ->  Test
//DEBUG  main ->  main
//DEBUG  mainTest ->  mainTest
//DEBUG  vMeth ->  vMeth mainTest
//DEBUG  vMeth1 ->  vMeth1 vMeth mainTest
//DEBUG  iMeth ->  iMeth vMeth1 vMeth mainTest
//DEBUG  Depth = 3
//DEBUG  Classes = 1
//DEBUG  static objects = {}
