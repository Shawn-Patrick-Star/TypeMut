
class d2f {

  public static boolean foo() {
    double d = Float.NaN;
    return Float.isNaN((float) d);
  }

  public static void main(String[] args) {
    System.exit(foo() ? 2 : 3);
  }
}