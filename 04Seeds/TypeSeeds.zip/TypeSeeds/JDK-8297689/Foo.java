

class Foo {
  static final int SIZE = 50;
  static int a[] = new int[SIZE];

  static void test() {
    for (int i = 0; i < SIZE; i++) {
      a[i] = Short.reverseBytes((short) a[i]);
    }
  }

  public static void main(String[] args) throws Exception {
    Class.forName("java.lang.Short");
    a[25] = 16;
    test();
    System.out.println(a[25]);
  }
}