class Test2 {
    static int N = 400;
    static int iArrFld[] = new int[N];
  
    static void test() {
        float f1 = 1.236F, fArr[] = new float[N];
        int i10, i11 = 2;
        long lArr1[] = new long[N];
        for (int i9 = 7; i9 < 43; i9++) {
            try {
                i10 = 7 % i9;
                iArrFld[i9 + 1] = i9 / i10 % i11;
            } catch (ArithmeticException a_e) {
            }
            for (int i12 = 1; 7 > i12; i12++) {
                i11 = (int)f1;
                lArr1[i9 - 1] = 42;
                iArrFld[i12] = 4;
                fArr[i9 - 1] = f1 = i9;
            }
        }
    }

    public static void main(String[] args) {
        for (int i = 0; i < 100_000; ++i) {
            test();
        }
    }
}
