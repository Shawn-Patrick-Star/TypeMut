// java -Xbatch -XX:-TieredCompilation -XX:CompileOnly=Reduced::test -XX:CompileThreshold=500 Reduced.java
//
// Note: somehow, the CompileThreashold=500 seems important.
class Reduced {
    static int test() {
        String s1 = (("a" == null) ? "b" : "c") + 'd';
        String s2 = new StringBuilder(s1).toString();
        String s3 = new StringBuilder(s2).append(s1).append(s2 == null ? "" : s2).toString();
        return s3.length();
    }

    public static void main(String[] args) {
        for (int t = 0; t < 10_000; t++) {
            // The following line is probably important for profiling.
            try { new String((String) null); } catch (NullPointerException e) {}
            test();
        }
    }
}
