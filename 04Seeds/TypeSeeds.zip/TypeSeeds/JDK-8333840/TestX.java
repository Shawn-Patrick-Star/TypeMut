
public class TestX {
    static int RANGE = 10_000;

    public static void main(String[] args) {
        int[] a = new int[RANGE];
        short[] aS = new short[RANGE];
        short[] bS = new short[RANGE];

        for (int i = 0; i < aS.length; i++) {
            aS[i] = (short)i;
            bS[i] = (short)i;
        }
        for (int i = 0; i < a.length; i++) {
            a[i] = 0;
        }
        int[] gold = a.clone();
        test20d(gold, aS, bS);

        for (int i = 0; i < 10_000; i++) {
            int[] res = a.clone();
            test20d(res, aS, bS);
            for (int j = 0; j < res.length; j++) { if (res[j] != gold[j]) { throw new RuntimeException("bad"); } }
        }
    }

    static void test20d(int[] a, short[] s1, short[] s2) {
        for (int i = 0; i < RANGE / 4; i+=2) {
            a[i+0] += ((s1[2*i+0] * s2[2*i+0]) + (s1[2*i+1] * s2[2*i+1]));
            a[i+1] += ((s1[2*i+2] * s2[2*i+3]) + (s1[2*i+3] * s2[2*i+2]));
        }
    }
}
