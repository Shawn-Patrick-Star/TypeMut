public class Reduced {
    static int iFld;

    public static void main(String[] strArr) {
        test();
    }

    static void test() {
        int iArr[] = new int[400];
        boolean flag = false;
        for (int i = 6; i < 50000; i++) { // Trigger OSR
            try {
                int x = 234 / iFld;
                iFld = iArr[3];
            } catch (ArithmeticException a_e) {
            }
            for (int j = i; j < 2; j++) {
                if (flag) {
                    iArr[j] = 117;
                } else {
                    iArr[1] = 34;
                }
                iArr[1] += i;
            }
        }
    }
}

