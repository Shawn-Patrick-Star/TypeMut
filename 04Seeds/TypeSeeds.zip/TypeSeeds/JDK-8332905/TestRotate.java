public class TestRotate {
    public static void main(String[] args) {
        int checksum = 0;
        for (int i = 0; i < 10_000; i++) {
            int[] x = test203();
            int sum = 0;
            for (int j = 0; j < x.length; j++) {
                sum += x[j];
            }
            if (i == 0) { checksum = sum; }
            System.out.println("sum: " + sum);
            if (sum != checksum) { throw new RuntimeException("wrong result"); }
        }
    }

    static int[] test203() {
        int[] res = new int[10_000];
        for (int i = 0; i < res.length; i++) {
            res[i] = (i << 14) | (i >>> 18);
        }
        return res;
    }
}
