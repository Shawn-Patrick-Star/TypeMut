public class Test_2267 {

    public static final int N = 400;

    public static long instanceCount=-29957L;
    public static short sFld=8230;
    public static double dFld=0.13175;
    public static int iArrFld[]=new int[N];
    public static int iArrFld1[]=new int[N];

    static {
        FuzzerUtils.init(Test_2267.iArrFld, -60198);
        FuzzerUtils.init(Test_2267.iArrFld1, -216);
    }

    public static long vSmallMeth_check_sum = 0;
    public static long lMeth_check_sum = 0;
    public static long iMeth_check_sum = 0;
    public static long vMeth_check_sum = 0;

    public static void vSmallMeth(int i, int i1, int i2) {

        int iArr[]=new int[N];

        FuzzerUtils.init(iArr, 19);

        i1 %= (int)((((iArr[(20807 >>> 1) % N] = (int)Test_2267.instanceCount) * i2) - i) | 1);
        vSmallMeth_check_sum += i + i1 + i2 + FuzzerUtils.checkSum(iArr);
    }

    public static void vMeth() {

        int i8=31828, i9=-147, i10=50165, i11=52103, i12=-1, i13=-151;
        byte by1=110;
        float f3=-4.776F;
        long lArr[]=new long[N];

        FuzzerUtils.init(lArr, 44L);

        for (i8 = 347; 13 < i8; i8 -= 3) {
            Test_2267.iArrFld[i8] = i9;
            i9 = i8;
            for (i10 = i8; 14 > i10; i10++) {
                i12 = 1;
                while (++i12 < 1) {
                    Test_2267.iArrFld[i12] += (int)Test_2267.dFld;
                    i11 -= 2;
                    if (i9 != 0) {
                        vMeth_check_sum += i8 + i9 + i10 + i11 + i12 + by1 + Float.floatToIntBits(f3) + i13 +
                            FuzzerUtils.checkSum(lArr);
                        return;
                    }
                    by1 += (byte)i11;
                    Test_2267.instanceCount += (((i12 * Test_2267.instanceCount) + f3) - i8);
                    switch ((((i8 >>> 1) % 4) * 5) + 26) {
                    case 39:
                        Test_2267.iArrFld[i10] <<= i8;
                        i11 >>>= -26884;
                        i9 = (int)Test_2267.instanceCount;
                        i9 = i12;
                        break;
                    case 42:
                        lArr[i8] >>>= Test_2267.instanceCount;
                    case 41:
                        i13 += i12;
                        break;
                    case 45:
                        f3 += (i12 * i12);
                        break;
                    }
                }
            }
        }
        vMeth_check_sum += i8 + i9 + i10 + i11 + i12 + by1 + Float.floatToIntBits(f3) + i13 +
            FuzzerUtils.checkSum(lArr);
    }

    public static int iMeth(int i7, float f2) {

        int i14=7, i15=127, i16=-39317, i17=9, i18=10, i19=62403, i20=-3;
        boolean b=false;
        float fArr[]=new float[N];

        FuzzerUtils.init(fArr, -2.305F);

        vMeth();
        f2 *= i7;
        for (i14 = 15; i14 < 302; ++i14) {
            Test_2267.dFld += -118.483F;
            for (i16 = i14; 6 > i16; i16++) {
                for (i18 = 1; i18 < 1; ++i18) {
                    fArr[i14 - 1] = i19;
                    i15 = 1;
                    i7 += (i18 * i18);
                }
                i20 = 1;
                do {
                    int i21=-1;
                    if (i19 != 0) {
                    }
                    if (b) continue;
                    try {
                        i17 = (i21 % i16);
                        Test_2267.iArrFld[i14 - 1] = (i15 % 203);
                        i19 = (i7 % Test_2267.iArrFld1[i14]);
                    } catch (ArithmeticException a_e) {}
                    Test_2267.iArrFld1 = Test_2267.iArrFld;
                    i21 -= i20;
                } while (++i20 < 1);
            }
        }
        long meth_res = i7 + Float.floatToIntBits(f2) + i14 + i15 + i16 + i17 + i18 + i19 + i20 + (b ? 1 : 0) +
            Double.doubleToLongBits(FuzzerUtils.checkSum(fArr));
        iMeth_check_sum += meth_res;
        return (int)meth_res;
    }

    public static long lMeth(short s) {

        int i4=8, i5=92, i6=-97, i22=-53029, i23=-8, i24=-34726, iArr1[]=new int[N];
        float f=-1.475F, f1=0.135F;
        double d=2.29230;
        long lArr1[]=new long[N];

        FuzzerUtils.init(iArr1, 15009);
        FuzzerUtils.init(lArr1, 9042281341018201924L);

        for (i4 = 5; i4 < 353; i4++) {
            for (f = 1; 5 > f; f++) {
                Test_2267.sFld += (short)(f + Test_2267.instanceCount);
                try {
                    i6 = (i4 % 96);
                    i5 = (i5 % -1411628657);
                    i6 = (i4 / i5);
                } catch (ArithmeticException a_e) {}
                i6 -= (-((i5 + i5) + i5));
                Test_2267.sFld += (short)(((--i6) + (--i5)) + ((--iArr1[i4]) + d));
                vSmallMeth((int)(((Test_2267.instanceCount--) + 189L) + (--f1)), i5, ++i6);
                Test_2267.instanceCount = iMeth(i4, f);
                i6 = i5;
            }
            lArr1[i4] >>= i4;
            i5 = i6;
            i22 = 1;
            while (++i22 < 5) {
                for (i23 = 1; i23 < 1; i23++) {
                    Test_2267.dFld -= i6;
                    i5 += (((i23 * Test_2267.instanceCount) + i6) - i5);
                }
            }
        }
        long meth_res = s + i4 + i5 + Float.floatToIntBits(f) + i6 + Double.doubleToLongBits(d) +
            Float.floatToIntBits(f1) + i22 + i23 + i24 + FuzzerUtils.checkSum(iArr1) + FuzzerUtils.checkSum(lArr1);
        lMeth_check_sum += meth_res;
        return (long)meth_res;
    }

    public void mainTest(String[] strArr1) {

        int i3=59091, i25=-195, i26=-13087, i27=14108, i28=19, i29=-29741, i30=-229, i31=37515, i32=-24298, i33=28677,
            i34=4;
        byte by=-34;
        float f4=-2.681F;
        boolean b1=false;
        long lArr2[]=new long[N];

        FuzzerUtils.init(lArr2, 26823L);

        for (int smallinvoc=0; smallinvoc<405; smallinvoc++) vSmallMeth(i3++, (int)((++i3) - Test_2267.instanceCount),
            ((by * i3) + (i3 - i3)) * ((i3++) - (--i3)));
        i3 *= Math.max((int)((-45981 * lMeth(Test_2267.sFld)) + i3), 40208);
        Test_2267.iArrFld[(-5 >>> 1) % N] = i3;
        i3 = -25916;
        for (i25 = 5; i25 < 264; ++i25) {
            for (i27 = 1; 97 > i27; ++i27) {
                i26 -= i25;
                Test_2267.instanceCount = (long)2.501F;
                i28 += i26;
                lArr2[i25 - 1] *= i27;
                Test_2267.instanceCount += (i27 | i26);
                Test_2267.instanceCount >>= 12;
                lArr2[i27 + 1] -= i3;
            }
            i26 *= 150;
            Test_2267.instanceCount = 229;
        }
        for (i29 = 15; 279 > i29; ++i29) {
            for (i31 = 2; i31 < 95; i31++) {
                i26 = (int)Test_2267.dFld;
                Test_2267.instanceCount += (-241 + (i31 * i31));
                i26 *= 59418;
                i28 -= i26;
                lArr2[i31] -= (long)f4;
            }
            for (i33 = 95; i33 > i29; --i33) {
                f4 -= i32;
                i34 >>= (int)Test_2267.instanceCount;
                if (b1) continue;
            }
            i26 -= i3;
            f4 *= 2094021440L;
            Test_2267.sFld *= (short)38538;
            i32 *= i27;
        }

        FuzzerUtils.out.println("i3 by i25 = " + i3 + "," + by + "," + i25);
        FuzzerUtils.out.println("i26 i27 i28 = " + i26 + "," + i27 + "," + i28);
        FuzzerUtils.out.println("i29 i30 i31 = " + i29 + "," + i30 + "," + i31);
        FuzzerUtils.out.println("i32 f4 i33 = " + i32 + "," + Float.floatToIntBits(f4) + "," + i33);
        FuzzerUtils.out.println("i34 b1 lArr2 = " + i34 + "," + (b1 ? 1 : 0) + "," + FuzzerUtils.checkSum(lArr2));
        FuzzerUtils.out.println("Test_2267 = " + Test_2267.instanceCount);

        FuzzerUtils.out.println("Test_2267.instanceCount Test_2267.sFld Test_2267.dFld = " + Test_2267.instanceCount +
            "," + Test_2267.sFld + "," + Double.doubleToLongBits(Test_2267.dFld));
        FuzzerUtils.out.println("Test_2267.iArrFld Test_2267.iArrFld1 Test_2267 = " +
            FuzzerUtils.checkSum(Test_2267.iArrFld) + "," + FuzzerUtils.checkSum(Test_2267.iArrFld1) + "," +
            Test_2267.instanceCount);

        FuzzerUtils.out.println("vSmallMeth_check_sum: " + vSmallMeth_check_sum);
        FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
        FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        FuzzerUtils.out.println("lMeth_check_sum: " + lMeth_check_sum);
    }
    public static void main(String[] strArr) {

        try {
            Test_2267 _instance = new Test_2267();
            for (int i = 0; i < 10; i++ ) {
                _instance.mainTest(strArr);
            }
         } catch (Exception ex) {
            FuzzerUtils.out.println(ex.getClass().getCanonicalName());
         }
    }
}

