
public class DependencyBug {

  public static interface Interface {
    public void method();
  }
  
  public static class Impl1 implements Interface {
    public void method() {
      // Nothing to do here
    }
  }
  
  public static class BaseImpl2 {
    public void method() {
      System.out.print("#");
    }
  }

  public static class Impl2 extends BaseImpl2 implements Interface {
    // Interface method already implemented in base class.
  }

  
 
  public static void callMethod(Interface obj) {
    // method() is inlined as long as only class Impl1() is loaded.
    obj.method();
  }
  
  public static void main(String[] args) throws Exception {
    
    Interface obj = new Impl1();
    for (int i = 0; i < 2000; i++) {
      // Force compilation of the method callMethod()
      callMethod(obj);
    }
    
    System.out.println("**** Initiating class loading of Impl2 ****");
    
    obj = new Impl2();
    callMethod(obj);
  }
}