// java -Xbatch -XX:CompileCommand=compileonly,Test2::test -XX:CompileCommand=printcompilation,Test2::test Test2.java

import java.util.Arrays;

public class Test2 {
    static byte[] source = new byte[] {(byte)42};
    static byte[] result;

    static byte[] test() {
        // Should be zero-padded, but we seem to get non-zero values.
        return Arrays.copyOf(source, 4);
    }

    public static void main(String[] args) {
        byte[] gold = test();
        for (int i = 0; i < 10_000; i++) {
            test();
        }
        byte[] res = test();

        System.out.println("gold: " + Arrays.toString(gold));
        System.out.println("res:  " + Arrays.toString(res));
 
        if (Arrays.hashCode(gold) != Arrays.hashCode(res)) {
            throw new AssertionError("mismatch!");
        }
        System.out.println("ok");
    }
}
