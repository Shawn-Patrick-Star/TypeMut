public class TestUnsignedCompareIntoEqualityNotCanonical {
    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            test(0);
            test(1);
        }
    }

    private static int test(int x) {
        if (Integer.compareUnsigned(0, x) >= 0) {
            return 42;
        }
        return -42;
    }
}