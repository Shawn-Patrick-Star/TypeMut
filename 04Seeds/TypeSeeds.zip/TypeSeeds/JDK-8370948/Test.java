class Test {
    static int RANGE;

    public static void main(String[] args) {
        int[] a = new int[RANGE];
        for (int i = 0; i < 10_000; i++) {
            try {
                test(a, 0);
            } catch (ArrayIndexOutOfBoundsException e) {}
        }
    }

    static void test(int[] a, int invar) {
        a[new MyInteger(invar).v()] = 42;
        
        Object o;
        int delay = 32;
        for (int i = 0; i < delay; i++) {
            o = 1;
        }
        
        for (int j = 0; Integer.valueOf(j) < 256;) {
            j = 0;
        }
    }

    static class MyInteger {
        int v;

        MyInteger(int v) {
            this.v = v;
        }

        int v() {
            return Integer.valueOf(v);
        }
    }
}

