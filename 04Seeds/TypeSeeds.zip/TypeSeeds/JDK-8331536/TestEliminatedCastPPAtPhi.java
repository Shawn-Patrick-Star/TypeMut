public class TestEliminatedCastPPAtPhi {
    static TestEliminatedCastPPAtPhi saved;
    static TestEliminatedCastPPAtPhi saved_not_null;
    int f;
    public static int CHECKSUM = 0;

    public TestEliminatedCastPPAtPhi() {
    }

    public static void main(String[] var0) {
        int[] var4 = new int[100];
        TestEliminatedCastPPAtPhi var1 = new TestEliminatedCastPPAtPhi();

        for(int var2 = 0; var2 < 20000; ++var2) {
            boolean var5;
            if (var2 % 2 == 0) {
                Throwable[][] var3 = new Throwable[9][8];
                var5 = true;
            } else {
                var5 = false;
            }

            test(var1, var4, var5);
        }

        test((TestEliminatedCastPPAtPhi)null, var4, true);
    }

    static int test(TestEliminatedCastPPAtPhi var0, int[] var1, boolean var2) {
        int var10000 = var1[0];
        int var3 = var1[20];
        int var4 = var10000 + var3;
        saved = var0;
        if (var0 == null) {
            return var4;
        } else {
            saved_not_null = var0;

            int var5;
            for(var5 = 0; var5 < 10; ++var5) {
            }

            int var6 = var1[var5];
            var5 = var4 + var6;
            TestEliminatedCastPPAtPhi var7;
            if (var2) {
                var7 = saved;
            } else {
                var7 = saved_not_null;
            }

            var6 = var7.f;
            return var5 + var6;
        }
    }
}