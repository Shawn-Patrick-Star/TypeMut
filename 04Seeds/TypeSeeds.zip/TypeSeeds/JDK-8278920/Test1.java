class Test1 {
    static final int RANGE = 1024;
    static final int ITER  = 10_000;

    static void init(long[] data) {
        for (int i = 0; i < RANGE; i++) {
            data[i] = i + 1;
        }
    }

    static long test(long[] a, long[] b) {
        long acc = 0;
        for (int i = 0; i < RANGE; i++) {
            acc += Long.bitCount(a[i]);
        }
        return acc;
    }

    public static void main(String[] args) {
        long[] a = new long[RANGE];
        long[] b = new long[RANGE];
        init(a);
        init(b);
        for (int i = 0; i < ITER; i++) {
            test(a, b);
        }
    }
}
