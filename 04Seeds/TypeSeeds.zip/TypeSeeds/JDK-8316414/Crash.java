// Run with a 32-bits x86 debug build:
// $ java -Xcomp -XX:CompileOnly=Crash::createAndClone Crash.java

public class Crash {

    // Maximum length of a byte array on a 32-bits platform using default object
    // alignment (8 bytes).
    static final int MAX_BYTE_ARRAY_LENGTH = 0x7ffffffc;

    public static byte[] createAndClone() {
        byte[] array = new byte[MAX_BYTE_ARRAY_LENGTH];
        return array.clone();
    }

    public static void main(String[] a) {
        createAndClone();
    }
}
