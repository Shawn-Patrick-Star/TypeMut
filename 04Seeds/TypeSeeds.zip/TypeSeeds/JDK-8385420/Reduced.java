// java -Xbatch -XX:CompileOnly=Reduced::test -XX:+UnlockDiagnosticVMOptions -XX:+StressGCM -XX:+StressLCM Reduced.java
//
// Note: intermittent because of stress flags!
//
class Reduced {
    static int test(String a, boolean flag) {
        StringBuilder sb = new StringBuilder();
        if (a == null) {
            sb.append("");
        } else {
            sb.append(flag ? a : "");
        }
        return sb.length();
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10_000; i++) {
            String a = (i & 1) == 0 ? "" : null;
            boolean flag = (i & 2) == 0;
            test(a, flag);
        }
    }
}
