// Run with
// /home/rocastan/git/views/JDK-8349930-memory-liveness-invariants/open/build/linux-x64-debug/jdk/bin/java -ea -Xbatch -XX:-TieredCompilation -XX:CompileOnly=Test::test -XX:PrintIdealGraphLevel=4 -XX:LoopUnrollLimit=0 -XX:+OptimizeFill Test.java
// compare to
// /home/rocastan/git/views/JDK-8349930-memory-liveness-invariants/open/build/linux-x64-debug/jdk/bin/java -ea -Xint Test.java

public class Test {

    static int N = 10;
    static short M = 4;
    static short VAL = 42;

    static short test(int pos, int samePos) {
        // This pre-condition is necessary to reproduce the miscompilation, but
        // should not be exploited by C2 for optimization.
        assert pos == samePos;
        short total = 0;
        short[] array = new short[N];
        array[pos] = VAL;
        for (int i = 0; i < M; i++) {
            // This load is wrongly scheduled after the loop below, which is
            // transformed into a call to arrayof_jshort_fill and clears the
            // entire array. As a consequence, the function returns 0 instead of
            // the expected VAL.
            // The load is wrongly allowed to be moved beyond the loop
            // (arrayof_jshort_fill call) because their anti-dependence is
            // missed. This is because the call operates on a different memory
            // slice (char[] instead of the expected short[]).
            total += array[samePos];
            for (int t = 0; t < array.length; t++) {
                array[t] = 0;
            }
        }
        return total;
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10_000; i++) {
            int result = test(0, 0);
            assert result == VAL;
        }
    }
}
