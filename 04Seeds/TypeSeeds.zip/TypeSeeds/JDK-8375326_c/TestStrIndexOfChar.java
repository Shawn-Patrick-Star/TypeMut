// Run with:
//   java -Xbatch -XX:CompileCommand=compileonly,TestStrIndexOfChar::test TestStrIndexOfChar.java
//
public class TestStrIndexOfChar {
    public static int test() {
        int x = 0;
        String s = "abcdefghijklmnop";
        byte[] a = new byte[32];

        for (int i = 0; i < 32; i++) {
            // StrIndexOfChar gets ctrl after loop, but memory input from middle of the loop body.
            x = s.indexOf(75);
            a[i] = (byte)(i * 5);
        }
        // StrIndexOfChar is moved here, but memory input is before the last store in the loop.
        return x;
    }

    public static void main(String[] argv) {
        for (int i = 0; i < 10_000; i++) {
            test();
        }
    }
}
