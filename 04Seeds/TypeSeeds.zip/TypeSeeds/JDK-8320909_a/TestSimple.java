class TestSimple {
    static long res = 0;

    static void test() {
        int i, i1 = 0, k, l = -4;
        for (i = 0; i < 100; i++) {
            for (int j = 0; j < 10; j++) {
                for (k = 1; k < 2; k++) {
                    i1 = l;
                    l += k * k;
                    if (l != 0) {
                        res = i + i1 + Float.floatToIntBits(2);
                    }
                }
            }
        }
        res = i + i1;
    }

    public static void main(String[] args) {
        test();
    }
}
