class Reduced {

    public static int sum(short[] a) {
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
            sum += a[i];
        }
        return sum;
    }

    static int foo() {
        short d[] = new short[64];
        for (int i = 0; i < d.length; i++) {
            d[i] = (short)Math.max(Integer.reverseBytes(50), i);
        }
        return sum(d);
    }

    public static void main(String[] args) throws Exception {
        for (int i = 0; i < 10; i++) {
            int f = foo();
            if (f != 0) {
                throw new Exception("unexpected value for f: " + f);
            }
        }
    }
}
