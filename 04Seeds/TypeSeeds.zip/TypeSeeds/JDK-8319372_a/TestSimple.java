    
public class TestSimple {
    static class X {
        static void m(int[] a) {
            
        }
    }

    static int array[] = new int[10];

    static void test(int val) {
        for (int i = 1; i < 10; ++i) {
            for (int j = i; j < 10; ++j) {
                if (i == 0 && j != 0) {
                    X.m(array);
                }
                array[j - 1] = val;
            }
        }
    }

    public static void main(String[] arg) {
        test(42);
    }
}

