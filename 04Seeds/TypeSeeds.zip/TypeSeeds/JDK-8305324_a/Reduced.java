public class Reduced {

    public static void main(String[] strArr) {
        byte[] arr = new byte[0];
        for (int i = 0; i < 10; i++) {
            arr = test();
        }
        for (int i = 0; i < arr.length; i++) {
           System.out.println("arr[" + i + "] = " + arr[i]);
        }
    }

    static byte[] test() {
        int i, i18, i20;
        byte byArr[] = new byte[300];
        for (i = 5; i < 293; i++) {
            byArr[i] = (byte)Integer.reverseBytes(i);
        }
        return byArr;
    }
}
