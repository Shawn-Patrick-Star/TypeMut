public class TestReverseBytesLargeConstantInput {
    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            test1();
            inlined1((short)0, 0);
        }
    }

    static short field;

    private static int test1() {
        short v = field;
        int res = 0;
        for (int i = 0; i < 20_000; i++) {
            res += inlined1(v, Integer.MIN_VALUE);
        }
        return res;
    }

    private static int inlined1(short v1, int v2) {
        if (v1 == v2) {
            return Short.reverseBytes(v1);
        }
        return 0;
    }
}
