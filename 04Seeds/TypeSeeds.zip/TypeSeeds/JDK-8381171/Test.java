// javac --enable-preview --source 27 --add-exports java.base/jdk.internal.value=ALL-UNNAMED --add-exports java.base/jdk.internal.vm.annotation=ALL-UNNAMED Test.java && java --enable-preview --add-exports java.base/jdk.internal.value=ALL-UNNAMED --add-exports java.base/jdk.internal.vm.annotation=ALL-UNNAMED -XX:CompileCommand=printcompilation,*::* -Xcomp -XX:CompileOnly=Test*::test* Test
public class Test {
    static B b = new B();
    static Object[] oArr = new B[100];
    static int iFld;

    public static void main(String[] args) {
        for (int i = 0; i < 10000; i++) {
            test();
        }
    }

    static Object test() {
        Object[] o2 = oArr;
        Object o = b.getClass().cast(o2[2]);
        iFld = o2.length;

        for (int i = 0; i < 100; i++) {} // Will assert earlier when building the loop tree. Otherwise, we will only fail in matching without this line.
        return o2;
    }
}


class B {
}

