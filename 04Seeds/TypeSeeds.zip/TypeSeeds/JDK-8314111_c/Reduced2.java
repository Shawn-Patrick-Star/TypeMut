public class Reduced2 {
    public static void main(String[] strArr) {
        test(false);
    }

    static void test(boolean flag) {
        int iArr[] = new int[1000];
        boolean bArr[] = new boolean[1000];
        int x = 0;
        int i = 1;
        while (++i < 5) {
            try {
                x = iArr[i - 1];
                x = 2 / i;
            } catch (ArithmeticException a_e) {
            }
            if (flag) {
                x++;
                bArr[i - 1] = false;
                iArr[i] = 0;
            }
        }
    }
}
