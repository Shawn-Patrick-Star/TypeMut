public class Test {
    public static void main(String[] args) {
	byte[] a = new byte[10_000];
	byte[] b = new byte[10_000];
	for (int i = 0; i < 10_000; i++) {
            test(a, b);
	}
    }

    public static void test(byte[] a, byte[] b) {
	for (int i = 0; i < 10_000; i++) {
	    b[i] = (byte)Short.reverseBytes(a[i]);
	}
    }
}
