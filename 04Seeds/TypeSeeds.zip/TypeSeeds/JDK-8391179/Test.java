// java -Xbatch -XX:CompileCommand=compileonly,Test::test -XX:+TieredCompilation -XX:RepeatCompilation=100 -XX:+StressLoopPeeling Test.java
public class Test {
    public static void main(String[] args) {
        test(123);
    }
    
    static String test(long l) {
        String s = "";
        for (int i = 0; i < 50_000; i++) {
            s = Long.toString(l);
        }
        return s;
    }
}

