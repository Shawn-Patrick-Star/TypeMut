class Test {
  int N = 256;
  volatile long instanceCount;
  short sFld;
  int iFld;
  volatile long lArrFld[] = new long[N];

  void vMeth(int i, int i1) {
    int i21, i24, i25 = 46;
    float f1;
    byte by2 = 97;
    sFld = (short) 1457395900305333787L;
    for (i21 = 11; i21 < 192; i21++) {
      for (f1 = 3; 1 < f1; f1 -= 3) {
        i1 = sFld;
        for (i24 = 1; 3 > i24; ++i24) {
          lArrFld = lArrFld;
          sFld = (short) i25;
          lArrFld[(int) f1] *= by2;
        }
      }
      sFld *= i1;
      i1 *= instanceCount;
    }
  }

  void mainTest(String[] strArr1) {
    int i28, i31 = 3, i36, i39 = 50982, iArr3[] = new int[N];
    vMeth(iFld, 5);
    for (i28 = 2; 138 > i28; i28++) {
      i36 = 1;
      while (++i36 < 37)
        switch (69) {
          case 69:
            i39 = sFld;
          case 70:
            iArr3[i28] -= i39;
          case 76:
            i31 = iArr3[i36];
        }
    }
    System.out.println(i31);
  }

  public static void main(String[] strArr) {
    Test _instance = new Test();
    for (int i = 0; i < 10; i++) _instance.mainTest(strArr);
  }
}