public class Test {
    
    public static long instanceCount = 2772208695340607833L;
    public static int iFld = -8;

    public void mainTest(java.lang.String[] strArr1) {
        byte loclaByte = (byte)73;
        int localInt1 = 63811;
        int localInt2 = 606;
        int localInt3 = 606;
        int localInt4 = 4;
        int localInt5 = -4918;
        int localInt6 = -10;
        Object O21 = new Object();
        switch (((((int) (Test.iFld + Test.instanceCount)) >>> 1) % 1) + 39) {
            case 39 :
                {
                    localInt1 = 1;
                    do {
                        for (localInt4 = ((int) (98)); localInt4 > 1; localInt4--) {
                            localInt2 = localInt1 + localInt4;
                            synchronized(O21) {
                                switch ((localInt1 % 10) + 68) {
                                    case 75 :
                                        {
                                            for (localInt3 = 0; localInt3 < (((localInt2) + ((int)(((byte) ((((byte) ((loclaByte) + ((byte)36)))) + (((byte) (((byte)78) + (loclaByte)))))))))); localInt3++) {
                                                if ((668) > 0) {
                                                    localInt2 = 765;                                             
                                                } else {                                                    
                                                    localInt2 = 765; 
                                            
                                                }
                                            }                                            
                                        }
                                    case 76 :
                                        {
                                            localInt5 = localInt6;
                                        }
                                    case 77 :
                                }
                            }
                        }
                    } while ((++localInt1) < 125 );
                }
        }
    }
    
    public static void main(java.lang.String[] args) {
        Test _instance = new Test();
        for (int i = 0; i < 10; i++) {
            try {
                _instance.mainTest(args);
            } catch (java.lang.Exception ex) {
                System.out.println(ex.getClass().getCanonicalName());
            }
        }
        System.out.println("PASS");
    }

}