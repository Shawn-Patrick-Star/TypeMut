// java -Xcomp -XX:CompileCommand=compileonly,Test::test Test.java
//
// JDK28:
//
// #  Internal Error (/src/hotspot/share/opto/type.hpp:2236), pid=1923351, tid=1923364
// #  assert(_base == Int) failed: Not an Int
// #
// # JRE version: Java(TM) SE Runtime Environment (28.0) (fastdebug build 28-internal-empeter.open)
// # Java VM: Java HotSpot(TM) 64-Bit Server VM (fastdebug 28-internal-empeter.open, compiled mode, tiered, compressed oops, compact obj headers, g1 gc, linux-amd64)
// # Problematic frame:
// # V  [libjvm.so+0x14a4fb6]  CountedLoopConverter::filtered_type_from_dominators(Node*, Node*) [clone .part.0]+0x346
//
//
// V  [libjvm.so+0x14a4fb6]  CountedLoopConverter::filtered_type_from_dominators(Node*, Node*) [clone .part.0]+0x346  (type.hpp:2236)
// V  [libjvm.so+0x14adfd9]  CountedLoopConverter::filtered_type(Node*, Node*)+0x2c9  (loopnode.cpp:3882)
// V  [libjvm.so+0x14ae1cf]  CountedLoopConverter::has_truncation_wrap(CountedLoopConverter::TruncatedIncrement const&, Node*, long)+0x8f  (loopnode.hpp:2179)
// V  [libjvm.so+0x14b3e25]  CountedLoopConverter::is_counted_loop()+0x95  (loopnode.cpp:2112)
// V
//
// JDK26:
//
// #  Internal Error (/src/hotspot/share/opto/type.hpp:2201), pid=1923858, tid=1923877
// #  assert(_base == Int) failed: Not an Int
// #
// # JRE version: Java(TM) SE Runtime Environment (26.0.2+8) (fastdebug build 26.0.2+8-52)
// # Java VM: Java HotSpot(TM) 64-Bit Server VM (fastdebug 26.0.2+8-52, compiled mode, sharing, tiered, compressed oops, compressed class ptrs, g1 gc, linux-amd64)
// # Problematic frame:
// # V  [libjvm.so+0x1593a7e]  Type::is_int() const [clone .part.0] [clone .isra.0]+0x2e
//
// V  [libjvm.so+0x1593a7e]  Type::is_int() const [clone .part.0] [clone .isra.0]+0x2e  (type.hpp:2201)
// V  [libjvm.so+0x159e58b]  PhaseIdealLoop::filtered_type_from_dominators(Node*, Node*)+0x2bb
// V  [libjvm.so+0x159e7e9]  PhaseIdealLoop::filtered_type(Node*, Node*)+0x1b9
// V  [libjvm.so+0x15b7a82]  PhaseIdealLoop::is_counted_loop(Node*, IdealLoopTree*&, BasicType)+0x522
//
//
// JDK25: pass

public class Test {
    public static void main(String[] args) {
        for (int i = 0; i < 10_000; i++) {
            test(1);
        }
    }

    static int test(int init) {
        if (init < 1) {
            return -1;
        }
        // if implies: init in [1..max_int]

        int i = init;
        while (i < 0) {
            // while implies: init in [min_int .. 0]
            // That contradicts the "if" above: empty intersection
            //
            // See CountedLoopConverter::filtered_type_from_dominators:
            //   rtn_t = rtn_t->join(if_t)->is_int()
            // -> top type in join, fails "is_int".
            i = (short)(i + 1);
        }
        return 0;
    }
}
