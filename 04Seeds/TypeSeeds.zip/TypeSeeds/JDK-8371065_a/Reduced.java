public class Reduced {
    public static void main(String[] strArr) {
        for (int i = 0; i < 10; i++) {
            test();
        }
    }

    static void test() {
        int iArr[] = new int[400];
        int i = 1;
        int x = 34;
        do {
            for (int i2 = 3; 201 > i2; ++i2) {
                x +=Math.min(i2, iArr[i2 - 1]);
            }
        } while (++i < 50);
    }
}

