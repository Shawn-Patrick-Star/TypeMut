// java -Xbatch -XX:CompileCommand=compileonly,Reduced::test Reduced.java
class Reduced {
    static Object test(String a, String b) {
        String s1 = new String(b);
        String s2 = new StringBuffer(s1).append(s1).toString();
        return new StringBuffer(s2).append(a).append(s2 == null ? "" : s2).toString();
    }

    public static void main(String[] args) {
        for (int t = 0; t < 10_000; t++) {
            try {
                if (t % 2 != 0) {
                    test(null, "B");
                } else {
                    test("A", null);
                }
            } catch (NullPointerException e) {
                // expected
            }
        }
    }
}
