class Test {

    public static void main(String[] strArr) {
        int result = 0;
        for (int i = 0; i < 100; i++) {
            result = test();
        }
        System.out.println("result: " + result);
    }

    static int test() {
        int x = 1030, y = 1031;
        for (int i = 7; i < 209; ++i) {
            x += i * i;
            long j = 1;
            while (++j < 8) {
                y += i;
            }
            y <<= x;
            y &= 55617;
        }
        return y;
    }
}
