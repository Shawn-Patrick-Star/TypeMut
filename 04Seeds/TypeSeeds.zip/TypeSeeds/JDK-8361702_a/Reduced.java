public class Reduced {
    static int iFld;
    static long lArr[] = new long[400];

    public static void main(String[] strArr) {
        for (int i = 0; i < 1000; i++) {
            test();
        }
    }

    static void test() {
        int iArr[] = new int[400];
        for (int i = 8; i < 128; i++) {
            for (int j = 209; j > 9; j--) {
                switch ((j % 5) + 58) {
                    case 58:
                        iArr[i] = 194;
                        break;
                    case 59:
                        iFld = 3;
                    case 62:
                    default:
                        iArr[1] = i;
                }
                for (int k = 2; k > 1; --k) {
                    lArr[k] -= iFld;
                }
            }
        }
    }

}

