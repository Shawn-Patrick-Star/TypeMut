import java.util.stream.IntStream;

class Test {
    static final int RANGE = 1024;
    static final int ITER  = 10_000;

    static void init(int[] dataI, float[] dataF) {
        for (int i = 0; i < RANGE; i++) {
            dataI[i] = i + 1;
            dataF[i] = i + 0.1f;
        }
    }

    static void test(int[] dataI1, int[] dataI2, float[] dataF1, float[] dataF2) {
        for (int i = 0; i < RANGE/2; i+=2) {
            dataF1[i+0] = dataI1[i+0] + 0.33f;
            dataI2[i+1] = (int)(11.0f * dataF2[i+1]);

            dataI2[i+0] = (int)(11.0f * dataF2[i+0]);
            dataF1[i+1] = dataI1[i+1] + 0.33f;
        }
    }

    static void verify(String name, int[] data, int[] gold) {
        for (int i = 0; i < RANGE; i++) {
            if (data[i] != gold[i]) {
                throw new RuntimeException(" Invalid " + name + " result: data[" + i + "]: " + data[i] + " != " + gold[i]);
            }
        }
    }

    static void verify(String name, float[] data, float[] gold) {
        for (int i = 0; i < RANGE; i++) {
            if (data[i] != gold[i]) {
                throw new RuntimeException(" Invalid " + name + " result: data[" + i + "]: " + data[i] + " != " + gold[i]);
            }
        }
    }

    public static void main(String[] args) {
        int[] dataI = new int[RANGE];
        int[] goldI = new int[RANGE];
        float[] dataF = new float[RANGE];
        float[] goldF = new float[RANGE];
        init(goldI, goldF);
        test(goldI, goldI, goldF, goldF);
        for (int i = 0; i < ITER; i++) {
            init(dataI, dataF);
            test(dataI, dataI, dataF, dataF);
        }
        verify("test", dataI, goldI);
        verify("test", dataF, goldF);
    }
}

