public class Test {
    
    static class Cls {
        public static byte gbByteVar = (byte)75;
    }

    public static boolean bFld = false;
    
    public void mainTest(String[] strArr1) {
        int lvInt1 = -138;
        int lvInt2 = -138;
        float f3 = 92.589F;
        String lvStr = "xmrjueawszzseso";
        byte[] lvByte = new byte[32];

        for (int TmpVar = 0; TmpVar < 32; TmpVar++) {
            lvInt2 = lvStr.indexOf(((int)(Cls.gbByteVar)));
            lvByte[TmpVar] = ((byte) ((((byte) (TmpVar)) * 5) + 12));
        }
        if (Test.bFld) {
            for (int TmpVar = 130; TmpVar > f3; TmpVar--) {
                lvInt2 = Integer.numberOfTrailingZeros(lvInt1 - lvInt2);
            }
        }
        
        System.out.println("f3 = " + Float.floatToIntBits(f3));
        System.out.println("Test.bFld = " + (Test.bFld ? 1 : 0));
    }

    public static void main(String[] strArr) {
        Test _instance = new Test();
        for (int i = 0; i < 5; i++) {
            _instance.mainTest(strArr);
        }
    }
}