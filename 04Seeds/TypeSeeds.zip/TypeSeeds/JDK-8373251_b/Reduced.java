public class Reduced {
    static long lFld;
    static boolean flag;

    public static void main(String[] strArr) {
        for (int i = 0; i < 1000; i++) {
            test();
        }
    }
    
    static void test() {
        int x = 67;
        for (int i = 0; i < 20; i++) {
            if (flag) {
                x = 0;
            }
            lFld <<= x;
            lFld >>>= x;
        }
    }
}

