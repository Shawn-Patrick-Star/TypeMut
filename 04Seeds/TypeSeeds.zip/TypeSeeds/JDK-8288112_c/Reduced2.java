class Reduced2 {
    static final int N = 400;

    static void test() {
        float f = 1.303F;
        int iArr[] = new int[N];
        for (int i1 : iArr) {
            f += Integer.reverseBytes(i1) - i1;
        }
    }

    public static void main(String[] strArr) {
        for (int i = 0; i < 10; i++) {
            test();
        }
  }
}
