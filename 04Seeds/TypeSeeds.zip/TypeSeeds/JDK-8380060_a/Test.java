public class Test {
    static final byte[] bytes = new byte[] {
            108, 77, 120, 120, 100, 77, 105, 113,
            83, 97, 71, 108, 116, 107, 90, 71,
            72, 107, 73, 85, 54, 65, 61, 61
    };

    static final String golden = "lMxxdMiqSaGltkZGHkIU6A=";

    public static void main(String[] args) {
        for (int i = 0; i < 10000; i++) {
            String result = test();
            if (!result.equals(golden)) {
                throw new RuntimeException("Expected: " + golden + ", found: " + result);
            }
        }
    }

    static String test() {
        String s = new String(bytes, 0, 0, 24);
        return s.substring(0, 23);
    }

}

