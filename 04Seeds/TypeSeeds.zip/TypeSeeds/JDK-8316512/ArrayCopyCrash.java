// Run with:
// $ java -Xcomp -XX:-TieredCompilation -XX:CompileOnly=ArrayCopyCrash::createAndClone -XX:FastAllocateSizeLimit=2147483647 ArrayCopyCrash.java

public class ArrayCopyCrash {

    // Maximum length of a byte array on a 32-bits platform using default object
    // alignment (8 bytes).
    static final int MAX_BYTE_ARRAY_LENGTH = 0x7ffffffc;

    public static byte[] createAndClone(int length) {
        byte[] array = new byte[length];
        return array.clone();
    }

    public static void main(String[] a) {
        createAndClone(MAX_BYTE_ARRAY_LENGTH);
    }
}
