// Run with:
//   java -Xbatch -XX:CompileCommand=compileonly,TestStrIndexOf::test TestStrIndexOf.java
//
public class TestStrIndexOf {
    static String other = "xyz";

    public static int test() {
        int x = 0;
        String s = "abcdefghijklmnop";
        byte[] a = new byte[32];

        for (int i = 0; i < 32; i++) {
            // StrIndexOf gets ctrl after loop, but memory input from middle of the loop body.
            x = s.indexOf(other);
            a[i] = (byte)(i * 5);
        }
        // StrIndexOf is moved here, but memory input is before the last store in the loop.
        return x;
    }

    public static void main(String[] argv) {
        for (int i = 0; i < 10_000; i++) {
            test();
        }
    }
}
