public class TestArrayAccessAboveRCAfterRCCastIIEliminated {
    private static int field;
    private static volatile int volatileField;

    public static void main(String[] args) {
        int[] array = new int[100];
        for (int i = 0; i < 20_000; i++) {
            test(9, 10, 1, true);
            test(9, 10, 1, false);
        }
        try {
            test(-1, 10, 1, true);
        } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            
        }
    }

    private static void test(int i, int j, int flag, boolean flag2) {
        i = Math.min(i, 9);
        int[] array = new int[10];
        notInlined(array);
        if (flag == 0) {
        }
        if (flag2) {
            float[] newArray = new float[j];
            newArray[i] = 42;
            float[] otherArray = new float[i];
            if (flag == 0) {
            }
            field = array[otherArray.length];
        } else {
            float[] newArray = new float[j];
            newArray[i] = 42;
            float[] otherArray = new float[i];
            if (flag == 0) {
            }
            field = array[otherArray.length];
        }
        for (int k = 0; k < 10; k++) {

        }
    }

    private static void notInlined(int[] array) {

    }
}
