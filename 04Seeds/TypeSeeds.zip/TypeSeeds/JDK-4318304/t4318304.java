
class t4318304 {
  static void testExc8(int x) {
    for (int i = 0; i < 10000; i++) {
      try {
        int a = 2 / x;
      } catch (java.lang.ArithmeticException exc) {}
//        if (i % 100 == 0) {
//  	System.out.println("i=" + i);
//        }
    }
  }
 
  public static void main(String[] args) {
    testExc8(0);
  }
}