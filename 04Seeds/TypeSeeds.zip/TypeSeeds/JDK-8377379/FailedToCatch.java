import java.util.Arrays;
public class FailedToCatch {
    static int counter = 0;

    public static void main(String[] args) {
        Object[] array = new Object[((byte) (10))];
        for (int i = 0; i < 50000; i++) {
            test(array);
        }
        if (counter != 50000) {
            throw new RuntimeException("Test failed");
        }
    }

    static void test(Object[] array) {
        try {
            Arrays.copyOfRange(array, 15, 20, Object[].class);
        } catch (ArrayIndexOutOfBoundsException e) {
            counter++;
        }
    }
}