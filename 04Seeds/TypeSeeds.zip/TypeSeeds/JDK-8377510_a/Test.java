public class Test {
    static final int RANGE = 1024 * 16;
    static final int ITER = (RANGE / 2) - 1;
    static short[] sArr1 = new short[RANGE];
    static short[] sArr2 = new short[RANGE];
    static final int[] GOLDEN_K;

    static {
        for (int i = 0; i < RANGE; i++) {
            sArr1[i] = ((short) (i));
            sArr2[i] = ((short) (i));
        }
        GOLDEN_K = test(generate());
    }

    public static void main(String[] args) {
        for (int i = 0; i < ITER; i++) {
            compare(test(generate()), GOLDEN_K, "test");
        }
    }

    public static int[] generate() {
        int[] a = new int[ITER];
        for (int i = 0; i < ITER; i++) {
            a[i] = 1;
        }
        return a;
    }

    public static void compare(int[] out, int[] golden, String name) {
        long err = 0;
        for (int i = 0; i < ITER; i++) {
            if (out[i] != golden[i]) {
                err++;
            }
        }
        if (err > 0) {
            throw new RuntimeException("errors: " + err);
        }
    }

    public static int[] test(int[] out) {
        for (int i = 0; i < (ITER - 2); i += 4) {
            out[i + 0] = (sArr1[(2 * i) + 0] * sArr2[(2 * i) + 1]) + (sArr1[(2 * i) + 1] * sArr2[(2 * i) + 0]);
            out[i + 1] = (sArr1[(2 * i) + 2] * sArr2[(2 * i) + 2]) + (sArr1[(2 * i) + 3] * sArr2[(2 * i) + 3]);
        }
        return out;
    }
}