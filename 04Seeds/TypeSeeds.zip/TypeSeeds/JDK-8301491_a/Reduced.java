public class Reduced {
    static byte byArr[] = new byte[500];

    public static void main(String[] args) {
        for (int j = 0; j < byArr.length; j++) {
            byArr[j] = (byte)j;
        }
        test();
    }

    static void test() {
        String s = new String(byArr);
        int x = s.indexOf(-2147483641);
        System.out.println("int = " + x);
    }
}

