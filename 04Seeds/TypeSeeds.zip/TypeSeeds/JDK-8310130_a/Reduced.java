public class Reduced {
    static boolean flag;
    static long lArrFld[];
    static int iArrFld[];

    public static void main(String[] strArr) {
        test();
    }

    static void test() {
        if (flag) {
            // Dead path.
            while (true) {
                for (int i10 : iArrFld) {
                    iArrFld[3] = 101;
                    lArrFld[5] |= i10;
                }
            }
        }
    }
}

