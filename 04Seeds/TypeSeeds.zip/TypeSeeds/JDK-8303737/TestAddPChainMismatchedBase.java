public class TestAddPChainMismatchedBase {
    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            test();
            testHelper(null, true);
            testHelper2(1000);
        }
    }

    private static void test() {
        int l;
        for (l = 0; l < 5; l++) {
            for (int i = 0; i < 2; i++) {
            }
        }
        testHelper2(l);
    }

    private static void testHelper2(int l) {
        int[] array = new int[1000];
        if (l == 5) {
            l = 4;
        } else {
            l = 1000;
        }
        for (int k = 0; k < 2; k++) {
            int v = 0;
            int i = 0;
            for (; ; ) {
                synchronized (new Object()) {
                }
                array = testHelper(array, false);
                v += array[i];
                int j = i;
                i++;
                if (i >= l) {
                    break;
                }
                array[j] = v;
            }
        }
    }

    private static int[] testHelper(int[] array, boolean flag) {
        if (flag) {
            return new int[1000];
        }
        return array;
    }
}
