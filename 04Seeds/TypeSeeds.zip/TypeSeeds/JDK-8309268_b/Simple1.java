public class Simple1 {
    static int N;

    public static void main(String[] strArr) {
         for (int i = 0; i < 10_100; i++) {
             test(500);
         }
    }

    static void test(int limit) {
        boolean a[] = new boolean[1000];
        for (int i = 0; i < limit; i++) {
            a[i] = 80.1f > i;
        }
    }
}
