public class TestEA {
    private static class A {
        public int i;
        public A(int ii) { i = ii; }
    }

    private static class B {
        public A a;
    }

    private static int test() {
        B b = new B();
        b.a = new A(1);
        int j = b.a.i;
        b.a = new A(2);
        return b.a.i + j;
    }

    public static void main(String[] args) {
        int sum = 0;
        for (int i = 0; i < 20_000; i++) {
            sum += test();
        }
        System.out.println("sum: " + sum);
    }
}
