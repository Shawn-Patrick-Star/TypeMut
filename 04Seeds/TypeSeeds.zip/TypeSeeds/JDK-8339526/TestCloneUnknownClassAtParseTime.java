public class TestCloneUnknownClassAtParseTime {
    private static volatile int volatileField;

    public static void main(String[] args) throws CloneNotSupportedException {
        A a = new A();
        for (int i = 0; i < 20_000; i++) {
            B b = (B)test1(-1);
            if (b.field1 != 42 || b.field2 != 42|| b.field3 != 42) {
                throw new RuntimeException("Clone wrongly initialized");
            }
            inlined1(42);
            field = a;
            inlined2();
        }
    }

    static A field;

    private static A test1(int i) throws CloneNotSupportedException {
        int[] nonEscapingArray = new int[1];
        field = new B(42, 42, 42);

        if (i > 0) {
            throw new RuntimeException("never taken");
        }
        inlined1(i);

        nonEscapingArray[0] = 42;
        return inlined2();
    }

    private static A inlined2() throws CloneNotSupportedException {
        A a = field;
        return (A)a.clone();
    }

    private static void inlined1(int i) {
        if (i > 0) {
            volatileField = 42;
        }
    }

    private static class A implements Cloneable {
        public Object clone() throws CloneNotSupportedException {
            return super.clone();
        }
    }

    private static class B extends A {
        int field1;
        int field2;
        int field3;

        B(int v1, int v2, int v3) {
            field1 = v1;
            field2 = v2;
            field3 = v3;
        }
    }
}
