public class test {
        public static void main(String[] args) throws Exception {
                int b = Integer.MAX_VALUE;
                for(int i=0;i<24800;i++){
                        test(b);
                }
        }

        public static void test(int b) {
                int a = 0;
                int c = 17;
                do{
                        a++;
                        c = c>>1;
                        if(a>b){
                                System.out.println("======= a="+a+",b="+b+",a>b="+(a>b));
                                break;
                        }
                }while(c>1);
        }

}