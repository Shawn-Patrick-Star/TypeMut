
public class Test {
    static final byte
        REF_NONE                    = 0,  // null value
        REF_getField                = 1,
        REF_getStatic               = 2,
        REF_putField                = 3,
        REF_putStatic               = 4,
        REF_invokeVirtual           = 5,
        REF_invokeStatic            = 6,
        REF_invokeSpecial           = 7,
        REF_newInvokeSpecial        = 8,
        REF_invokeInterface         = 9,
        REF_LIMIT                  = 10;

    public static void main(String[] args) {
        for (int i = 0; i < 10000; i++) {
            try {
                test((byte)(i % 11));
            } catch (Throwable f) {}
        }
    }

    static boolean test(byte refKind) {
        assert(refKindIsValid(refKind));
        return (refKind <= REF_getStatic);
    }

    static boolean refKindIsValid(int refKind) {
        return (refKind > REF_NONE && refKind < REF_LIMIT);
    }
}