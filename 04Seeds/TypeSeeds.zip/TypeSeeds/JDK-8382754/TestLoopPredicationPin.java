public class TestLoopPredicationPin {
    static int iFld;
    static volatile double dFld;
    static int iArr[] = new int[400];
    static boolean flag, flag2;

    public static void main(String[] a) {
        TestLoopPredicationPin test = new TestLoopPredicationPin();
        test.test();
        test.testFuzzer();
    }

    // java -XX:CompileCommand=compileonly,*TestLoopPredicationPin::test* -Xcomp -XX:LoopMaxUnroll=0 -XX:-RangeCheckElimination -XX:-DoEscapeAnalysis TestLoopPredicationPin.java
    static void test() {
        iArr = new int[9500];

    	int a = 77;
        int b = 0;
        do {
            a--;
            b++;
        } while (a > 0);

        // 3) After 1st loop opts in IGVN, we find that a = 0.

        int limit = flag ? 10000 : 9000;
        int init = flag2 ? 0 : 5;

        // 4) After Loop Peeling, we have this graph. During IGVN, we find that a = 0 and we can clean the entire peeled iteration up ("->"):
        //
        // RangeCheck for "i + a*iFld" with i == init -> init + 0*iFld -> init, 4a) which is [0,5] and thus always in range (< 9500)
        // if (a > 10) exit                           -> a = 0 -> always false, 4b)
        // Zero-Trip Guard                            -> init + 1 > limit -> [1,6] > [9000,1000] is always true
        // Remaining Loop
        // RangeCheck for "i + a*iFld"
        //
        // 5) Since we cleaned up the entire peeled iteration, we can reuse the Parse Predicates again for the remaining loop.
        // 6) Loop Peeling added a CastII for the iv of the remaining loop. As a result, the RangeCheck in the remaining loop is pinned at
        //    the current loop entry.
        // 7) We apply Loop Predication even though the iv is pinned at the loop entry -> we add the Hoisted Range Check predicate above that pin which
        //    violates domination and we fail with a bad graph assertion.
        for (int i = init; i < limit; i++) {
            // 1) 1st loop opts: Too complicated for Loop Predication.
            iArr[i + a*iFld] = 343; // 4a) -> iArr[i]
            // 2) 1st loop opts: We don't know, yet, that a = 0. The check is loop invariant and an exit -> Loop Peeling.
            if (a > 10) { // 4b) -> removed
                return;
            }

            iFld = 34;
        }
    }

    // java -XX:CompileCommand=compileonly,*TestLoopPredicationPin::test* -XX:-TieredCompilation -Xcomp -XX:+StressLoopPeeling -XX:RepeatCompilation=100 TestLoopPredicationPin.java
    static void testFuzzer() {
        int i16 = 14;
        for (int i = 4; i < 251; i += 3) {
            iArr[i] = 45;
            for (int j = i; j < 305; j++) {
                iArr[j] = 34;
                switch (i16 * 5) {
                    case 90:
                        iArr[1] = iFld;
                        i16 += 5;
                        dFld = 150;
                }
            }
        }
    }
}

