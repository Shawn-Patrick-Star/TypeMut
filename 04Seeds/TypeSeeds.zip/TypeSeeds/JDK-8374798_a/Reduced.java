public class Reduced {
    static int iFld;
    static long lFld, lFld2;
    static int iArrFld[] = new int[10];

    public static void main(String[] strArr) {
        for (int i = 0; i < 10; i++) {
            test();
        }
    }

    static void test() {
        int i15 = 39749, i16 = 5;
        for (int i11 : iArrFld) {
            for (int i12 = 3; i12 < 63; i12++) {
                for (int i14 = 1; i14 < 2; ++i14) {
                    iFld <<= lFld;
                }
                iFld >>= lFld = i15;
            }
            do {
                for (int f3 = 1; f3 < 1; f3 += 3) {
                    i15 = (int) lFld2;
                }
            } while (++i16 < 63);
        }
    }
}

