public class TestBrokenSuperWord {
    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            int[] array = test1();
            int j;
            boolean abort = false;
            for (j = 0; j < array.length-2; j++) {
                if (array[j] != (j | 1)) {
                    System.out.println("For " + j + " " + array[j]);
                    abort = true;
                }
            }
            for (; j < array.length; j++) {
                if (array[j] != j) {
                    System.out.println("For " + j + " " + array[j]);
                    abort = true;
                }
            }
            if (abort) {
                throw new RuntimeException("Failure");
            }
        }
    }

    private static int[] test1() {
        int limit = 2;
        for (; limit < 4; limit *= 2);
        int k = limit / 4;

        int[] array = new int[1000];
        int[] flags = new int[1000];
        int[] flags2 = new int[1000];
        int j;
        for (j = 0; j < 10; j += k) {

        }
//        j -= 9;
        notInlined(array);
        for (int i = 0; ; i++) {
            synchronized (new Object()) {}
            int ii = Integer.min(Integer.max(i, 0), array.length-1);
            int v = array[ii];
            if (flags2[ii] * (j-10) != 0) {
                throw new RuntimeException("never taken" + v);
            }
            if (i * k >= array.length - 2) {
                break;
            }
            if (flags[ii]*(j-10)  != 0) {
                throw new RuntimeException("never taken");
            }
            array[ii] = v | 1;
        }
        return array;
    }

    private static void notInlined(int[] array) {
        for (int i = 0; i < array.length; i++) {
            array[i] = i;
        }
    }
}
