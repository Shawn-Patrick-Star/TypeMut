public class Test4 {
    static int limit = 0;
    static int res = 0;

    static void test() {
        for (int i = 0; i >= limit + -2147483647; i += -2147483648) {
            res += 42;
        }
    }
 
    public static void main(String[] args) {
        test();
    }   
}
