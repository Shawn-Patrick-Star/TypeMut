// java -XX:TieredStopAtLevel=1 -XX:CompileCommand=compileonly,Test::test -XX:CompileCommand=printcompilation,Test::* Test.java
//
// This flag disables the reproduction:
//   -XX:-UseLoopInvariantCodeMotion

public class Test {
    static void test() {
        for (int i = 0; i < 10; i++) {
            // C1:
            // hoists range-check-free LoadIndex out of the loop,
            // before the String.checkIndex guard makes it safe.
            // The index is obviously far out of bounds, which
            // is likely to go to unmapped memory: SIGSEGV
            //
            // Code:
            //   String.charAt --calls--> StringUTF16.charAt
            //
            //   StringUTF16.charAt(byte[] value, int index):
            //     checkIndex(index, value)
            //     return getChar(value, index)   <----- hoisted
            //
            "\u266B".charAt(1000_000_000);
        }
    }

    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            try {
                test();
            } catch (StringIndexOutOfBoundsException e) {
            }
        }
    }
}
