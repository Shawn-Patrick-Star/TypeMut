public class Reproducer2 {
  static Wrapper w1 = new Wrapper();
  static Wrapper w2 = new Wrapper();
  static Wrapper w3 = new Wrapper();

  public static void main(String... args) {
    for (int x = 0; x < 100000000; x++) {
      makeRandomQuery(x % 2 == 0);
    }
  }

  private static class Wrapper {
    long longs;
    void maybeMaskBits(boolean b) {
      if (b) {
        longs &= 0x1f1f1f1f;
      }
    }
  }

  private static void makeRandomQuery(boolean two) {
    Wrapper[] wrappers_array;
    if (two) {
      wrappers_array = new Wrapper[] {w1, w2};
    } else {
      wrappers_array = new Wrapper[] {w1, w2, w3};
    }
    for (Wrapper wrapper : wrappers_array) {
      wrapper.maybeMaskBits(two);
    }
  }
}
