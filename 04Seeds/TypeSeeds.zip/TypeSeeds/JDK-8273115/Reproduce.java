/**
 * javac Reproduce.java && macosx-aarch64-debug/jdk/bin/java \
 * -XX:+TraceLoopOpts -Xcomp -XX:-TieredCompilation -XX:CompileOnly=Reproduce.main Reproduce
 */

public class Reproduce {
    static int y;
    static int[] A = new int[1];

    public static void main(String[] args) {
        for (int i = 0; i < 10; i+=2) {
            int k;
            int j;
            for (j = 1; (j += 3) < 5; ) {
                A[0] = 0;
                for (k = j; k < 5; k++) {
                    y++;
                }
            }
            y = j;
        }
    }

}
