public class TestTruncationWrap {
    public static void main(String[] args) {
        int[] array = new int[100];
        for (int i = 0; i < 20_000; i++) {
            test1(0, 100, array);
        }
    }

    private static void test1(int start, int stop, int[] array) {
        stop = (stop << 16) >> 16;
        int v = array[start];
        for (int i = start; i < stop;) {
            i++;
            i = (i << 16) >> 16;
        }
    }
}
