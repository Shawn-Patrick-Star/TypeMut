import java.util.Arrays;

// java -XX:-TieredCompilation -XX:CompileCommand=quiet -XX:CompileCommand=compileonly,FailedToCatch::test -Xbatch FailedToCatch.java

public class FailedToCatch {
    static int counter = 0;

    public static void main(String[] args) {
        Object[] array = new Object[10];
        for (int i = 0; i < 50_000; i++) {
            test(array);
        }
        if (counter != 50_000) {
            throw new RuntimeException("Test failed");    
        }
    }

    static void test(Object[] array) {
        try {
            Arrays.copyOfRange(array, 15, 20, Object[].class);
        } catch (ArrayIndexOutOfBoundsException e) {
            // Expected
            counter++;
        }
    }
}
