
public class Test 
{ 
    public static long computeValue() { 
 
        long value = -176; 
 
        return (long)(value * value * value); 
    } 
 
    public static void main(String[] args) { 
 
        try { 
             
            long value = -176; 
 
            System.out.println("Result 1: " + (long)(value * value * value)); 
 
            System.out.println("Result 2: " + Test.computeValue()); 
 
        } catch (Throwable t) { 
            t.printStackTrace(); 
        } 
 
    } 
}