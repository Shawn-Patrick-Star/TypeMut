public class Test {
    static boolean flag;

    public static void main(String[] strArr) {

        for (int i = 0; i < 10000; i++) {
            flag = !flag;
            test();
        }
    }

    public static void test() {
        int limit = flag ? Integer.MAX_VALUE : 1000;

        int i = 0;
        while (i < limit) {
            i += 3;

            if (flag) {
                return;
            }
        }
    }
}

