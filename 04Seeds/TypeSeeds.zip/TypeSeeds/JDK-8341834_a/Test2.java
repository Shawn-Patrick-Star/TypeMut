public class Test2 {
    public static long val = 0;

    public static void test() {
        int array[] = new int[500];

        for (int i = 0; i < 100; i++) {
            for (long l = 100; l > i; l--) {
                val = 42 + (l + i);
                array[(int)l] = (int)l - (int)val;
            }
        }
    }

    public static void main(String[] args) {
        test();
    }
}

// Alternative version

/*
public class Test2 {
    public static int val = 0;

    public static void test() {
        int array[] = new int[500];

        for (int i = 0; i < 100; i++) {
            for (long l = 100; l > i; l--) {
                val = (int)(l + i);
                array[(int)l] -= (int)l - val;
            }
        }
    }

    public static void main(String[] args) {
        test();
    }
}
*/