public class TestNullAtCallAfterLateInline {
    private static final C c = new C();
    private static final A a = new A();
    private static volatile int volatileField;
    private static B b= new B();

    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            testHelper1(0, true);
            testHelper1(1, true);
            testHelper1(2, true);
            test1(false);
            testHelper2(0, true, b);
            testHelper2(1, true, c);
            testHelper2(2, true, a);
            inlined2(null, 3);
            test2(false, null);
        }
    }

    private static int test1(boolean flag) {
        for (int i = 0; i < 10; i++) {
        }
        return testHelper1(3, flag);
    }

    private static int testHelper1(int i, boolean flag) {
        int v;
        if (flag) {
            A a = inlined1(i);
            a.notInlined();
            v = a.field;
        } else {
            volatileField = 42;
            v = volatileField;
        }
        return v;
    }

    private static A inlined1(int i) {
        if (i == 0) {
            return b;
        } else if (i == 1) {
            return c;
        } else if (i == 2) {
            return a;
        }
        return null;
    }

    private static int test2(boolean flag, A a) {
        for (int i = 0; i < 10; i++) {
        }
        return testHelper2(3, flag, a);
    }

    private static int testHelper2(int i, boolean flag, A a) {
        int v;
        if (flag) {
            inlined2(a, i);
            a.notInlined();
            v = a.field;
        } else {
            volatileField = 42;
            v = volatileField;
        }
        return v;
    }

    private static void inlined2(Object a, int i) {
        if (i == 0) {
            if (!(a instanceof B)) {
            }
        } else if (i == 1) {
            if (!(a instanceof C)) {

            }
        } else if (i == 2) {
            if (!(a instanceof A)) {

            }
        } else {
            if (!(a instanceof D)) {
            }
        }
    }

    private static class A {
        public int field;

        void notInlined() {}
    }

    private static class B extends A {
        void notInlined() {}
    }

    private static class C extends A {
        void notInlined() {}
    }

    private static class D {
    }
}
