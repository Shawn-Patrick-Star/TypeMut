// java -Xbatch -XX:-TieredCompilation -XX:CompileCommand=compileonly,Test.test -XX:-UseOnStackReplacement Test.java

public class Test {
    boolean b;

    boolean getB() {
        return b;
    }

    void test() {
        int x = -845;

        for (int i = 5; i > 1; i -= 2) {
            try {
                try {
                    for (Object temp = new byte[x]; ; ) {
                        // infinite loop
                    }
                } finally {
                    int zeroLimit = 2;
                    for (; zeroLimit < 4; zeroLimit *= 2) { }

                    int zero = 34;
                    for (int peel = 2; peel < zeroLimit; peel++) {
                        zero = 0;
                    }

                    if (zero == 0) {
                        // nop
                    }

                    int flagLimit = 2;
                    for (; flagLimit < 4; flagLimit *= 2) { }

                    boolean flag = getB();
                    for (int peel = 2; peel < flagLimit; peel++) {
                        if (flag) {
                            break;
                        }
                    }
                }
            } catch (Throwable t) {
                // ignored
            }
        }
    }

    public static void main(String[] strArr) {
        Test t = new Test();
        for (int i = 0; i < 10_000; ++i) {
            t.test();
        }
    }
}
