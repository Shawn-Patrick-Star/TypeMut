import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;

public class Test {
    public static void main(String[] args) throws Throwable {
        int[] a = new int[1005];
        MethodHandles.Lookup lookup = MethodHandles.lookup();
        MethodType mt = MethodType.methodType(void.class, boolean.class, int[].class);
        MethodHandle mh = lookup.findStatic(Test.class, "test", mt);
        MethodHandle mhGeneric = mh.asType(mt.generic()).asType(mt);
        for (int i = 0; i < 10000; i++) {
            mhGeneric.invoke(i % 2 == 0, a);
        }
    }

    static void test(boolean flag, int[] a) {
        int x = flag ? 1000 : 2147483646;
        for (int i = 0; i <= x; i += 4) {
            for (int loopVar = 0; loopVar < 10; loopVar++) {
                if (!flag) {
                    return;
                }
            }
            a[i] = 34;
        }
    }
}
