
public class Test {
    public static void main(String[] args) throws Exception {
        java.lang.invoke.MethodHandles.constant(boolean.class, true);
    }
}