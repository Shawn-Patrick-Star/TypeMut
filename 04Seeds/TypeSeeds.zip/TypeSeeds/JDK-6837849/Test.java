public class Test
{
  public static long JITFails(long num, int s)
  {
    long a;
    
    switch (s)
    {
      default:
        num = num / 10;
      case  1:
        a = num / 10;
        
        return (a);
    }
  }
  
  public static long JITSucceeds(long num, int s)
  {
    long a;
    
    switch (s)
    {
      default:
        num = num / 11;
      case  1:
        a = num / 11;
        
        return (a);
    }
  }
  
  public static void main(String [] args) {
    
    for (int i = 0; i < 100000; i++) {
      JITFails(123456L, i % 2);
      
      JITSucceeds(123456, i % 2);
    }
  }
}