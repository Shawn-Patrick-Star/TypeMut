public class Test {
    public static void main(String[] args) {
        int gold = test(-2);
        for (int i = 0; i < 10000; i++) {
            test(2);
            test(-2);
        }
        int res = test(-2);
        if (res != gold) {
            throw new AssertionError("wrong result: " + res + ", gold: " + gold);
        }
    }

    private static int test(int start) {
        if (((short) Integer.compareUnsigned(start, 2)) < 0) {
            return 0;
        }
        int i = start;
        while (i < 3) {
            i = (i + 1) & 0x7fff;
            if (i < 1) {
                break;
            }
        }
        return i;
    }
}
