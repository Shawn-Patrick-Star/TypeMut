class Test2 {
    static final int RANGE = 1024;
    static final int ITER  = 10_000;

    static void initNaN(float[] dataF, int offset) {
        for (int i = 0; i < RANGE; i++) {
            dataF[i] = i + ((i + offset) % 5) * 10;
            if (i % (offset + 5) == 0) {
                dataF[i] = Float.NaN;
            }
        }
    }

    static void test(float[] a, float[] b, float[] r) {
        for (int i = 0; i < RANGE; i+=2) {
            r[i+0] = (a[i+0] > b[i+0]) ? 1 : 0;
            r[i+1] = (a[i+1] >= b[i+1]) ? 1 : 0;
        }
    }

    public static void main(String[] args) {
        float[] a = new float[RANGE];
        float[] b = new float[RANGE];
        float[] r = new float[RANGE];
        float[] r2 = new float[RANGE];
        initNaN(a, 0);
        initNaN(b, 1);
        a[100] = 1;
        a[101] = 1;
        a[102] = 0;
        a[103] = 0;
        a[104] = 1;
        a[105] = 1;
	b[100] = 1;
        b[101] = 1;
        b[102] = 1;
        b[103] = 1;
        b[104] = 0;
        b[105] = 0;
        test(a, b, r2);
        for (int i = 0; i < ITER; i++) {
            test(a, b, r);
        }
        verify(r, r2, a, b);
    }

    static void verify(float[] r, float[] r2, float[] a, float[] b) {
        boolean failed = false;
        for (int i = 0; i < RANGE; i++) {
            if (r[i] != r2[i] && !( Float.isNaN(r[i]) && Float.isNaN(r2[i]) )) {
                System.out.println("fail: " + i + " " + r[i] + " != " + r2[i] + " : " + a[i] + " " + b[i]);
                failed = true;
            }
        }
        if (failed) {
            throw new RuntimeException("There were wrong results");
        }
    }
}

