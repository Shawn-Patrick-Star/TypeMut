public class Reduced {
    static long instanceCount;

    public static void main(String[] args) {
        for (int i = 0; i < 2000; i++) {
            test();
        }
    }

    static void test() {
        int i, i1 = 6, i9, i10, i11, i12;
        boolean b = false;
        for (i = 25; i > 5; i--) {
            i9 = 1;
            do {
                i1 += 0;
                for (i10 = 1; i10 < 3; ++i10) {
                    instanceCount = i9;
                }
                i12 = 3;
                while (--i12 > 0) {
                    i11 = (int) instanceCount;
                    i1 = i11;
                    if (b) {};
                    instanceCount &= 21;
                }
                i9++;
            } while (i9 < 9);
        }
    }
}
