class TestReduced {
  static int N;
  static int iArrFld[];
  static void test() {
    int i20 = 1, i23 = 3, i24 = 4, i25;
    double d1, d2;
    long lArr2[] = new long[N];
    for (d1 = 63; d1 > 2; d1 -= 2) {
      for (d2 = 3; 1 < d2; --d2)
        i20 <<= i24;
      i20 &= i23;
      for (i25 = 1; 3 > i25; i25++)
        try {
          i20 = iArrFld[1];
          i24 = 0;
        } catch (ArithmeticException a_e) {
        }
    }
  }
  public static void main(String[] args) {
      test();
  }
}
