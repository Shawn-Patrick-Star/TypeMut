class wide
{
   public static void main(String[] arg) {
       float  f1 = Float.MAX_VALUE;
       float  f2 = Float.MAX_VALUE;
       double d1 = Double.MAX_VALUE;
       double d2 = Double.MAX_VALUE;

       if(f1 * f2 == Float.POSITIVE_INFINITY) 
           System.out.println("Float test PASSES.");
       else
           System.out.println("Float test FAILS");

       if(d1 * d2 == Double.POSITIVE_INFINITY) 
           System.out.println("Double test PASSES.");
       else
           System.out.println("Double test FAILS");

   }
}