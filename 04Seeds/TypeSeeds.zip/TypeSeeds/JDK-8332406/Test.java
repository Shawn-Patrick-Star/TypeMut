
public class Test {
    static final Object OBJ = new Object();

    public static Object test(boolean b, Object[] array, int i) {
        return b ? array[i] : OBJ;
    }

    public static void main(String[] args) {
        test(true, new Object[1], 0);
    }
}
