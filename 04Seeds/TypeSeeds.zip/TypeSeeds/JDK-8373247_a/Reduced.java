public class Reduced {

    public static void main(String[] strArr) {
        Integer a = 34; // Make sure loaded
        test();
    }

    static void test() {
        int x = 1;
        for (int i = 6; i < 100; i++) {
            try {
                x = i % Integer.MIN_VALUE;
            } catch (ArithmeticException a_e) {
                x += 0;
            }
        }
    }
}
