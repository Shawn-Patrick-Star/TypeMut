// java -XX:+AlwaysIncrementalInline -XX:CompileOnly=TestDeadLoopIncrementalInlining::test1 -Xcomp TestDeadLoopIncrementalInlining
public class TestDeadLoopIncrementalInlining {
    private static Object fieldObject;
    private static int field;

    public static void main(String[] args) {
        Object o = new Object();
        test1(0, true);
    }

    private static Object test1(int j, boolean flag) {
        if (j < 42) {
            if (flag) {
                field = 42;
            }
            Object o = fieldObject;
            if (j >= 42) {
                for (int i = 1; i < 10; ) {
                    boolean boolRes = lateInlined2();
                    if (boolRes) {
                        i *= 2;
                        o =lateInlined1(o);
                        if (o == null) {
                            throw new RuntimeException();
                        }
                    } else {
                        i++;
                    }
                }
            }
            return o;
        }
        return null;
    }

    private static boolean lateInlined2() {
        return true;
    }

    private static Object lateInlined1(Object o) {
        return o;
    }
}
