import static java.lang.Integer.*;

public class Test {
    public static boolean test() {
        for (int i = MAX_VALUE - 50_000; compareUnsigned(i, -1) < 0; ++i) {
            if (compareUnsigned(MIN_VALUE, i) < 0) {
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10_000; ++i) {
            test();
        }
    }
}
