/*
 * Copyright (c) 2026, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

/*
 * @test
 * @bug 8353851
 * @summary Branches added for check_flat_array are opaque to the C1 register allocator.
 * @requires vm.debug == true
 * @enablePreview
 * @run main/othervm -XX:+UseSerialGC -XX:TieredStopAtLevel=1
 *                   -XX:+StressC1RegAlloc
 *                   -XX:CompileCommand=compileonly,${test.main.class}::test*
 *                   ${test.main.class}
 */

public class TestC1FlatArrayHiddenControlFlow {
    static volatile Object sink;
    static volatile int intSink;
    static Object live = new Object();
    static Integer value = 42;

    static Object testLoad1(Object[] array, int index) {
        Object result = live;
        if (result == null) {
            throw new RuntimeException();
        }
        sink = result;
        int tmp = index + 1;
        int arrayIndex = tmp & 1;
        Object element = array[arrayIndex];
        intSink = index;
        sink = element;
        return result;
    }

    static Object testLoad2(Object[] array, int index) {
        Object result = live;
        if (result == null) {
            throw new RuntimeException();
        }
        sink = result;
        int arrayIndex = ((index + 1) | index) + 1;
        Object element = array[arrayIndex];
        intSink = index;
        sink = element;
        return result;
    }

    static Object testStore(Object[] array) {
        Object result = live;
        if (result == null) {
            throw new RuntimeException();
        }
        sink = result;
        array[0] = value;
        return result;
    }

    public static void main(String[] args) {
        Integer[] array = { 42 };
        for (int i = 0; i < 5_000; i++) {
            int index = (i & 1) == 0 ? -1 : 1;
            if (testLoad1(array, index) != live || intSink != index) {
                throw new RuntimeException("Unexpected result");
            }
            index = (i & 1) == 0 ? -1 : -2;
            if (testLoad2(array, index) != live || intSink != index) {
                throw new RuntimeException("Unexpected result");
            }
            if (testStore(array) != live) {
                throw new RuntimeException("Unexpected result");
            }
        }
    }
}
