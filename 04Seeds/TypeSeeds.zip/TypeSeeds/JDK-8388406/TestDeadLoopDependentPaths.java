public class TestDeadLoopDependentPaths {
    private static int field;
    private static boolean doThat = false;

    public static void main(String[] args) {
        test1(true);
    }

    private static void test1(boolean flag) {
        if (doThat) {
            if (flag) {
                field = 42;
            } else {
                field = 42;
            }
            if (!doThat) {
                while (true) {
                }
            }
        }
    }
}
