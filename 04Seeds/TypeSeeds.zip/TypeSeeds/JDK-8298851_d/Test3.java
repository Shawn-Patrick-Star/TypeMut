public class Test3 {
    static int iFld;

    static void test() {
        long l2;
        int i16, iArr2[] = new int[10];
        for (l2 = 186; l2 > 1; l2 -= 3) {
            for (i16 = (int) l2; i16 < 1; )
                ;
            try {
                iFld = 8 % i16;
            } catch (ArithmeticException a_e) {
            }
        }
    }

    public static void main(String[] strArr) {
        test();
    }
}
