class Test {
    int var15;

    void mainTest() {
        int i2 = 38;
        for (int i = 0; i < 100; ++i)
            try {
                int var5 = Integer.valueOf(i2);
                synchronized (new Test()) {
                    int var18 = var5 - 71;
                    synchronized (Test.class) {
                        for (int var19 = 0; var19 < var18;) {
                            int var21 = Integer.valueOf(var19);
                        }
                    }
                }
                for (int var8 = 0; var8 < 20000; ++var8) ;
            } catch (ArithmeticException a_e) {
            }
    }

    public static void main(String[] strArr) {
        Test _instance = new Test();
        _instance.mainTest();
    }
}