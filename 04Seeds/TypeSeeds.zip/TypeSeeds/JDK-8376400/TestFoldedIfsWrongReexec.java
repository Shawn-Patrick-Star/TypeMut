
// java -XX:-TieredCompilation -XX:-BackgroundCompilation -XX:-UseOnStackReplacement -XX:CompileOnly=TestFoldedIfsWrongReexec::test1 -XX:CompileCommand=quiet  -XX:-OptimizeUnstableIf TestFoldedIfsWrongReexec

public class TestFoldedIfsWrongReexec {
    private static int taken;
    private static int MIN_VALUE = Integer.MIN_VALUE;

    public static void main(String[] args) {
        for (int i = 0; i < 20_000; i++) {
            test1(12);
            if (taken != 0) {
                throw new RuntimeException("branch shouldn't have been taken");
            }
            test1Helper1(16, 0);
        }
        test1(0);
        if (taken == 0) {
            throw new RuntimeException("branch should have been taken");
        }
    }

    private static void test1(int i) {
        if (test1Helper1(i, 16) == 0) {
            throw new RuntimeException("never taken");
        }
        if (i + MIN_VALUE < 8 + Integer.MIN_VALUE) {
            taken++;
        }
        for (int j = 0; j < 10; j++) {
            for (int k = 0; k < 10; k++) {

            }

        }
    }

    private static int test1Helper1(int i, int j) {
        if (i + MIN_VALUE >= j + Integer.MIN_VALUE) {
            for (int k = 0; k < 100; k++) {
            }
            return 0;
        }
        return 1;
    }

}
