
public class Test {
    static boolean equal(Object left, Object right) {
        return left == right;
    }

    public static void main(String[] args) {
        for (int i = 0; i < 100_000; i++) {
            if (!equal(Integer.valueOf(i), Integer.valueOf(i))) {
                throw new AssertionError();
            }
        }

        for (int i = 0; i < 100_000; i++) {
            if (equal(new Object(), new Object())) {
                throw new AssertionError();
            }
        }
    }
}