public class Reduced3 {
    static long instanceCount;
    static int iArrFld[];
    static long lArrFld[];
    static double dArrFld[][];

    public static void main(String[] strArr) {
        test();
    }

    static void test() {
        int i16;

        boolean b = false;
        for (double d1 = 31.2; d1 < 72; d1++) {
            for (i16 = (int) d1; i16 < 2; ++i16) {
                iArrFld[i16] >>= 5;
                dArrFld[i16 - 1][i16] = 3;
                if (b) {
                    break;
                }
                lArrFld[i16] = 4;
            }
            switch (0) {
                case 5:
                    b = b;
            }
        }
    }
}
