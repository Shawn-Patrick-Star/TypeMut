// java -Xbatch -XX:-TieredCompilation -XX:CompileCommand=compileonly,Test.test Test.java

public class Test {
    static void test() {
        Byte x = 1;

        for (int i = 0; i < 10_000; i++) {
            if ((i & 1) == 0) {
                int N = 32;
                for (int j = 0; j < N; j++) {
                    if (j == 1) {
                        x = (byte) x;
                    }
                }

                for (int j = 0; j < 32; j++) {
                    Object o;
                    o = 1;
                    o.toString();

                    for (int k = 1; k < 32; k++) {
                        x = (byte) x;
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        test();
    }
}

