class Test {
  long instanceCount;
  int iArrFld[];
  void mainTest(String[] strArr1) {
    int i23, i24 = -239;
    try {
      for (i23 = 5;; --i23) {
        instanceCount >>= i24;
        iArrFld[i23] = (int)instanceCount;
      }
    } catch (NegativeArraySizeException exc2) {
    }
  }
  public static void main(String[] strArr) {
    try {
      Test _instance = new Test();
      _instance.mainTest(strArr);
    } catch (Exception ex) {
    }
  }
}
