  public class OverflowTest{
      static int test(byte a[]){
          int result=0;
          for( int i=0; i<a.length; i+=((0x7fffffff>>1)+1) ){
              result += a[i];
          }
          return result;
      }
  
      public static void main(String [] args){
          byte a[]=new byte[(0x7fffffff>>1)+2];
          System.out.println(""+test(a));
      }
  }