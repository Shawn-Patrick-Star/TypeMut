class Test {
  
  static void iMeth() {
    Byte x = 1;
    for (int i = 0; i < 10000; i++) {
      if ((i & 1) == 0) {
        x = (byte)x;
      }
    }
  }
  
  public static void main(String[] strArr) {
    Test _instance = new Test();
    for (int i = 0; i < 11; i++) {
        iMeth();
    }
  }
}
