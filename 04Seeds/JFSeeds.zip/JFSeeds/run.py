from pathlib import Path
import shutil

current_dir = Path.cwd()

for subdir in current_dir.iterdir():
    # 只处理当前目录下的第一层子文件夹
    if not subdir.is_dir():
        continue

    dt_dir = subdir / ".dt"

    # 删除 子文件夹/.dt
    if dt_dir.is_symlink():
        # 如果 .dt 是符号链接，只删除链接本身
        dt_dir.unlink()
        print(f"已删除符号链接: {dt_dir}")
    elif dt_dir.is_dir():
        shutil.rmtree(dt_dir)
        print(f"已删除: {dt_dir}")

print("处理完成。")